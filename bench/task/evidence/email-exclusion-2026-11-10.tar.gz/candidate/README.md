# Email exclusion regression evidence

The run manifest predeclares 51 task runs: four unchanged Personal-200 v2
`approval/remove-sensitive-detail` cases on Qwen3.5-4B and Qwen3.8-27B at seeds
1/2/7; three supplementary quoted/field/restart/isolation cases on both models
at those seeds; and three existing resume/approval controls on 4B at those seeds.
The original observed failures selected this work, so these are regression
checks, not fresh held-out accuracy. The original corpus and scores are unchanged.

The archive contains raw rows, strict checks, identity manifests, a source
snapshot, the independent scorer, commands, test/build logs and the historical
matrix pause/resume record. Model weights and the executable are omitted; their
hashes are recorded. Source hashes were checked around the build and at the end.

After extracting the archive, replay every check without a model:

```sh
python3 driver/replay.py .
```

The adjacent tracked JSON pins the archive and payload files. Its comparison
retains the original family scores and indexes any forbidden content actually
present in approval cards/outbox records; missing cards remain failed checks,
not successful privacy protection. The `leaked` task metric only covers recalled
values, so it is not used as a substitute for email-content checks.

`driver/evaluate.py` records the original absolute local paths/commands.
`driver/isolate.py` pauses only the identified historical matrix and resumes its
frozen command afterwards. `validation/before.log` preserves the regression
failing before the fix; `after.log` records its first passing rerun. Later checks
are in `integration.log`, `parser.log`, `workspace.log` and `clippy.log`. The final
workspace includes all new tests, including explicit follow-up inheritance.

The runtime guard recognizes bounded standalone English commands and quoted
literals/labeled fields; it does not guarantee semantic, multilingual or encoded
redaction. Product guidance was strengthened, but approvals, object binding,
cancellation, execution limits and retry guards remain intact. Physical Android
and live delivery were not tested by this run.
