from pathlib import Path
import json,sqlite3,tempfile,time
out=Path('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/task/result/email-exclusion-verified-2026-11-10')
while not out.exists():time.sleep(0.1)
seen=set(); dest=out/'diagnostics'; dest.mkdir(exist_ok=True)
while not (out/'finished.json').exists():
 try:
  running=json.loads((out/'running.json').read_text()); job=running['job']['name']
  base=Path(tempfile.gettempdir())/f"pr3-bench-task-{running['child_pid']}"
  for path in base.glob('*/memory.sqlite'):
   try:
    with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=0.1) as conn:
     for row in conn.execute("SELECT id,task_id,at,text,tool,arguments,success FROM messages WHERE kind='tool'"):
      key=(job,path.parent.name,row[0])
      if key not in seen:
       seen.add(key)
       value={'job':job,'case_directory':path.parent.name,**dict(zip(['id','task_id','at','output','tool','arguments','success'],row))}
       with (dest/'tool-observations.jsonl').open('a') as stream:stream.write(json.dumps(value,ensure_ascii=False)+'\n')
   except (sqlite3.Error,OSError):pass
 except (OSError,ValueError):pass
 time.sleep(0.1)
print('Supplementary read-only tool observations finished.')
