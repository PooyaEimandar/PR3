"""Replay raw observations without loading a model: python3 driver/replay.py ."""
from pathlib import Path
import hashlib,json,sys,tarfile,tomllib
from score import assess
root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1])
def digest(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
manifest=json.loads((root/'manifest.json').read_text())
assert digest(root/'source.tar.gz')==manifest['source_archive_sha256']
with tarfile.open(root/'source.tar.gz') as archive:
 for name,expected in manifest['source_sha256'].items():
  assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==expected,name
for name,expected in manifest['files'].items():
 if name.startswith('bin/'):continue # Executable omitted; identity is pinned in each row manifest.
 assert digest(root/name)==expected,name
results=[]
for job in manifest['jobs']:
 corpus_path=root/'data'/(job['corpus']+'.toml')
 corpus=tomllib.loads(corpus_path.read_text())
 cases={c['id']:c for c in corpus['case']}
 path=root/'rows'/(job['name']+'.jsonl')
 rows=[json.loads(line) for line in path.read_text().splitlines()]
 assert [r['id'] for r in rows]==job['cases']
 identity=json.loads(path.with_suffix('.manifest.json').read_text())
 assert identity=={'harness':5,'model_sha256':manifest['models'][job['model']]['sha256'],'binary_sha256':manifest['files']['bin/pr3-bench-task'],'corpus_sha256':digest(corpus_path),'seed':job['seed'],'web':True,'cases':job['cases']}
 verdicts=[assess(cases[row['id']],corpus['filler'],row,job['seed']) for row in rows]
 results.append({**job,'recorded':len(rows),'passed':sum(v['passed'] for v in verdicts),'leaked':sum(v['leaked'] for v in verdicts),'errors':sum(v['error'] for v in verdicts)})
assert results==json.loads((root/'finished.json').read_text())['jobs']
print(json.dumps({key:sum(j[key] for j in results) for key in ['recorded','passed','leaked','errors']},indent=2))
