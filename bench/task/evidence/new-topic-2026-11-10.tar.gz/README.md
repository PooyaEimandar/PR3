# New task and restart: focused regression evidence

The manifest predeclares 33 task runs: four unchanged Personal-200 v2
`isolation/new-task-empty` cases on Qwen3.5-4B and Qwen3.8-27B, each at seeds
1/2/7; and `restart/trip`, `topic/speech`, `approval/dinner` on 4B at the same
seeds. The observed v2 failures motivated this fix, so these are regression
checks, not a fresh held-out evaluation. The original corpus and scores remain
unchanged.

The archive contains raw rows, original checks, identity manifests, a source
snapshot, the independent scorer, commands, build/test logs and the historical
matrix pause/resume record. The executable and model weights are omitted; their
hashes are recorded. No source changed between build and the end of the run.

After extracting the archive, replay every check without a model:

```sh
python3 driver/replay.py .
```

The adjacent tracked JSON pins the archive and every payload file. Its summary
compares the original family scores to this run and records limitations.
`driver/evaluate.py` records the actual local evaluation commands, including the
original absolute paths. `driver/isolate.py` records pausing only the identified
historical matrix process and resuming its original frozen command afterwards.
`validation/before.log` retains the two regressions failing before the fix;
`after.log` retains them passing, and `workspace.log`/`clippy.log` record the final
checks. `targeted.log` preserves a restricted-sandbox attempt whose existing
socket tests could not bind; the authorized full rerun passed.
