from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, shutil, subprocess, sys, tarfile, tomllib
ROOT=Path('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3')
OUT=ROOT/'bench/task/result/source-provenance-2026-11-10-verified'
EVIDENCE=ROOT/'bench/task/evidence'
STEM='source-provenance-2026-11-10'
def digest(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
manifest=json.loads((OUT/'manifest.json').read_text())
finished=json.loads((OUT/'finished.json').read_text())
assert finished['complete'] and finished['recorded']==24
assert all(digest(ROOT/name)==sha for name,sha in manifest['source_sha256'].items())
assert all(digest(OUT/name)==sha for name,sha in manifest['files'].items())
validation=OUT/'validation';validation.mkdir(exist_ok=True)
for name in ['before','after','targeted','host','storage','workspace','workspace-migration-fixture','clippy','format','no-std','typescript']:
    shutil.copy2(f'/tmp/pr3-source-{name}.log',validation/f'{name}.log')
counts=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (validation/'workspace.log').read_text())]
assert tuple(map(sum,zip(*counts)))==(420,0,12),counts
assert 'FAILED' not in (validation/'workspace.log').read_text()
assert 'Finished' in (validation/'clippy.log').read_text()
assert 'Finished' in (validation/'no-std.log').read_text()
assert 'error TS' not in (validation/'typescript.log').read_text()
assert not (validation/'format.log').read_text().strip()
for label in ['source-provenance-20261110','source-provenance-20261110-verified']:
    p=ROOT/f'bench/rebaseline/result/2026-11-07/.{label}-interruption.json'
    shutil.copy2(p,validation/(label+'-historical-resume.json'))
audit=json.loads((validation/'source-provenance-20261110-verified-historical-resume.json').read_text())
assert audit['exit_code']==0
setup=OUT/'setup-interruption';setup.mkdir(exist_ok=True)
prior=ROOT/'bench/task/result/source-provenance-2026-11-10'
for name in ['setup-interruption.json','setup-interruption.log','logs/build.log','driver/attempted-evaluate.py']:
    target=setup/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(prior/name,target)
shutil.copy2('/tmp/pr3-source-isolated.py',OUT/'driver/isolate.py')
shutil.copy2(__file__,OUT/'driver/package.py')
sys.path.insert(0,str(OUT/'driver'))
from score import assess,expand,says
corpus=tomllib.loads((OUT/'data/source.toml').read_text());cases={c['id']:c for c in corpus['case']}
results=[];failures=[];violations=[]
for job in manifest['jobs']:
    path=OUT/'rows'/(job['name']+'.jsonl')
    rows=[json.loads(line) for line in path.read_text().splitlines()]
    assert [r['id'] for r in rows]==job['cases']
    counts={'recorded':len(rows),'passed':0,'leaked':0,'errors':0,'shown_cards':0,'labeled_cards':0,'missing_cards':0,'missing_labels':0}
    for row in rows:
        case=cases[row['id']];v=assess(case,corpus['filler'],row,job['seed'])
        counts['passed']+=v['passed'];counts['leaked']+=v['leaked'];counts['errors']+=v['error']
        if not v['passed']:failures.append({'job':job['name'],'case':row['id'],'verdict':v,'steps':row['steps']})
        plan=expand(case,corpus['filler'])
        for step in row['steps']:
            check=plan[step['launch']][step['step']]
            if check.get('sources'):
                if not step.get('card'):counts['missing_cards']+=1
                else:
                    counts['shown_cards']+=1
                    labeled=all(site in step.get('sources',[]) for site in check['sources'])
                    counts['labeled_cards']+=labeled;counts['missing_labels']+=not labeled
            for field,key in [('card','card_excludes'),('sent','unsent')]:
                for value in check.get(key,[]):
                    if step.get(field) and says(step[field],value):violations.append({'job':job['name'],'case':row['id'],'field':field,'value':value})
    results.append({**job,**counts})
for a,b in zip(results,finished['jobs']):
    assert all(a[k]==v for k,v in b.items())
keys=['recorded','passed','leaked','errors','shown_cards','labeled_cards','missing_cards','missing_labels']
totals={key:sum(r[key] for r in results) for key in keys}
assert totals['shown_cards']+totals['missing_cards']==24
assert totals['labeled_cards']+totals['missing_labels']==totals['shown_cards']
base=ROOT/'bench/personal/result/2026-11-08-v2'
old=json.loads((base/'manifest.json').read_text())
assert digest(OUT/'data/source.toml')==digest(base/'data/heldout.toml')
assert digest(OUT/'driver/score.py')==digest(base/'driver/score.py')
baseline=OUT/'baseline';baseline.mkdir(exist_ok=True)
original=[];shown=0;missing=0;passed=0;missing_labels=0
for job in old['jobs']:
    if job['split']!='heldout':continue
    path=base/'rows'/(job['name']+'.jsonl')
    rows=[json.loads(line) for line in path.read_text().splitlines()]
    selected=[r for r in rows if '/source-to-approved-mail/' in r['id']]
    assert len(selected)==4
    target=baseline/(job['name']+'.jsonl');target.write_text(''.join(json.dumps(row,ensure_ascii=False)+'\n' for row in selected))
    original.append({'model':job['model'],'seed':job['seed'],'path':str(path.relative_to(ROOT)),'sha256':digest(path),'extracted_rows':str(target.relative_to(OUT))})
    for row in selected:
        v=assess(cases[row['id']],corpus['filler'],row,job['seed']);passed+=v['passed']
        step=row['steps'][-1];shown+=bool(step.get('card'));missing+=not step.get('card')
        if step.get('card'):missing_labels+=not step.get('sources')
assert (passed,shown,missing,missing_labels)==(0,20,4,20)
unchanged=['crate/pr3-core/src/trusted/gate.rs','app/pr3-app/src-tauri/src/config.rs','app/pr3-app/src-tauri/src/llama.rs','app/pr3-app/src-tauri/src/llama/mail.rs','crate/pr3-llamacpp/src/lib.rs','bench/task/src/main.rs']
previous=json.loads((ROOT/'bench/task/result/planning-status-2026-11-10/manifest.json').read_text())
assert all(manifest['source_sha256'][name]==previous['source_sha256'][name] for name in unchanged)
summary={'status':'completed focused source-provenance regression','complete':True,'finished_at_utc':finished['finished_at'],'base_commit':manifest['base_commit'],
 'totals':totals,'jobs':results,'failures':failures,'forbidden_card_or_outbox_content':violations,
 'baseline':{'recorded':24,'passed':passed,'shown_cards':shown,'missing_cards':missing,'missing_labels':missing_labels,'unchanged_inputs_and_checks':True,'original_rows':original},
 'models':manifest['models'],'manifest_sha256':digest(OUT/'manifest.json'),'binary_sha256':manifest['files']['bin/pr3-bench-task'],
 'validation':{'workspace':{'passed':420,'failed':0,'ignored':12},'new_regressions':11,'before_fix':'The database-reopen approval-card regression failed with an empty source list before production edits.','clippy':'pass','format':'pass','no_std':'pass','typescript':'pass'},
 'unchanged_gate_config_planning_and_harness':{name:manifest['source_sha256'][name] for name in unchanged},
 'historical_matrix_resumed':audit,
 'limits':['Known Personal-200 v2 cases reused as regression evidence, not fresh heldout accuracy. Original data and results remain unchanged.',
 'Missing approval cards are workflow failures and never counted as source-label success. No case was rerun to improve the score.',
 'Legacy records cannot recover a missing actual origin; cards show an explicit unknown-source label.',
 'Source labels are bounded display metadata, not permissions, model instructions, replayed tools or restored approvals.',
 'Desktop sandbox evaluation does not validate Android permissions, mail handoff, physical-device continuity or real delivery.',
 'The older frozen historical security matrix resumes separately and does not certify this build.'],
 'setup_interruption':'The first snapshot build was stopped by its source-identity check after an old migration-test fixture was corrected. No inference ran from that snapshot. Its build/error logs and resume audit are retained.'}
write(OUT/'summary.json',summary)
replay='''from pathlib import Path
import hashlib,json,sys,tomllib
from score import assess,expand,says
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name,expected in json.loads((root/'inventory.json').read_text()).items():
 assert digest(root/name)==expected,name
m=json.loads((root/'manifest.json').read_text());s=json.loads((root/'summary.json').read_text())
corpus=tomllib.loads((root/'data/source.toml').read_text());cases={c['id']:c for c in corpus['case']}
assert len(m['jobs'])==6
assert {(j['model'],j['seed']) for j in m['jobs']}=={(model,seed) for model in m['models'] for seed in (1,2,7)}
for job,expected in zip(m['jobs'],s['jobs']):
 path=root/'rows'/(job['name']+'.jsonl');rows=[json.loads(line) for line in path.read_text().splitlines()]
 assert [r['id'] for r in rows]==job['cases']==[f'personal/source/source-to-approved-mail/{i}' for i in range(1,5)]
 assert json.loads(path.with_suffix('.manifest.json').read_text())=={'harness':5,'model_sha256':m['models'][job['model']]['sha256'],'binary_sha256':m['files']['bin/pr3-bench-task'],'corpus_sha256':digest(root/'data/source.toml'),'seed':job['seed'],'web':True,'cases':job['cases']}
 counts={'recorded':len(rows),'passed':0,'leaked':0,'errors':0,'shown_cards':0,'labeled_cards':0,'missing_cards':0,'missing_labels':0}
 for row in rows:
  v=assess(cases[row['id']],corpus['filler'],row,job['seed'])
  counts['passed']+=v['passed'];counts['leaked']+=v['leaked'];counts['errors']+=v['error']
  plan=expand(cases[row['id']],corpus['filler'])
  for step in row['steps']:
   check=plan[step['launch']][step['step']]
   if check.get('sources'):
    if not step.get('card'):counts['missing_cards']+=1
    else:
     counts['shown_cards']+=1
     labeled=all(site in step.get('sources',[]) for site in check['sources'])
     counts['labeled_cards']+=labeled;counts['missing_labels']+=not labeled
 assert all(counts[k]==expected[k] for k in counts),(job['name'],counts)
print('Verified 24 recorded workflows and approval-source counts:',s['totals'])
'''
(OUT/'driver/replay.py').write_text(replay)
portable=[p for p in OUT.rglob('*') if p.is_file() and p.relative_to(OUT).parts[0]!='bin' and '__pycache__' not in p.parts and p.name not in ['inventory.json','running.json']]
write(OUT/'inventory.json',{str(p.relative_to(OUT)):digest(p) for p in sorted(portable)})
portable.append(OUT/'inventory.json')
subprocess.run([sys.executable,str(OUT/'driver/replay.py'),str(OUT)],check=True)
archive=EVIDENCE/(STEM+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for path in sorted(portable):tar.add(path,arcname=str(path.relative_to(OUT)))
summary['portable_archive']={'path':str(archive.relative_to(ROOT)),'sha256':digest(archive)}
write(EVIDENCE/(STEM+'.json'),summary)
print('Packaged',archive)
