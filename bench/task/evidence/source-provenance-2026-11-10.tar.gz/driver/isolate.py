from pathlib import Path
from datetime import datetime, timezone
import json, os, signal, subprocess, sys, time
root=Path('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3')
base=root/'bench/rebaseline/result/2026-11-07'
label=sys.argv[1]
assert label.replace('-','').isalnum()
command=sys.argv[2:]
assert command
now=lambda:datetime.now(timezone.utc).isoformat()
processes=lambda:subprocess.check_output(['ps','-axo','pid=,pgid=,command='],text=True).splitlines()
for attempt in range(100):
 running=json.loads((base/'running.json').read_text())
 pid=running['runner_pid']
 owned=[s for s in processes() if int(s.strip().split(None,2)[0])==pid]
 if len(owned)==1 and str(root/'bench/rebaseline/run.py') in owned[0] and str(base) in owned[0]:break
 time.sleep(.2)
assert len(owned)==1 and str(root/'bench/rebaseline/run.py') in owned[0] and str(base) in owned[0],owned
assert os.getpgid(pid)==pid
launch=json.loads(base.with_suffix('.launch.json').read_text())['command']
assert launch==['/usr/bin/caffeinate','-i',str(root/'bench/agentdojo/.venv/bin/python'),str(root/'bench/rebaseline/run.py'),'--out',str(base)]
audit=base/f'.{label}-interruption.json'
assert not audit.exists()
data=dict(interrupted_at=now(),previous_running=running,reason='Source metadata persistence regression; historical frozen matrix inputs remain unchanged.',command=command)
audit.write_text(json.dumps(data,indent=2)+'\n')
os.killpg(pid,signal.SIGINT)
for _ in range(100):
 remaining=[s for s in processes() if int(s.strip().split(None,2)[1])==pid]
 if not remaining:break
 time.sleep(.1)
assert not remaining,remaining
try:
 print('Paused frozen matrix for '+label,flush=True)
 result=subprocess.run(command,cwd=root)
 data['exit_code']=result.returncode
finally:
 assert not [s for s in processes() if str(root/'bench/rebaseline/run.py') in s and '--out' in s]
 with base.with_suffix('.runner.log').open('a') as stream:
  child=subprocess.Popen(launch,cwd=root,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 data.update(resumed_at=now(),resumed_pid=child.pid,resumed_command=launch)
 audit.write_text(json.dumps(data,indent=2)+'\n')
 print('Resumed frozen matrix: '+str(child.pid),flush=True)
sys.exit(result.returncode)
