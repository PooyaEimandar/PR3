from pathlib import Path
import hashlib,json,sys,tomllib
from score import assess,expand,says
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name,expected in json.loads((root/'inventory.json').read_text()).items():
 assert digest(root/name)==expected,name
m=json.loads((root/'manifest.json').read_text());s=json.loads((root/'summary.json').read_text())
corpus=tomllib.loads((root/'data/source.toml').read_text());cases={c['id']:c for c in corpus['case']}
assert len(m['jobs'])==6
assert {(j['model'],j['seed']) for j in m['jobs']}=={(model,seed) for model in m['models'] for seed in (1,2,7)}
for job,expected in zip(m['jobs'],s['jobs']):
 path=root/'rows'/(job['name']+'.jsonl');rows=[json.loads(line) for line in path.read_text().splitlines()]
 assert [r['id'] for r in rows]==job['cases']==[f'personal/source/source-to-approved-mail/{i}' for i in range(1,5)]
 assert json.loads(path.with_suffix('.manifest.json').read_text())=={'harness':5,'model_sha256':m['models'][job['model']]['sha256'],'binary_sha256':m['files']['bin/pr3-bench-task'],'corpus_sha256':digest(root/'data/source.toml'),'seed':job['seed'],'web':True,'cases':job['cases']}
 counts={'recorded':len(rows),'passed':0,'leaked':0,'errors':0,'shown_cards':0,'labeled_cards':0,'missing_cards':0,'missing_labels':0}
 for row in rows:
  v=assess(cases[row['id']],corpus['filler'],row,job['seed'])
  counts['passed']+=v['passed'];counts['leaked']+=v['leaked'];counts['errors']+=v['error']
  plan=expand(cases[row['id']],corpus['filler'])
  for step in row['steps']:
   check=plan[step['launch']][step['step']]
   if check.get('sources'):
    if not step.get('card'):counts['missing_cards']+=1
    else:
     counts['shown_cards']+=1
     labeled=all(site in step.get('sources',[]) for site in check['sources'])
     counts['labeled_cards']+=labeled;counts['missing_labels']+=not labeled
 assert all(counts[k]==expected[k] for k in counts),(job['name'],counts)
print('Verified 24 recorded workflows and approval-source counts:',s['totals'])
