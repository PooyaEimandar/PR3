from pathlib import Path
import hashlib,json,sys,tomllib
from score import assess,expand
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name,expected in json.loads((root/'inventory.json').read_text()).items():assert digest(root/name)==expected,name
m=json.loads((root/'manifest.json').read_text());s=json.loads((root/'summary.json').read_text())
corpora={n:tomllib.loads((root/'data'/(n+'.toml')).read_text()) for n in ['source','compatibility']}
identities=[]
for job,expected in zip(m['jobs'],s['jobs']):
 corpus=corpora[job['corpus']];cases={c['id']:c for c in corpus['case']}
 path=root/'rows'/(job['name']+'.jsonl');rows=[json.loads(line) for line in path.read_text().splitlines()]
 assert [r['id'] for r in rows]==job['cases']
 identities.extend((job['model'],job['seed'],case) for case in job['cases'])
 assert json.loads(path.with_suffix('.manifest.json').read_text())=={'harness':5,'model_sha256':m['models'][job['model']]['sha256'],'binary_sha256':m['files']['bin/pr3-bench-task'],'corpus_sha256':digest(root/'data'/(job['corpus']+'.toml')),'seed':job['seed'],'web':True,'cases':job['cases']}
 passed=0;reads=0;fetches=0;cards=0;labeled=0
 for row in rows:
  v=assess(cases[row['id']],corpus['filler'],row,job['seed']);passed+=v['passed']
  assert v['passed'] and not v['leaked'] and not v['error']
  plan=expand(cases[row['id']],corpus['filler'])
  for step in row['steps']:
   check=plan[step['launch']][step['step']]
   if step['launch']>0:
    reads+=step.get('tools',[]).count('read_web_page');fetches+=len(step.get('fetched',[]))
   if check.get('sources') and step.get('card'):
    cards+=1;labeled+=all(site in step.get('sources',[]) for site in check['sources'])
 assert (len(rows),passed,reads,fetches,cards,labeled)==(expected['recorded'],expected['passed'],expected['resumed_reads'],expected['resumed_fetches'],expected['source_cards'],expected['labeled_source_cards'])
assert len(identities)==len(set(identities))==33
assert set(identities)=={(model,seed,f'personal/source/source-to-approved-mail/{i}') for model in m['models'] for seed in (1,2,7) for i in range(1,5)} | {('Qwen3.5-4B-Q4_K_M',seed,case) for seed in (1,2,7) for case in ['restart/trip','topic/speech','approval/dinner']}
corpus=corpora['source'];cases={c['id']:c for c in corpus['case']}
old_passed=0;old_reads=0
for job in s['baseline']['jobs']:
 rows=[json.loads(line) for line in (root/'baseline'/(job['name']+'.jsonl')).read_text().splitlines()]
 assert digest(root/'baseline'/(job['name']+'.jsonl'))==job['sha256']
 for row in rows:
  old_passed+=assess(cases[row['id']],corpus['filler'],row,job['seed'])['passed']
  old_reads+=sum(step.get('tools',[]).count('read_web_page') for step in row['steps'] if step['launch']>0)
assert (old_passed,old_reads)==(22,2)
cm=json.loads((root/'initial-candidate/manifest.json').read_text());job=cm['jobs'][0]
rows=[json.loads(line) for line in (root/'initial-candidate/rows'/(job['name']+'.jsonl')).read_text().splitlines()]
assert len(rows)==2 and sum(assess(cases[r['id']],corpus['filler'],r,job['seed'])['passed'] for r in rows)==1
assert rows[-1]['steps'][-1]['effects']==2
print('Verified 24/24 source workflows, 9/9 controls, 24 labeled cards and zero resumed reads; baseline and initial failed candidate preserved.')
