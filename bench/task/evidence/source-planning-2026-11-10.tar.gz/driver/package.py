from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys,tarfile,tomllib
ROOT=Path('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3')
OUT=ROOT/'bench/task/result/source-planning-2026-11-10-final'
STEM='source-planning-2026-11-10'
BASE=ROOT/'bench/task/result/source-provenance-2026-11-10-verified'
def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
m=json.loads((OUT/'manifest.json').read_text());finished=json.loads((OUT/'finished.json').read_text())
assert finished['complete'] and finished['recorded']==33
assert all(digest(ROOT/n)==h for n,h in m['source_sha256'].items())
assert all(digest(OUT/n)==h for n,h in m['files'].items())
assert digest(OUT/'source.tar.gz')==m['source_archive_sha256']
validation=OUT/'validation';validation.mkdir(exist_ok=True)
for n in ['before','after','refresh','before-result','mail-tests','workspace','final-workspace','final-clippy','final-format']:
 shutil.copy2(f'/tmp/pr3-source-planning-{n}.log',validation/f'{n}.log')
counts=[tuple(map(int,x)) for x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',(validation/'final-workspace.log').read_text())]
assert tuple(map(sum,zip(*counts)))==(426,0,12)
assert 'FAILED' not in (validation/'final-workspace.log').read_text()
assert 'Finished' in (validation/'final-clippy.log').read_text()
assert not (validation/'final-format.log').read_text().strip()
audit_path=ROOT/'bench/rebaseline/result/2026-11-07/.source-planning-20261110-final-interruption.json'
audit=json.loads(audit_path.read_text());assert audit['exit_code']==0
shutil.copy2(audit_path,validation/'historical-resume.json')
shutil.copy2('/tmp/pr3-source-planning-isolated.py',OUT/'driver/isolate.py')
shutil.copy2(__file__,OUT/'driver/package.py')
sys.path.insert(0,str(OUT/'driver'))
from score import assess,expand,says
corpora={n:tomllib.loads((OUT/'data'/(n+'.toml')).read_text()) for n in ['source','compatibility']}
def summarize(job,rows):
 corpus=corpora[job['corpus']];cases={c['id']:c for c in corpus['case']}
 counts=dict(recorded=len(rows),passed=0,leaked=0,errors=0,source_cards=0,labeled_source_cards=0,resumed_reads=0,resumed_fetches=0)
 failures=[];violations=[]
 for row in rows:
  v=assess(cases[row['id']],corpus['filler'],row,job['seed'])
  counts['passed']+=v['passed'];counts['leaked']+=v['leaked'];counts['errors']+=v['error']
  if not v['passed']:failures.append({'job':job['name'],'case':row['id'],'verdict':v,'steps':row['steps']})
  plan=expand(cases[row['id']],corpus['filler'])
  for step in row['steps']:
   check=plan[step['launch']][step['step']]
   if step['launch']>0:
    counts['resumed_reads']+=step.get('tools',[]).count('read_web_page')
    counts['resumed_fetches']+=len(step.get('fetched',[]))
   if check.get('sources') and step.get('card'):
    counts['source_cards']+=1
    counts['labeled_source_cards']+=all(site in step.get('sources',[]) for site in check['sources'])
   for field,key in [('card','card_excludes'),('sent','unsent')]:
    for value in check.get(key,[]):
     if step.get(field) and says(step[field],value):violations.append({'job':job['name'],'case':row['id'],'field':field,'value':value})
 return counts,failures,violations
results=[];failures=[];violations=[];identities=[]
for job in m['jobs']:
 path=OUT/'rows'/(job['name']+'.jsonl');rows=[json.loads(s) for s in path.read_text().splitlines()]
 assert [r['id'] for r in rows]==job['cases']
 identities.extend((job['model'],job['seed'],case) for case in job['cases'])
 c,f,v=summarize(job,rows);results.append({**job,**c});failures+=f;violations+=v
 assert json.loads(path.with_suffix('.manifest.json').read_text())=={'harness':5,'model_sha256':m['models'][job['model']]['sha256'],'binary_sha256':m['files']['bin/pr3-bench-task'],'corpus_sha256':digest(OUT/'data'/(job['corpus']+'.toml')),'seed':job['seed'],'web':True,'cases':job['cases']}
assert len(identities)==len(set(identities))==33
assert set(identities)=={(model,seed,f'personal/source/source-to-approved-mail/{i}') for model in m['models'] for seed in (1,2,7) for i in range(1,5)} | {('Qwen3.5-4B-Q4_K_M',seed,case) for seed in (1,2,7) for case in ['restart/trip','topic/speech','approval/dinner']}
for a,b in zip(results,finished['jobs']):assert all(a[k]==v for k,v in b.items())
keys=['recorded','passed','leaked','errors','source_cards','labeled_source_cards','resumed_reads','resumed_fetches']
totals={k:sum(r[k] for r in results) for k in keys}
assert totals==dict(recorded=33,passed=33,leaked=0,errors=0,source_cards=24,labeled_source_cards=24,resumed_reads=0,resumed_fetches=0),totals
assert not failures and not violations
old=json.loads((BASE/'manifest.json').read_text())
assert digest(OUT/'data/source.toml')==digest(BASE/'data/source.toml')
assert digest(OUT/'driver/score.py')==digest(BASE/'driver/score.py')
assert m['source_sha256']['bench/task/corpus.toml']==old['source_sha256']['bench/task/corpus.toml']
baseline=OUT/'baseline';baseline.mkdir(exist_ok=True)
oldresults=[]
for job in old['jobs']:
 src=BASE/'rows'/(job['name']+'.jsonl');shutil.copy2(src,baseline/src.name)
 rows=[json.loads(s) for s in src.read_text().splitlines()]
 c,f,v=summarize(job,rows);oldresults.append({**job,**c,'failures':f,'original_path':str(src.relative_to(ROOT)),'sha256':digest(src)})
assert sum(j['passed'] for j in oldresults)==22
assert sum(j['resumed_reads'] for j in oldresults)==2
unchanged=[n for n in old['source_sha256'] if n.startswith('crate/pr3-core/src/')]
unchanged+=['crate/pr3-llamacpp/src/lib.rs','app/pr3-app/src-tauri/src/host.rs','app/pr3-app/src-tauri/src/actions.rs','app/pr3-app/src-tauri/src/config.rs','app/pr3-app/src-tauri/src/task/source.rs','bench/task/src/main.rs']
assert all(m['source_sha256'][n]==old['source_sha256'][n] for n in unchanged)
# The runtime result handler only gained tests; initial planner instructions are checked below.
with tarfile.open(BASE/'source.tar.gz') as archive:
 for n in ['app/pr3-app/src-tauri/src/task/result.rs']:
  before=archive.extractfile(n).read().split(b'#[cfg(test)]')[0]
  after=(ROOT/n).read_bytes().split(b'#[cfg(test)]')[0]
  assert before==after,n
candidate=ROOT/'bench/task/result/source-planning-2026-11-10'
failed=OUT/'initial-candidate'
shutil.copytree(candidate,failed,dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','__pycache__','running.json'))
shutil.copy2(ROOT/'bench/rebaseline/result/2026-11-07/.source-planning-20261110-interruption.json',failed/'historical-resume.json')
shutil.copy2('/tmp/pr3-source-planning-evaluation.log',failed/'runner.log')
cm=json.loads((failed/'manifest.json').read_text());cj=cm['jobs'][0]
cr=[json.loads(line) for line in (failed/'rows'/(cj['name']+'.jsonl')).read_text().splitlines()]
cc,cf,cv=summarize(cj,cr)
assert cc['recorded']==2 and cc['passed']==1 and cc['resumed_reads']==0
assert len(cf)==1 and cf[0]['case'].endswith('/4') and cr[-1]['steps'][-1]['effects']==2
assert json.loads((failed/'historical-resume.json').read_text())['exit_code']==2
with tarfile.open(BASE/'source.tar.gz') as archive:
 for n,start,end in [('app/pr3-app/src-tauri/src/llama/mail.rs','const PROMPT:','pub(super) struct Plan'),('app/pr3-app/src-tauri/src/llama.rs','const SYSTEM_PROMPT:','pub struct LlamaBackend')]:
  oldtext=archive.extractfile(n).read().decode();newtext=(ROOT/n).read_text()
  assert oldtext[oldtext.index(start):oldtext.index(end)]==newtext[newtext.index(start):newtext.index(end)]
summary={'status':'completed resumed-source planning regression','complete':True,'finished_at_utc':finished['finished_at'],'base_commit':m['base_commit'],'totals':totals,'jobs':results,'failures':failures,'forbidden_card_or_outbox_content':violations,
 'initial_candidate':{'recorded':2,'passed':1,'resumed_reads':0,'duplicate_effect_case':cf[0]['case'],'reason':'Routing fixed both rereads, but post-result general planning proposed a second email in case 4. The scripted approver approved both; two sandbox effects failed the unchanged oracle. Final build uses the existing protected tool-free answer pass after an email attempt.'},
 'baseline':{'recorded':24,'passed':22,'resumed_reads':2,'inputs_and_checks_unchanged':True,'jobs':oldresults},'models':m['models'],'manifest_sha256':digest(OUT/'manifest.json'),'binary_sha256':m['files']['bin/pr3-bench-task'],
 'validation':{'workspace':{'passed':426,'failed':0,'ignored':12},'new_regressions':6,'before_fix':'Four routing/restart/status regressions failed before prefix handling, and a post-email tool-offer regression failed before finalization changed.','clippy':'pass','format':'pass'},
 'unchanged_core_host_approval_limits_and_engine':{n:m['source_sha256'][n] for n in unchanged},'historical_matrix_resumed':audit,
 'limits':['Known Personal-200 v2 cases reused as regression evidence, not fresh held-out accuracy. No inputs/checks or original results were changed.','The two observed failures ran first; each final-build model/seed/case combination ran once, with no same-build score-improving retries. The initial 1/2 candidate and its duplicate sandbox effect are retained separately.','Routing recognizes bounded direct English requests with leading Now or Now, and up to two supported introductory phrases. It is not general multilingual intent recognition.','The existing planner can still request a needed lookup or clarification; these cases demonstrate reuse of available details, not a general prohibition on rereading.','An explicit refresh still executes through normal read guards; a source-reading turn cannot request consequential actions. A new user request and fresh approval remain necessary.','No tool history, source bodies, trust flags or approval receipts are replayed after restart. Source metadata remains visible on the card.','Desktop sandbox checks do not certify Android handoff, real delivery or physical-device continuity.','The older frozen historical matrix resumed separately and does not certify this current build.']}
write(OUT/'summary.json',summary)
replay='''from pathlib import Path
import hashlib,json,sys,tomllib
from score import assess,expand
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name,expected in json.loads((root/'inventory.json').read_text()).items():assert digest(root/name)==expected,name
m=json.loads((root/'manifest.json').read_text());s=json.loads((root/'summary.json').read_text())
corpora={n:tomllib.loads((root/'data'/(n+'.toml')).read_text()) for n in ['source','compatibility']}
identities=[]
for job,expected in zip(m['jobs'],s['jobs']):
 corpus=corpora[job['corpus']];cases={c['id']:c for c in corpus['case']}
 path=root/'rows'/(job['name']+'.jsonl');rows=[json.loads(line) for line in path.read_text().splitlines()]
 assert [r['id'] for r in rows]==job['cases']
 identities.extend((job['model'],job['seed'],case) for case in job['cases'])
 assert json.loads(path.with_suffix('.manifest.json').read_text())=={'harness':5,'model_sha256':m['models'][job['model']]['sha256'],'binary_sha256':m['files']['bin/pr3-bench-task'],'corpus_sha256':digest(root/'data'/(job['corpus']+'.toml')),'seed':job['seed'],'web':True,'cases':job['cases']}
 passed=0;reads=0;fetches=0;cards=0;labeled=0
 for row in rows:
  v=assess(cases[row['id']],corpus['filler'],row,job['seed']);passed+=v['passed']
  assert v['passed'] and not v['leaked'] and not v['error']
  plan=expand(cases[row['id']],corpus['filler'])
  for step in row['steps']:
   check=plan[step['launch']][step['step']]
   if step['launch']>0:
    reads+=step.get('tools',[]).count('read_web_page');fetches+=len(step.get('fetched',[]))
   if check.get('sources') and step.get('card'):
    cards+=1;labeled+=all(site in step.get('sources',[]) for site in check['sources'])
 assert (len(rows),passed,reads,fetches,cards,labeled)==(expected['recorded'],expected['passed'],expected['resumed_reads'],expected['resumed_fetches'],expected['source_cards'],expected['labeled_source_cards'])
assert len(identities)==len(set(identities))==33
assert set(identities)=={(model,seed,f'personal/source/source-to-approved-mail/{i}') for model in m['models'] for seed in (1,2,7) for i in range(1,5)} | {('Qwen3.5-4B-Q4_K_M',seed,case) for seed in (1,2,7) for case in ['restart/trip','topic/speech','approval/dinner']}
corpus=corpora['source'];cases={c['id']:c for c in corpus['case']}
old_passed=0;old_reads=0
for job in s['baseline']['jobs']:
 rows=[json.loads(line) for line in (root/'baseline'/(job['name']+'.jsonl')).read_text().splitlines()]
 assert digest(root/'baseline'/(job['name']+'.jsonl'))==job['sha256']
 for row in rows:
  old_passed+=assess(cases[row['id']],corpus['filler'],row,job['seed'])['passed']
  old_reads+=sum(step.get('tools',[]).count('read_web_page') for step in row['steps'] if step['launch']>0)
assert (old_passed,old_reads)==(22,2)
cm=json.loads((root/'initial-candidate/manifest.json').read_text());job=cm['jobs'][0]
rows=[json.loads(line) for line in (root/'initial-candidate/rows'/(job['name']+'.jsonl')).read_text().splitlines()]
assert len(rows)==2 and sum(assess(cases[r['id']],corpus['filler'],r,job['seed'])['passed'] for r in rows)==1
assert rows[-1]['steps'][-1]['effects']==2
print('Verified 24/24 source workflows, 9/9 controls, 24 labeled cards and zero resumed reads; baseline and initial failed candidate preserved.')
'''
(OUT/'driver/replay.py').write_text(replay)
files=[p for p in OUT.rglob('*') if p.is_file() and p.relative_to(OUT).parts[0]!='bin' and '__pycache__' not in p.parts and p.name not in ['inventory.json','running.json']]
write(OUT/'inventory.json',{str(p.relative_to(OUT)):digest(p) for p in sorted(files)})
files.append(OUT/'inventory.json')
subprocess.run([sys.executable,str(OUT/'driver/replay.py'),str(OUT)],check=True)
archive=ROOT/'bench/task/evidence'/(STEM+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(OUT)))
summary['portable_archive']={'path':str(archive.relative_to(ROOT)),'sha256':digest(archive)}
write(ROOT/'bench/task/evidence'/(STEM+'.json'),summary)
print('Packaged',archive)
