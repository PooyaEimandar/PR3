from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, signal, subprocess, sys, tarfile, time, tomllib

ROOT = Path('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3')
OUT = ROOT / 'bench/task/result/planning-status-2026-11-10'
sys.path.insert(0, str(ROOT / 'bench/personal'))
from run import environment, sources, stop
from score import assess

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def now():
    return datetime.now(timezone.utc).isoformat()

assert not OUT.exists(), 'Keep prior runs immutable'
OUT.mkdir(parents=True)
for name in ('bin', 'data', 'rows', 'logs', 'driver'):
    (OUT / name).mkdir()
hashes = {name: digest(ROOT / name) for name in sources()}
with (OUT / 'logs/build.log').open('w') as log:
    subprocess.run(['cargo', 'build', '--release', '-p', 'pr3-bench-task', '-p', 'pr3-bench-agentdojo', '--locked'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
assert all(digest(ROOT / name) == h for name, h in hashes.items())
shutil.copy2(ROOT / 'target/release/pr3-bench-task', OUT / 'bin/pr3-bench-task')
shutil.copy2(ROOT / 'target/release/pr3-bench-agentdojo', OUT / 'bin/pr3-bench-agentdojo')
for name in ('score.py', 'run.py', 'dataset.py'):
    shutil.copy2(ROOT / 'bench/personal' / name, OUT / 'driver' / name)
shutil.copy2(__file__, OUT / 'driver/evaluate.py')
shutil.copy2(ROOT / 'bench/personal/v2/development.toml', OUT / 'data/removal.toml')
shutil.copy2(ROOT / 'bench/task/email-exclusions.toml', OUT / 'data/supplementary.toml')
shutil.copy2(ROOT / 'bench/task/corpus.toml', OUT / 'data/compatibility.toml')
with tarfile.open(OUT / 'source.tar.gz', 'w:gz') as archive:
    for name in hashes:
        archive.add(ROOT / name, arcname=name)
models = {}
for name in ('Qwen3.8-27B-Q4_K_M', 'Qwen3.5-4B-Q4_K_M'):
    path = ROOT / 'model' / (name + '.gguf')
    models[name] = {'path': str(path), 'sha256': digest(path)}
jobs = []
for corpus, cases in (
    ('removal', [f'personal/approval/remove-sensitive-detail/{i}' for i in range(1,5)]),
    ('supplementary', ['email-exclusions/quoted-restart', 'email-exclusions/field-restart', 'email-exclusions/new-task']),
):
    for model in models:
        for seed in (1,2,7):
            jobs.append({'name':f'{corpus}-{model}-seed{seed}', 'corpus':corpus, 'model':model, 'seed':seed, 'cases':cases})
for seed in (1,2,7):
    model='Qwen3.5-4B-Q4_K_M'
    jobs.append({'name':f'compatibility-{model}-seed{seed}', 'corpus':'compatibility', 'model':model, 'seed':seed, 'cases':['restart/trip','topic/speech','approval/dinner']})
# Run each of the six observed failures first, then the remaining controls once.
targets = [
 ('supplementary', 'Qwen3.5-4B-Q4_K_M', 2, 'email-exclusions/new-task'),
 ('supplementary', 'Qwen3.5-4B-Q4_K_M', 7, 'email-exclusions/new-task'),
 ('compatibility', 'Qwen3.5-4B-Q4_K_M', 2, 'topic/speech'),
 ('removal', 'Qwen3.8-27B-Q4_K_M', 1, 'personal/approval/remove-sensitive-detail/2'),
 ('removal', 'Qwen3.8-27B-Q4_K_M', 7, 'personal/approval/remove-sensitive-detail/2'),
 ('supplementary', 'Qwen3.8-27B-Q4_K_M', 1, 'email-exclusions/quoted-restart'),
]
first=[]
for n,(corpus,model,seed,case) in enumerate(targets,1):
 job=next(j for j in jobs if (j['corpus'],j['model'],j['seed'])==(corpus,model,seed))
 assert case in job['cases']
 job['cases'].remove(case)
 first.append({'name':f'failure{n}-{model}-seed{seed}', 'corpus':corpus,'model':model,'seed':seed,'cases':[case]})
jobs=first+[j for j in jobs if j['cases']]
planned = sum(len(j['cases']) for j in jobs)
assert planned == 51
manifest = {'created_at': now(), 'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'source_sha256': hashes, 'environment': environment(), 'models': models, 'jobs': jobs,
            'files': {str(p.relative_to(OUT)): digest(p) for directory in ('bin', 'data', 'driver') for p in (OUT / directory).iterdir()},
            'source_archive_sha256': digest(OUT / 'source.tar.gz'),
            'policy': 'Focused regression using unchanged inputs/checks from the previous 45/51 email exclusion build. New structured unapproved email planning and truthful status; existing protected answer fallback after repeated read-only plans. Approval, exclusions and execution/round/call/token limits unchanged. All failures preserved, no same-build retries to improve scores. Not fresh held-out evidence.'}
write('manifest.json', manifest)
results = []
for job in jobs:
    path = OUT / 'rows' / (job['name'] + '.jsonl')
    corpus_path = OUT / 'data' / (job['corpus'] + '.toml')
    command = [str(OUT / 'bin/pr3-bench-task'), 'run', '--model', models[job['model']]['path'],
               '--corpus', str(corpus_path), '--seed', str(job['seed']), '--out', str(path)]
    for case in job['cases']:
        command += ['--case', case]
    print('Starting ' + job['name'], flush=True)
    with (OUT / 'logs' / (job['name'] + '.log')).open('w') as log:
        child = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        write('running.json', {'job': job, 'runner_pid': os.getpid(), 'child_pid': child.pid, 'command': command})
        try:
            child.wait()
        finally:
            stop(child)
        assert child.returncode == 0, 'Preserve a failed harness job for inspection'
    corpus = tomllib.loads(corpus_path.read_text())
    cases = {c['id']: c for c in corpus['case']}
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    assert [row['id'] for row in rows] == job['cases']
    identity = json.loads(path.with_suffix('.manifest.json').read_text())
    assert identity == {'harness': 5, 'model_sha256': models[job['model']]['sha256'],
                        'binary_sha256': manifest['files']['bin/pr3-bench-task'],
                        'corpus_sha256': digest(corpus_path), 'seed': job['seed'], 'web': True, 'cases': job['cases']}
    verdicts = [assess(cases[row['id']], corpus['filler'], row, job['seed']) for row in rows]
    results.append({**job, 'recorded': len(rows), 'passed': sum(v['passed'] for v in verdicts),
                    'leaked': sum(v['leaked'] for v in verdicts), 'errors': sum(v['error'] for v in verdicts)})
    write('progress.json', {'complete': len(results) == len(jobs), 'planned': planned, 'recorded': sum(r['recorded'] for r in results), 'jobs': results})
    print(json.dumps(results[-1]), flush=True)
    if len(results) <= 6 and results[-1]['passed'] != results[-1]['recorded']:
        write('interrupted.json', {'at':now(),'reason':'A previously failing case still fails; preserve candidate before inspecting or changing code.','results':results})
        raise SystemExit(2)
assert all(digest(ROOT / name) == h for name, h in hashes.items())
write('finished.json', {'finished_at': now(), 'complete': True, 'recorded': planned, 'jobs': results})
