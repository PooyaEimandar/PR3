"""Replay raw observations without loading a model: python3 driver/replay.py ."""
from pathlib import Path
import hashlib,json,sys,tarfile,tomllib
from score import assess
root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1])
def digest(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
manifest=json.loads((root/'manifest.json').read_text())
assert digest(root/'source.tar.gz')==manifest['source_archive_sha256']
with tarfile.open(root/'source.tar.gz') as archive:
 for name,expected in manifest['source_sha256'].items():
  assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==expected,name
for name,expected in manifest['files'].items():
 if name.startswith('bin/'):continue # Executable omitted; identity is pinned in each row manifest.
 assert digest(root/name)==expected,name
results=[]
for job in manifest['jobs']:
 corpus_path=root/'data'/(job['corpus']+'.toml')
 corpus=tomllib.loads(corpus_path.read_text())
 cases={c['id']:c for c in corpus['case']}
 path=root/'rows'/(job['name']+'.jsonl')
 rows=[json.loads(line) for line in path.read_text().splitlines()]
 assert [r['id'] for r in rows]==job['cases']
 identity=json.loads(path.with_suffix('.manifest.json').read_text())
 assert identity=={'harness':5,'model_sha256':manifest['models'][job['model']]['sha256'],'binary_sha256':manifest['files']['bin/pr3-bench-task'],'corpus_sha256':digest(corpus_path),'seed':job['seed'],'web':True,'cases':job['cases']}
 verdicts=[assess(cases[row['id']],corpus['filler'],row,job['seed']) for row in rows]
 results.append({**job,'recorded':len(rows),'passed':sum(v['passed'] for v in verdicts),'leaked':sum(v['leaked'] for v in verdicts),'errors':sum(v['error'] for v in verdicts)})
assert results==json.loads((root/'finished.json').read_text())['jobs']
print(json.dumps({key:sum(j[key] for j in results) for key in ['recorded','passed','leaked','errors']},indent=2))

import ast,re
security=root/'security'
namespace={'__name__':'replay_checks','__file__':str(security/'answer_regression.py')}
version=int(re.search(r'HARNESS_VERSION = (\d+)',(security/'run.py').read_text()).group(1))
namespace['HARNESS_VERSION']=version
tree=ast.parse((security/'answer_regression.py').read_text())
tree.body=[node for node in tree.body if not (isinstance(node,ast.ImportFrom) and node.module=='run') and not (isinstance(node,ast.FunctionDef) and node.name=='main') and not isinstance(node,ast.If)]
exec(compile(tree,'answer_regression.py','exec'),namespace)
travel=[json.loads(line) for seed in (1,2,7) for line in (security/'travel'/f'seed{seed}.jsonl').read_text().splitlines()]
assert len(travel)==12
assert not namespace['check_rows'](travel)
answers=json.loads((security/'source-boundaries.json').read_text())
assert len(answers)==21 and len({(r['id'],r['seed']) for r in answers})==21 and all(r['passed'] for r in answers)
for name,expected in json.loads((root/'inventory.json').read_text()).items():
 assert digest(root/name)==expected,name
print('Security checks: travel 12/12, source boundaries 21/21; artifact inventory verified.')
