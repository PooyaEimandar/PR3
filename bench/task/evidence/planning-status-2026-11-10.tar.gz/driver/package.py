from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys,tarfile,tomllib
ROOT=Path('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3')
OUT=ROOT/'bench/task/result/planning-status-2026-11-10'
STEM='planning-status-2026-11-10'
EVIDENCE=ROOT/'bench/task/evidence'
def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
manifest=json.loads((OUT/'manifest.json').read_text())
finished=json.loads((OUT/'finished.json').read_text())
assert finished['complete'] and finished['recorded']==51
assert all(digest(ROOT/n)==h for n,h in manifest['source_sha256'].items())
assert all(digest(OUT/n)==h for n,h in manifest['files'].items())
assert sum(j['passed'] for j in finished['jobs'])==51
validation=OUT/'validation';validation.mkdir(exist_ok=True)
for name in ['before-status','before-plan','after-status','after-plan','app-tests','engine-tests','final-workspace','final-clippy','format']:
 shutil.copy2(Path('/tmp')/f'pr3-planning-status-{name}.log',validation/f'{name}.log')
for name in ['planning-status-20261110','planning-status-20261110-verified']:
 path=ROOT/f'bench/rebaseline/result/2026-11-07/.{name}-interruption.json'
 shutil.copy2(path,validation/f'{name}-historical-resume.json')
audit=json.loads((validation/'planning-status-20261110-verified-historical-resume.json').read_text())
assert audit['exit_code']==0
for name in ['eval','isolate','runall']:
 source='isolated' if name=='isolate' else name
 shutil.copy2(f'/tmp/pr3-planning-status-{source}.py',OUT/'driver'/f'{name}.py')
shutil.copy2(__file__,OUT/'driver/package.py')
# Preserve the setup failure (before any inference), including the exact bad driver
# and error/audit. No product source or model observation changed between launches.
failed=ROOT/'bench/task/result/planning-status-2026-11-10-setup-failed'
setup=OUT/'setup-failure';setup.mkdir(exist_ok=True)
for name in ['setup-error.log','setup-error.json','driver/evaluate.py','logs/build.log','source.tar.gz']:
 target=setup/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(failed/name,target)
with tarfile.open(setup/'source.tar.gz') as archive:
 for name,expected in manifest['source_sha256'].items():
  assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==expected,name
for name in ['answer_regression.py','run.py']:
 shutil.copy2(ROOT/'bench/agentdojo'/name,OUT/'security'/name)
counts=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (validation/'final-workspace.log').read_text())]
assert tuple(map(sum,zip(*counts)))==(409,0,12)
assert 'test result: FAILED' not in (validation/'final-workspace.log').read_text()
assert 'Finished' in (validation/'final-clippy.log').read_text()
assert all(c['exit_code']==0 for c in json.loads((OUT/'security/checks.json').read_text()))
answers=[json.loads(line.split('ANSWER_REGRESSION ',1)[1]) for line in (OUT/'security/source-boundaries.log').read_text().splitlines() if line.startswith('ANSWER_REGRESSION ')]
assert len(answers)==21 and all(r['passed'] for r in answers)
write(OUT/'security/source-boundaries.json',answers)
sys.path.insert(0,str(OUT/'driver'))
from score import assess,expand,says
violations=[];failures=[];results=[]
for job in manifest['jobs']:
 corpus=tomllib.loads((OUT/'data'/(job['corpus']+'.toml')).read_text());cases={c['id']:c for c in corpus['case']}
 rows=[json.loads(line) for line in (OUT/'rows'/(job['name']+'.jsonl')).read_text().splitlines()]
 assert [r['id'] for r in rows]==job['cases']
 verdicts=[]
 for row in rows:
  case=cases[row['id']];v=assess(case,corpus['filler'],row,job['seed']);verdicts.append(v)
  if not v['passed']:failures.append({'job':job['name'],'case':row['id'],'verdict':v,'steps':row['steps']})
  plan=expand(case,corpus['filler'])
  for step in row['steps']:
   check=plan[step['launch']][step['step']]
   for field,key in [('card','card_excludes'),('sent','unsent')]:
    for value in check.get(key,[]):
     if step.get(field) and says(step[field],value):violations.append({'job':job['name'],'case':row['id'],'field':field,'value':value})
 results.append({**job,'recorded':len(rows),'passed':sum(v['passed'] for v in verdicts),'leaked':sum(v['leaked'] for v in verdicts),'errors':sum(v['error'] for v in verdicts)})
assert results==finished['jobs'] and not violations and not failures
baseline=ROOT/'bench/task/evidence/email-exclusion-2026-11-10.json'
unchanged=['crate/pr3-core/src/runtime.rs','crate/pr3-core/src/trusted/gate.rs','app/pr3-app/src-tauri/src/actions.rs','app/pr3-app/src-tauri/src/config.rs','app/pr3-app/src-tauri/src/host.rs']
old=json.loads((ROOT/'bench/task/result/email-exclusion-verified-2026-11-10/manifest.json').read_text())
def combinations(m):return [(j['corpus'],j['model'],j['seed'],case) for j in m['jobs'] for case in j['cases']]
assert len(combinations(manifest))==len(set(combinations(manifest)))==51
assert set(combinations(manifest))==set(combinations(old))
for name in ['data/removal.toml','data/supplementary.toml','data/compatibility.toml','driver/score.py']:
 assert manifest['files'][name]==old['files'][name]
assert all(manifest['source_sha256'][n]==old['source_sha256'][n] for n in unchanged)
summary={'status':'completed focused planning/status regression','complete':True,'finished_at_utc':finished['finished_at'],'base_commit':manifest['base_commit'],'run_manifest_sha256':digest(OUT/'manifest.json'),'binary_sha256':manifest['files']['bin/pr3-bench-task'],'models':manifest['models'],
 'recorded':51,'passed':51,'runtime_errors':0,'forbidden_card_or_outbox_content':violations,'failures':failures,'jobs':results,
 'baseline':{'path':str(baseline.relative_to(ROOT)),'sha256':digest(baseline),'passed':45,'recorded':51,'failures_fixed':6,'inputs_and_checks_unchanged':True},
 'validation':{'workspace':{'passed':409,'failed':0,'ignored':12,'command':'cargo test --workspace --locked'},'new_regressions':14,'before_fix':'Two deterministic reproductions failed before production edits; logs retained.','clippy':'cargo clippy --workspace --all-targets --locked -- -D warnings: pass','format':'cargo fmt --all -- --check: pass','source_boundaries':{'passed':21,'recorded':21},'travel':{'passed':12,'recorded':12,'successful_attacks':0,'attack_cases':6}},
 'unchanged_approval_and_execution_sources':{n:manifest['source_sha256'][n] for n in unchanged},'historical_matrix_resumed':audit,
 'limits':['Focused regression on known failures, not fresh held-out accuracy. Frozen Personal-200 corpora and previous evidence remain unchanged.','Bounded direct-English request routing selects a format; other wording uses the existing planner. This does not add general multilingual email exclusion support.','Structured output validates nonempty fields, not semantic correctness. Exact approved content and recipients still require user review.','The structured planning path does not re-enter after an attempted email in the same user turn; existing outcome handling and approval checks remain in charge. It may propose an offered read-only lookup before a draft, within the existing execution limits.','The repeated-read fallback uses the existing protected answer pass with no added execution or budget; mixed/repeated actions remain subject to original guards.','The speech control passes its unchanged no-error/recall checks, but its first reply still asks unnecessary clarifying questions.','Desktop sandbox effects and deterministic device-adapter tests do not prove Android mail-app handoff or delivery.','The separately frozen historical matrix resumed unchanged; it predates these fixes and does not certify this build.'],
 'setup_failure':'A shared mutable job list caused setup to fail before inference. The bad driver, error and resume audit are preserved; a per-job list copy corrected the evaluator without changing product code or checks.'}
write(OUT/'summary.json',summary)
# Portable replay uses the unchanged task scorer and the original travel-check
# function AST, avoiding AgentDojo installation/network just to check recorded rows.
replay=(ROOT/'bench/task/result/email-exclusion-verified-2026-11-10/driver/replay.py').read_text()
replay += '''\nimport ast,re\nsecurity=root/'security'\nnamespace={'__name__':'replay_checks','__file__':str(security/'answer_regression.py')}\nversion=int(re.search(r'HARNESS_VERSION = (\\d+)',(security/'run.py').read_text()).group(1))\nnamespace['HARNESS_VERSION']=version\ntree=ast.parse((security/'answer_regression.py').read_text())\ntree.body=[node for node in tree.body if not (isinstance(node,ast.ImportFrom) and node.module=='run') and not (isinstance(node,ast.FunctionDef) and node.name=='main') and not isinstance(node,ast.If)]\nexec(compile(tree,'answer_regression.py','exec'),namespace)\ntravel=[json.loads(line) for seed in (1,2,7) for line in (security/'travel'/f'seed{seed}.jsonl').read_text().splitlines()]\nassert len(travel)==12\nassert not namespace['check_rows'](travel)\nanswers=json.loads((security/'source-boundaries.json').read_text())\nassert len(answers)==21 and len({(r['id'],r['seed']) for r in answers})==21 and all(r['passed'] for r in answers)\nfor name,expected in json.loads((root/'inventory.json').read_text()).items():\n assert digest(root/name)==expected,name\nprint('Security checks: travel 12/12, source boundaries 21/21; artifact inventory verified.')\n'''
(OUT/'driver/replay.py').write_text(replay)
portable=[]
for p in OUT.rglob('*'):
 if p.is_file() and not p.relative_to(OUT).parts[0]=='bin' and '__pycache__' not in p.parts and p.name not in ['inventory.json','running.json']:
  portable.append(p)
write(OUT/'inventory.json',{str(p.relative_to(OUT)):digest(p) for p in sorted(portable)})
portable.append(OUT/'inventory.json')
subprocess.run([sys.executable,str(OUT/'driver/replay.py'),str(OUT)],check=True)
archive=EVIDENCE/(STEM+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for path in sorted(portable):tar.add(path,arcname=str(path.relative_to(OUT)))
summary['portable_archive']={'path':str(archive.relative_to(ROOT)),'sha256':digest(archive)}
write(EVIDENCE/(STEM+'.json'),summary)
print('Packaged',archive)
