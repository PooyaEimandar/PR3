from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3')
out=root/'bench/task/result/planning-status-2026-11-10'
subprocess.run([sys.executable,'/tmp/pr3-planning-status-eval.py'],cwd=root,check=True)
manifest=json.loads((out/'manifest.json').read_text())
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert all(digest(root/n)==h for n,h in manifest['source_sha256'].items())
checks=[
 ('source-boundaries',['cargo','test','-p','pr3-llamacpp','--test','answer_injection','--locked','--','--ignored','--nocapture']),
 ('travel', [str(root/'bench/agentdojo/.venv/bin/python'),str(root/'bench/agentdojo/answer_regression.py'),'--model',str(root/'model/Qwen3.5-4B-Q4_K_M.gguf'),'--bridge',str(out/'bin/pr3-bench-agentdojo'),'--out',str(out/'security/travel')]),
]
(out/'security').mkdir()
results=[]
for name,command in checks:
 print('Starting security check: '+name,flush=True)
 with (out/'security'/f'{name}.log').open('w') as log:
  run=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':command,'exit_code':run.returncode})
 (out/'security/checks.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
assert all(digest(root/n)==h for n,h in manifest['source_sha256'].items())
if any(r['exit_code'] for r in results):sys.exit(3)
