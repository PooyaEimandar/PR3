from pathlib import Path
import hashlib,json,sys,tomllib
from score import assess
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name,h in json.loads((root/'inventory.json').read_text()).items():assert digest(root/name)==h,name
m=json.loads((root/'manifest.json').read_text());summary=json.loads((root/'summary.json').read_text())
identities=[];passed=0
for job in m['jobs']:
 corpus=tomllib.loads((root/'data'/(job['corpus']+'.toml')).read_text());cases={c['id']:c for c in corpus['case']}
 path=root/'rows'/(job['name']+'.jsonl');rows=[json.loads(s) for s in path.read_text().splitlines()]
 assert [r['id'] for r in rows]==job['cases']
 assert json.loads(path.with_suffix('.manifest.json').read_text())=={'harness':5,'model_sha256':m['models'][job['model']]['sha256'],'binary_sha256':m['files']['bin/pr3-bench-task'],'corpus_sha256':digest(root/'data'/(job['corpus']+'.toml')),'seed':job['seed'],'web':True,'cases':job['cases']}
 for row in rows:
  verdict=assess(cases[row['id']],corpus['filler'],row,job['seed']);assert verdict['passed'] and not verdict['leaked'] and not verdict['error']
  passed+=1;identities.append((job['model'],job['seed'],row['id']))
assert passed==len(identities)==len(set(identities))==45
assert {seed for _,seed,_ in identities}=={1,2,7}
initial=root/'initial-candidate';corpus=tomllib.loads((initial/'data/semantic.toml').read_text());cases={c['id']:c for c in corpus['case']}
rows=[json.loads(s) for p in (initial/'rows').glob('*.jsonl') for s in p.read_text().splitlines()]
assert len(rows)==summary['initial_candidate']['recorded']
assert sum(assess(cases[r['id']],corpus['filler'],r,r['seed'])['passed'] for r in rows)==summary['initial_candidate']['passed']
for folder,key in [('v1-candidate','v1_candidate'),('reinclusion-candidate','reinclusion_candidate'),('context-candidate','context_candidate')]:
 candidate=root/folder;vm=json.loads((candidate/'manifest.json').read_text());count=passed=0
 for job in vm['jobs']:
  path=candidate/'rows'/(job['name']+'.jsonl')
  if not path.exists():continue
  corpus=tomllib.loads((candidate/'data'/(job['corpus']+'.toml')).read_text());cases={c['id']:c for c in corpus['case']}
  for line in path.read_text().splitlines():
   row=json.loads(line);count+=1;passed+=assess(cases[row['id']],corpus['filler'],row,job['seed'])['passed']
 assert (count,passed)==(summary[key]['recorded'],summary[key]['passed'])
print('Verified 27/27 multilingual development workflows and 18/18 unchanged controls; all four partial candidates and their original failures preserved.')
