from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys,tarfile,tomllib
ROOT=Path('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3')
OUT=ROOT/'bench/task/result/semantic-email-2026-11-10-body'
STEM='semantic-email-2026-11-10'
def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
m=json.loads((OUT/'manifest.json').read_text());f=json.loads((OUT/'finished.json').read_text())
assert f['complete'] and f['recorded']==45
assert all(digest(ROOT/n)==h for n,h in m['source_sha256'].items())
assert all(digest(OUT/n)==h for n,h in m['files'].items())
assert digest(OUT/'source.tar.gz')==m['source_archive_sha256']
v=OUT/'validation';v.mkdir(exist_ok=True)
for name in ['before','boundaries-before','reinclude-before','reinclude-after','duplicates-before','legacy-duplicates-before','v2-workspace','v2-clippy','v2-format','v2-python','reinclude-note-before','reinclude-note-after','verified-workspace','verified-clippy','verified-format','context-before','body-final-workspace','body-final-clippy','body-final-format']:
 shutil.copy2(f'/tmp/pr3-semantic-mail-{name}.log',v/(name+'.log'))
counts=[tuple(map(int,x)) for x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',(v/'body-final-workspace.log').read_text())]
assert tuple(map(sum,zip(*counts)))==(443,0,12)
assert len([line for line in (v/'body-final-workspace.log').read_text().splitlines() if 'semantic_exclusions_' in line and line.endswith(' ... ok')])==17
assert 'Ran 21 tests' in (v/'v2-python.log').read_text() and (v/'v2-python.log').read_text().strip().endswith('OK')
assert 'Finished' in (v/'body-final-clippy.log').read_text()
assert not (v/'body-final-format.log').read_text().strip()
audit_path=ROOT/'bench/rebaseline/result/2026-11-07/.semantic-email-20261110-body-interruption.json'
audit=json.loads(audit_path.read_text());assert audit['exit_code']==0
shutil.copy2(audit_path,v/'historical-resume.json')
shutil.copy2('/tmp/pr3-semantic-email-isolated.py',OUT/'driver/isolate.py')
shutil.copy2('/tmp/pr3-semantic-email-body-evaluation.log',OUT/'runner.log')
shutil.copy2(__file__,OUT/'driver/package.py')
sys.path.insert(0,str(OUT/'driver'))
from score import assess,expand,says
corpora={n:tomllib.loads((OUT/'data'/(n+'.toml')).read_text()) for n in ['semantic','legacy','compatibility']}
results=[];failures=[];identities=[];violations=[]
for job in m['jobs']:
 corpus=corpora[job['corpus']];cases={c['id']:c for c in corpus['case']}
 path=OUT/'rows'/(job['name']+'.jsonl');rows=[json.loads(s) for s in path.read_text().splitlines()]
 assert [r['id'] for r in rows]==job['cases']
 identities.extend((job['model'],job['seed'],r['id']) for r in rows)
 verdicts=[]
 for row in rows:
  verdict=assess(cases[row['id']],corpus['filler'],row,job['seed']);verdicts.append(verdict)
  if not verdict['passed']:failures.append({'job':job['name'],'case':row['id'],'verdict':verdict,'steps':row['steps']})
  plan=expand(cases[row['id']],corpus['filler'])
  for step in row['steps']:
   check=plan[step['launch']][step['step']]
   for field,key in [('card','card_excludes'),('sent','unsent')]:
    for value in check.get(key,[]):
     if step.get(field) and says(step[field],value):violations.append({'job':job['name'],'case':row['id'],'field':field,'value':value})
 results.append({**job,'recorded':len(rows),'passed':sum(x['passed'] for x in verdicts),'leaked':sum(x['leaked'] for x in verdicts),'errors':sum(x['error'] for x in verdicts)})
 assert json.loads(path.with_suffix('.manifest.json').read_text())=={'harness':5,'model_sha256':m['models'][job['model']]['sha256'],'binary_sha256':m['files']['bin/pr3-bench-task'],'corpus_sha256':digest(OUT/'data'/(job['corpus']+'.toml')),'seed':job['seed'],'web':True,'cases':job['cases']}
assert len(identities)==len(set(identities))==45
assert results==f['jobs']
totals={k:sum(r[k] for r in results) for k in ['recorded','passed','leaked','errors']}
assert totals==dict(recorded=45,passed=45,leaked=0,errors=0), (totals,failures)
assert not violations
baseline=ROOT/'bench/task/evidence/source-planning-2026-11-10.tar.gz'
with tarfile.open(baseline) as archive:
 old=json.load(archive.extractfile('manifest.json'))
 with tarfile.open(fileobj=archive.extractfile('source.tar.gz'),mode='r:gz') as source:
  name='app/pr3-app/src-tauri/src/host.rs'
  before=source.extractfile(name).read()
  after=(ROOT/name).read_bytes()
  assert before.replace(b'} else if task::mail::command(&text) {',b'} else if self.tasks()?.email_instruction(session) {')+b'\n#[cfg(test)]\nmod mail_meaning_tests;\n'==after
  name='app/pr3-app/src-tauri/src/llama/mail.rs'
  before=source.extractfile(name).read().decode();after=(ROOT/name).read_text()
  def outside_prompt(text):
   first,rest=text.split('const PROMPT: &str = ',1)
   _,last=rest.split('const GRAMMAR: &str = ',1)
   return first,last
  assert outside_prompt(before)==outside_prompt(after)
assert digest(OUT/'driver/score.py')==old['source_sha256']['bench/personal/score.py']
for name in ['bench/task/corpus.toml','bench/task/email-exclusions.toml']:
 assert m['source_sha256'][name]==old['source_sha256'][name]
unchanged=[n for n in old['source_sha256'] if n.startswith('crate/pr3-core/src/')]
unchanged+=['crate/pr3-llamacpp/src/lib.rs','app/pr3-app/src-tauri/src/actions.rs','app/pr3-app/src-tauri/src/config.rs','app/pr3-app/src-tauri/src/llama.rs','app/pr3-app/src-tauri/src/task/source.rs','bench/task/src/main.rs']
assert all(m['source_sha256'][n]==old['source_sha256'][n] for n in unchanged)
initial=OUT/'initial-candidate'
shutil.copytree(ROOT/'bench/task/result/semantic-email-2026-11-10',initial,dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','__pycache__','running.json'))
shutil.copy2(ROOT/'bench/rebaseline/result/2026-11-07/.semantic-email-20261110-interruption.json',initial/'historical-resume.json')
shutil.copy2('/tmp/pr3-semantic-email-evaluation.log',initial/'runner.log')
im=json.loads((initial/'manifest.json').read_text());ic=tomllib.loads((initial/'data/semantic.toml').read_text());cases={c['id']:c for c in ic['case']}
ir=[json.loads(s) for path in (initial/'rows').glob('*.jsonl') for s in path.read_text().splitlines()]
iv=[assess(cases[r['id']],ic['filler'],r,r['seed']) for r in ir]
v1=OUT/'v1-candidate'
shutil.copytree(ROOT/'bench/task/result/semantic-email-2026-11-10-final',v1,dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','__pycache__','running.json'))
shutil.copy2(ROOT/'bench/rebaseline/result/2026-11-07/.semantic-email-20261110-final-interruption.json',v1/'historical-resume.json')
shutil.copy2('/tmp/pr3-semantic-email-final-evaluation.log',v1/'runner.log')
vm=json.loads((v1/'manifest.json').read_text());vr=[];vv=[];vf=[]
for job in vm['jobs']:
 path=v1/'rows'/(job['name']+'.jsonl')
 if not path.exists():continue
 corpus=tomllib.loads((v1/'data'/(job['corpus']+'.toml')).read_text());cases={c['id']:c for c in corpus['case']}
 for line in path.read_text().splitlines():
  row=json.loads(line);verdict=assess(cases[row['id']],corpus['filler'],row,job['seed']);vr.append(row);vv.append(verdict)
  if not verdict['passed']:vf.append({'job':job['name'],'case':row['id'],'verdict':verdict,'steps':row['steps']})
assert vf and any(r['case']=='semantic-email/scoped-reinclusion' for r in vf)
reinclusion=OUT/'reinclusion-candidate'
shutil.copytree(ROOT/'bench/task/result/semantic-email-2026-11-10-v2',reinclusion,dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','__pycache__','running.json'))
shutil.copy2(ROOT/'bench/rebaseline/result/2026-11-07/.semantic-email-20261110-v2-interruption.json',reinclusion/'historical-resume.json')
shutil.copy2('/tmp/pr3-semantic-email-v2-evaluation.log',reinclusion/'runner.log')
rm=json.loads((reinclusion/'manifest.json').read_text());rr=[];rv=[];rf=[]
for job in rm['jobs']:
 path=reinclusion/'rows'/(job['name']+'.jsonl')
 if not path.exists():continue
 corpus=tomllib.loads((reinclusion/'data'/(job['corpus']+'.toml')).read_text());cases={c['id']:c for c in corpus['case']}
 for line in path.read_text().splitlines():
  row=json.loads(line);verdict=assess(cases[row['id']],corpus['filler'],row,job['seed']);rr.append(row);rv.append(verdict)
  if not verdict['passed']:rf.append({'job':job['name'],'case':row['id'],'verdict':verdict,'steps':row['steps']})
assert any(r['case']=='semantic-email/scoped-reinclusion' and 'seed2' in r['job'] for r in rf)
assert digest(reinclusion/'data/semantic.toml')==digest(OUT/'data/semantic.toml')
assert digest(reinclusion/'driver/score.py')==digest(OUT/'driver/score.py')
context=OUT/'context-candidate'
shutil.copytree(ROOT/'bench/task/result/semantic-email-2026-11-10-verified',context,dirs_exist_ok=True,ignore=shutil.ignore_patterns('bin','__pycache__','running.json'))
shutil.copy2(ROOT/'bench/rebaseline/result/2026-11-07/.semantic-email-20261110-verified-interruption.json',context/'historical-resume.json')
shutil.copy2('/tmp/pr3-semantic-email-verified-evaluation.log',context/'runner.log')
cm=json.loads((context/'manifest.json').read_text());cr=[];cv=[];cf=[]
for job in cm['jobs']:
 path=context/'rows'/(job['name']+'.jsonl')
 if not path.exists():continue
 corpus=tomllib.loads((context/'data'/(job['corpus']+'.toml')).read_text());cases={c['id']:c for c in corpus['case']}
 for line in path.read_text().splitlines():
  row=json.loads(line);verdict=assess(cases[row['id']],corpus['filler'],row,job['seed']);cr.append(row);cv.append(verdict)
  if not verdict['passed']:cf.append({'job':job['name'],'case':row['id'],'verdict':verdict,'steps':row['steps']})
assert len(cr)==len(cf)==1
assert digest(context/'data/semantic.toml')==digest(OUT/'data/semantic.toml')
assert digest(context/'driver/score.py')==digest(OUT/'driver/score.py')
# V2 changes only explicit numeric alternatives; no conversation, contact, decision or scorer changes.
before=tomllib.loads((v1/'data/semantic.toml').read_text());after=tomllib.loads((OUT/'data/semantic.toml').read_text())
for case in after['case']:
 for launch in case['launches']:
  for step in launch:
   for key in ('card_contains','card_excludes','sent','unsent'):
    for i,value in enumerate(step.get(key,[])):
     if '|' in value:
      assert value.split('|')[0] in ('74200','63500','81500') and len(value.split('|'))==6
      assert all(int(x.replace(',','').replace('٬',''))==int(value.split('|')[0]) for x in value.split('|'))
      step[key][i]=value.split('|')[0]
assert before==after
assert digest(v1/'driver/score.py')==digest(OUT/'driver/score.py')
summary={'complete':True,'status':'category-aware multilingual email exclusion regression','finished_at_utc':f['finished_at'],'base_commit':m['base_commit'],'totals':totals,'jobs':results,'failures':failures,'forbidden_card_or_outbox_content':violations,
 'validation':{'workspace':{'passed':443,'failed':0,'ignored':12},'new_regressions':17,'python_tests':21,'new_python_regressions':2,'clippy':'pass','format':'pass'},
 'initial_candidate':{'complete':False,'recorded':len(ir),'passed':sum(x['passed'] for x in iv),'reason':'Stopped during code review to add scoped field reinclusion and protection against dropping a category during clarification. Complete raw rows, frozen source and interruption/resume audits are retained; no same-build score-improving retry.'},
 'v1_candidate':{'complete':False,'recorded':len(vr),'passed':sum(x['passed'] for x in vv),'failures':vf,'reason':'Two original failures are retained: seed 1 rendered correct income $74,200 that did not match frozen token 74200; seed 2 genuinely omitted the requested income. V2 explicitly lists equivalent numerical renderings in both positive and negative checks. Prompts and independent scorer stay unchanged. The final source also bounds distinct values without truncating late corrections after duplicates.'},
 'reinclusion_candidate':{'complete':False,'recorded':len(rr),'passed':sum(x['passed'] for x in rv),'failures':rf,'reason':'Genuine seed-2 scoped-reinclusion failure: the approved draft omitted the income explicitly allowed back in. Bank information remained excluded. The final source now supplies latest explicitly re-included facts as task planning context; separate exclusions still win. The same v2 corpus and scorer remain unchanged; the failing case ran first on the revised build.'},
 'context_candidate':{'complete':False,'recorded':len(cr),'passed':sum(x['passed'] for x in cv),'failures':cf,'reason':'The context-only change still omitted income at seed 2 and substituted a nonexistent attachment. A host regression confirms the re-included value reaches the model after restart. Final planner policy now requires requested permitted facts in the body and forbids inventing an attachment; no decoder, tool, approval or inference-budget change.'},
 'models':m['models'],'manifest_sha256':digest(OUT/'manifest.json'),'binary_sha256':m['files']['bin/pr3-bench-task'],
 'unchanged_core_approval_limits_and_engine':{n:m['source_sha256'][n] for n in unchanged},'planner_change':'Only structured planning policy text changes to require requested permitted facts, scoped exceptions and no invented attachment substitution. Grammar, decoder, tool permissions, generation count and attempt limits are byte-identical to the prior source-planning build.', 'host_production_change':'Only correction routing changes from a stateless command check to task-aware recognition of pending clarification. Approval dispatch and execution sections remain byte-identical.',
 'historical_matrix_resumed':audit,
 'limits':['A local vocabulary maps four categories and known fields across English, French, Spanish, Persian and Arabic. This is not general semantic redaction or general multilingual intent recognition.','27 new development runs and 18 unchanged regression/control runs on installed Qwen3.5-4B at seeds 1/2/7. No claim of fresh held-out accuracy, 27B evaluation or physical Android acceptance.','Unsupported grammar, unlabelled narratives and arbitrary paraphrases/translations of excluded values remain open. Recognized unresolved requests block approval.','Latest explicitly re-included facts are carried into bounded planning context, without extra inference or execution permission. A named field/category can be re-included explicitly. A literal alone does not override a category policy. Incomplete quoted category data remains blocked; clarification cannot discard the category.','All source data, assistant replies and summaries remain unable to add/revoke exclusions. Original user messages are the durable source of truth; no schema migration or additional inference/execution allowance.','No real email delivery occurred. The separately frozen historical matrix is older evidence and was already stopped at entry to the initial candidate.']}
write(OUT/'summary.json',summary)
replay='''from pathlib import Path
import hashlib,json,sys,tomllib
from score import assess
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name,h in json.loads((root/'inventory.json').read_text()).items():assert digest(root/name)==h,name
m=json.loads((root/'manifest.json').read_text());summary=json.loads((root/'summary.json').read_text())
identities=[];passed=0
for job in m['jobs']:
 corpus=tomllib.loads((root/'data'/(job['corpus']+'.toml')).read_text());cases={c['id']:c for c in corpus['case']}
 path=root/'rows'/(job['name']+'.jsonl');rows=[json.loads(s) for s in path.read_text().splitlines()]
 assert [r['id'] for r in rows]==job['cases']
 assert json.loads(path.with_suffix('.manifest.json').read_text())=={'harness':5,'model_sha256':m['models'][job['model']]['sha256'],'binary_sha256':m['files']['bin/pr3-bench-task'],'corpus_sha256':digest(root/'data'/(job['corpus']+'.toml')),'seed':job['seed'],'web':True,'cases':job['cases']}
 for row in rows:
  verdict=assess(cases[row['id']],corpus['filler'],row,job['seed']);assert verdict['passed'] and not verdict['leaked'] and not verdict['error']
  passed+=1;identities.append((job['model'],job['seed'],row['id']))
assert passed==len(identities)==len(set(identities))==45
assert {seed for _,seed,_ in identities}=={1,2,7}
initial=root/'initial-candidate';corpus=tomllib.loads((initial/'data/semantic.toml').read_text());cases={c['id']:c for c in corpus['case']}
rows=[json.loads(s) for p in (initial/'rows').glob('*.jsonl') for s in p.read_text().splitlines()]
assert len(rows)==summary['initial_candidate']['recorded']
assert sum(assess(cases[r['id']],corpus['filler'],r,r['seed'])['passed'] for r in rows)==summary['initial_candidate']['passed']
for folder,key in [('v1-candidate','v1_candidate'),('reinclusion-candidate','reinclusion_candidate'),('context-candidate','context_candidate')]:
 candidate=root/folder;vm=json.loads((candidate/'manifest.json').read_text());count=passed=0
 for job in vm['jobs']:
  path=candidate/'rows'/(job['name']+'.jsonl')
  if not path.exists():continue
  corpus=tomllib.loads((candidate/'data'/(job['corpus']+'.toml')).read_text());cases={c['id']:c for c in corpus['case']}
  for line in path.read_text().splitlines():
   row=json.loads(line);count+=1;passed+=assess(cases[row['id']],corpus['filler'],row,job['seed'])['passed']
 assert (count,passed)==(summary[key]['recorded'],summary[key]['passed'])
print('Verified 27/27 multilingual development workflows and 18/18 unchanged controls; all four partial candidates and their original failures preserved.')
'''
(OUT/'driver/replay.py').write_text(replay)
files=[p for p in OUT.rglob('*') if p.is_file() and p.relative_to(OUT).parts[0]!='bin' and '__pycache__' not in p.parts and p.name not in ['inventory.json','running.json']]
write(OUT/'inventory.json',{str(p.relative_to(OUT)):digest(p) for p in sorted(files)})
files.append(OUT/'inventory.json')
subprocess.run([sys.executable,str(OUT/'driver/replay.py'),str(OUT)],check=True)
archive=ROOT/'bench/task/evidence'/(STEM+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(OUT)))
summary['portable_archive']={'path':str(archive.relative_to(ROOT)),'sha256':digest(archive)}
write(ROOT/'bench/task/evidence'/(STEM+'.json'),summary)
print('Packaged',archive)
