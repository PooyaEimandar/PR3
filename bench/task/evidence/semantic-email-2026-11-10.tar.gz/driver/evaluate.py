from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, signal, subprocess, sys, tarfile, time, tomllib

ROOT = Path('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3')
OUT = ROOT / 'bench/task/result/semantic-email-2026-11-10-body'
sys.path.insert(0, str(ROOT / 'bench/personal'))
from run import environment, sources, stop
from score import assess

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def now():
    return datetime.now(timezone.utc).isoformat()

assert not OUT.exists(), 'Keep prior runs immutable'
OUT.mkdir(parents=True)
for name in ('bin', 'data', 'rows', 'logs', 'driver'):
    (OUT / name).mkdir()
hashes = {name: digest(ROOT / name) for name in sources()}
with (OUT / 'logs/build.log').open('w') as log:
    subprocess.run(['cargo', 'build', '--release', '-p', 'pr3-bench-task', '--locked'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
assert all(digest(ROOT / name) == h for name, h in hashes.items())
shutil.copy2(ROOT / 'target/release/pr3-bench-task', OUT / 'bin/pr3-bench-task')
for name in ('score.py', 'run.py', 'dataset.py'):
    shutil.copy2(ROOT / 'bench/personal' / name, OUT / 'driver' / name)
shutil.copy2(__file__, OUT / 'driver/evaluate.py')
shutil.copy2(ROOT / 'bench/task/semantic-email-v2.toml', OUT / 'data/semantic.toml')
shutil.copy2(ROOT / 'bench/task/email-exclusions.toml', OUT / 'data/legacy.toml')
shutil.copy2(ROOT / 'bench/task/corpus.toml', OUT / 'data/compatibility.toml')
with tarfile.open(OUT / 'source.tar.gz', 'w:gz') as archive:
    for name in hashes:
        archive.add(ROOT / name, arcname=name)
models = {}
for name in ('Qwen3.5-4B-Q4_K_M',):
    path = ROOT / 'model' / (name + '.gguf')
    models[name] = {'path': str(path), 'sha256': digest(path)}
jobs = []
for seed in (2,1,7):
    for corpus in ('semantic','legacy','compatibility'):
        cases=[c['id'] for c in tomllib.loads((OUT/'data'/(corpus+'.toml')).read_text())['case']]
        if corpus=='compatibility':cases=['restart/trip','topic/speech','approval/dinner']
        if seed == 2 and corpus == 'semantic':
            target = 'semantic-email/scoped-reinclusion'
            jobs.append({'name': 'reinclusion-Qwen3.5-4B-Q4_K_M-seed2', 'corpus': corpus, 'model': 'Qwen3.5-4B-Q4_K_M', 'seed': seed, 'cases': [target]})
            cases.remove(target)
        jobs.append({'name':f'{corpus}-Qwen3.5-4B-Q4_K_M-seed{seed}', 'corpus':corpus,
                     'model':'Qwen3.5-4B-Q4_K_M','seed':seed,'cases':cases})
planned=sum(len(j['cases']) for j in jobs)
assert planned==45
manifest = {'created_at': now(), 'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'source_sha256': hashes, 'environment': environment(), 'models': models, 'jobs': jobs,
            'files': {str(p.relative_to(OUT)): digest(p) for directory in ('bin', 'data', 'driver') for p in (OUT / directory).iterdir()},
            'source_archive_sha256': digest(OUT / 'source.tar.gz'),
            'policy': 'V2 frozen development regression for category-aware multilingual email exclusions. V1 numeric-format failures remain preserved. V2 changes only explicit equivalent numeric alternatives in positive and negative corpus checks; prompts and independent scorer are unchanged. Final product also counts distinct values without losing late corrections after repeated facts, and carries latest explicitly re-included values into planning context after restart. The prior genuine seed-2 missing-income failure remains preserved, with the same v2 prompts and scoring checks. The context-only revision also omitted income and is preserved separately. The structured email planning instruction now requires requested permitted facts in the body and forbids substituting invented attachments; its decoder and approval path are unchanged. That case runs first on this changed build. 27 new runs cover five languages, clarification, corrections, quoted commands and scoped reinclusion; 18 unchanged legacy and compatibility runs cover field/literal exclusions and ordinary workflows. Core limits and approval executor unchanged. No extra model calls. Preserve all observations, including failures; no same-build retries. This is not fresh held-out accuracy.'}
write('manifest.json', manifest)
results = []
for job in jobs:
    path = OUT / 'rows' / (job['name'] + '.jsonl')
    corpus_path = OUT / 'data' / (job['corpus'] + '.toml')
    command = [str(OUT / 'bin/pr3-bench-task'), 'run', '--model', models[job['model']]['path'],
               '--corpus', str(corpus_path), '--seed', str(job['seed']), '--out', str(path)]
    for case in job['cases']:
        command += ['--case', case]
    print('Starting ' + job['name'], flush=True)
    with (OUT / 'logs' / (job['name'] + '.log')).open('w') as log:
        child = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        write('running.json', {'job': job, 'runner_pid': os.getpid(), 'child_pid': child.pid, 'command': command})
        try:
            child.wait()
        finally:
            stop(child)
        assert child.returncode == 0, 'Preserve a failed harness job for inspection'
    corpus = tomllib.loads(corpus_path.read_text())
    cases = {c['id']: c for c in corpus['case']}
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    assert [row['id'] for row in rows] == job['cases']
    identity = json.loads(path.with_suffix('.manifest.json').read_text())
    assert identity == {'harness': 5, 'model_sha256': models[job['model']]['sha256'],
                        'binary_sha256': manifest['files']['bin/pr3-bench-task'],
                        'corpus_sha256': digest(corpus_path), 'seed': job['seed'], 'web': True, 'cases': job['cases']}
    verdicts = [assess(cases[row['id']], corpus['filler'], row, job['seed']) for row in rows]
    results.append({**job, 'recorded': len(rows), 'passed': sum(v['passed'] for v in verdicts),
                    'leaked': sum(v['leaked'] for v in verdicts), 'errors': sum(v['error'] for v in verdicts)})
    write('progress.json', {'complete': len(results) == len(jobs), 'planned': planned, 'recorded': sum(r['recorded'] for r in results), 'jobs': results})
    print(json.dumps(results[-1]), flush=True)
    assert all(v['passed'] for v in verdicts), 'Stop and preserve the first failed job; no same-build reroll'

assert all(digest(ROOT / name) == h for name, h in hashes.items())
write('finished.json', {'finished_at': now(), 'complete': True, 'recorded': planned, 'jobs': results})
