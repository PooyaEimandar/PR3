import { createReadStream, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { verifyFreeze } from '../../freeze.ts';

const dir = fileURLToPath(new URL('.', import.meta.url));
const manifest = JSON.parse(readFileSync(dir + 'manifest.json', 'utf8'));
async function digest(path: string): Promise<string> {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return hash.digest('hex');
}

verifyFreeze();
const expected: [string, string][] = [
  ...Object.entries(manifest.harnessHashes) as [string, string][],
  ['target/debug/research_bridge', manifest.binarySha256],
  ...manifest.models.map((m: { name: string; sha256: string }) => [`model/${m.name}`, m.sha256] as [string, string]),
];
const checks = await Promise.all(expected.map(async ([path, expectedSha256]) => {
  const actualSha256 = await digest(path);
  return { path, expectedSha256, actualSha256, matches: expectedSha256 === actualSha256 };
}));
const summary = JSON.parse(readFileSync(dir + 'summary.json', 'utf8'));
const analysis = JSON.parse(readFileSync(dir + 'analysis.json', 'utf8'));
const summaryMatchesReplay = JSON.stringify(summary) === JSON.stringify(analysis.automatic);
const rows = readFileSync(dir + 'results.jsonl', 'utf8').trim().split('\n').map(line => JSON.parse(line));
const errors = rows.flatMap(row => [row.error, ...row.turns.map((turn: { error?: string }) => turn.error)]).filter(Boolean);
const result = {
  checkedAt: new Date().toISOString(),
  productionFreezeVerified: true,
  summaryMatchesReplay,
  checks,
  runtimeErrors: errors.length,
  allRuntimeErrorsAreContextLimits: errors.every((error: string) => error.includes('message too long for the model')),
  rpcDeadlineFailures: errors.filter((error: string) => /timeout|timed out|deadline/i.test(error)).length,
  passed: summaryMatchesReplay && checks.every(check => check.matches),
};
writeFileSync(dir + 'integrity.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ passed: result.passed, hashChecks: checks.length, summaryMatchesReplay, runtimeErrors: result.runtimeErrors, rpcDeadlineFailures: result.rpcDeadlineFailures }));
if (!result.passed) process.exitCode = 1;
