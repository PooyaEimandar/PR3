import {readFileSync,writeFileSync,statSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {score,summarize,verifyCorpusBytes} from '../../score.ts';
import {verifyFreeze,sha} from '../../freeze.ts';
import type {Row,Corpus} from '../../types.ts';
import {fileURLToPath} from 'node:url';
const dir=fileURLToPath(new URL('.',import.meta.url));
const partial=process.argv.includes('--partial');
const manifest=JSON.parse(readFileSync(dir+'manifest.json','utf8'));
const corpus:Corpus=verifyCorpusBytes(readFileSync(dir+'corpus.json','utf8'),manifest.corpusSha256);
const rows:Row[]=readFileSync(dir+'results.jsonl','utf8').trim().split('\n').map(l=>JSON.parse(l));
const decisions=readFileSync(dir+'review-decisions.jsonl','utf8').trim().split('\n').map(l=>JSON.parse(l));
const reviews=new Map(decisions.map(d=>[d.blindId,d]));
if(reviews.size!==decisions.length)throw Error('Duplicate review');
const automatic=summarize(corpus,rows,manifest.models.map((m:any)=>m.name),manifest.seeds);
if(!partial&&!automatic.complete)throw Error('Matrix incomplete');
const blind=(model:string,side:string,seed:number,id:string,i:number)=>createHash('sha256').update(`${model}/${side}/${seed}/${id}/${i}`).digest('hex').slice(0,16);
const completed:any[]=[],groups:any={},reviewIds=new Set<string>(),authIssues:any[]=[];
const normalize=(s:string)=>s.replace(/research:\d+:/g,'research:TASK:');
const signatures=new Map<string,string>();
const q=(a:number[],p:number)=>a.toSorted((a,b)=>a-b)[Math.max(0,Math.ceil(a.length*p)-1)]??null;
const median=(a:number[])=>{const s=a.toSorted((a,b)=>a-b);return s.length?(s[(s.length-1)>>1]!+s[Math.floor(s.length/2)]!)/2:null;};
for(const model of manifest.models)for(const side of ['pr3','openjarvis']){
 const g:any={expectedRuns:corpus.cases.length*manifest.seeds.length,recordedRuns:0,expectedTurns:corpus.cases.reduce((n,c)=>n+(c.restart?2:1),0)*manifest.seeds.length,recordedTurns:0,reviewedTurns:0,reviewedPass:0,borderlinePassTurns:0,borderlineFailTurns:0,reviewedCasePass:0,runtimeErrorTurns:0,turnLimitTurns:0,missingTurns:0,noSubstantiveAnswerTurns:0,successfulReportCalls:0,successfulReportTurns:0,reviewedPassWithReport:0,verifiedToolQuotations:0,tokens:0,times:[],goodTimes:[],adapterTimes:[]};
 for(const seed of manifest.seeds)for(const c of corpus.cases){
  const row=rows.find(r=>r.model===model.name&&r.side===side&&r.seed===seed&&r.id===c.id);
  const n=c.restart?2:1;let all=true;g.recordedRuns+=Number(!!row);
  for(let i=0;i<n;i++){
   const id=blind(model.name,side,seed,c.id,i),t:any=row?.turns[i],d=reviews.get(id);
   if(!t){g.missingTurns++;g.runtimeErrorTurns+=Number(!!row?.error);all=false;continue;}
   g.recordedTurns++;reviewIds.add(id);if(d)g.reviewedTurns++;
   if(!d&&!partial)throw Error(`Missing review ${id}`);
   const pass=!!d&&d.supported===true&&d.complete===true&&!t.error;
   all&&=pass;g.reviewedPass+=Number(pass);g.borderlinePassTurns+=Number(!!d?.borderline&&pass);g.borderlineFailTurns+=Number(!!d?.borderline&&!pass&&!t.error&&d.complete===true);g.noSubstantiveAnswerTurns+=Number(d?.supported===null);
   g.runtimeErrorTurns+=Number(!!t.error);g.turnLimitTurns+=Number(t.agent_metadata?.max_turns_exceeded===true);
   if(Number.isFinite(t.seconds)){g.times.push(t.seconds);if(pass)g.goodTimes.push(t.seconds);}
   if(Number.isFinite(t.adapter_seconds))g.adapterTimes.push(t.adapter_seconds);
   g.tokens+=side==='pr3'?(t.traces??[]).reduce((n:number,x:any)=>n+x.total_tokens,0):(t.generations??[]).reduce((n:number,x:any)=>n+(x.response?.usage?.total_tokens??0),0);
   const sources=new Map<string,string>(t.evidence.sources.map((s:any)=>[s.source,s.text]));
   const calls=side==='pr3'?(t.traces??[]).flatMap((x:any)=>x.steps.filter((s:any)=>s.step_type==='tool_call'&&s.input.tool==='answer_research'&&s.output.success).map((s:any)=>JSON.parse(s.input.arguments))):t.events.filter((e:any)=>e.name==='answer_research'&&e.success).map((e:any)=>e.arguments);
   g.successfulReportCalls+=calls.length;g.successfulReportTurns+=Number(calls.length>0);g.reviewedPassWithReport+=Number(pass&&calls.length>0);
   for(const call of calls)for(const f of call.findings??[])for(const cite of f.citations??[]){
    if(sources.get(cite.source)?.includes(cite.quote))g.verifiedToolQuotations++;else authIssues.push({blindId:id,source:cite.source});
   }
   const evidence=t.evidence.sources.map((s:any)=>({source:normalize(s.source),location:s.location,text:s.text})).sort((a:any,b:any)=>a.source.localeCompare(b.source));
   signatures.set(id,createHash('sha256').update(JSON.stringify({case:c.id,turn:i,answer:normalize(t.answer),error:t.error,evidence})).digest('hex'));
   completed.push({blindId:id,model:model.name,side,seed,case:c.id,turn:i,...d,pass,automatic:score(t,i===0?c.checks:c.restart!.checks),seconds:t.seconds,runtimeError:t.error??null,rowError:row?.error??null});
  }
  g.reviewedCasePass+=Number(!!row&&!row.error&&all);
 }
 g.reviewedPassSensitivity=[g.reviewedPass-g.borderlinePassTurns,g.reviewedPass+g.borderlineFailTurns];g.maxSeconds=g.times.length?Math.max(...g.times):null;g.medianSeconds=median(g.times);g.p95Seconds=q(g.times,.95);g.qualityPassingMedianSeconds=median(g.goodTimes);g.adapterMedianSeconds=median(g.adapterTimes);
 delete g.times;delete g.goodTimes;delete g.adapterTimes;groups[`${model.name}/${side}`]=g;
}
for(const d of decisions){
 if(!reviewIds.has(d.blindId))throw Error(`Foreign review ${d.blindId}`);
 if(typeof d.complete!=='boolean'||![true,false,null].includes(d.supported)||!d.reason)throw Error(`Invalid review ${d.blindId}`);
 if(d.equivalentTo){const parent=reviews.get(d.equivalentTo);if(!parent||signatures.get(d.blindId)!==signatures.get(d.equivalentTo)||d.equivalenceSha256!==signatures.get(d.blindId)||d.supported!==parent.supported||d.complete!==parent.complete)throw Error(`Invalid review equivalence ${d.blindId}`);}
}
const byCase=Object.fromEntries(manifest.models.flatMap((model:any)=>['pr3','openjarvis'].map(side=>[`${model.name}/${side}`,Object.fromEntries(corpus.cases.map(c=>{const turns=completed.filter(t=>t.model===model.name&&t.side===side&&t.case===c.id);return [c.id,{reviewedPass:turns.filter(t=>t.pass).length,recordedTurns:turns.length,expectedTurns:(c.restart?2:1)*manifest.seeds.length}];}))])));
const bySeed=Object.fromEntries(manifest.models.flatMap((model:any)=>['pr3','openjarvis'].flatMap(side=>manifest.seeds.map((seed:number)=>{const ts=completed.filter(t=>t.model===model.name&&t.side===side&&t.seed===seed);const times=ts.map(t=>t.seconds).filter(Number.isFinite);return [`${model.name}/${side}/${seed}`,{recordedTurns:ts.length,reviewedPass:ts.filter(t=>t.pass).length,runtimeErrorTurns:ts.filter(t=>t.runtimeError).length,medianSeconds:median(times),p95Seconds:q(times,.95),maxSeconds:times.length?Math.max(...times):null}];}))));
const result={version:1,byCase,bySeed,complete:automatic.complete,automatic,groups,toolQuotationVerification:{issues:authIssues},review:{producedTurns:reviewIds.size,reviewedTurns:decisions.length,exactEquivalentReviews:decisions.filter(d=>d.equivalentTo).length,borderlineDecisions:decisions.filter(d=>d.borderline).map(d=>({blindId:d.blindId,reason:d.reason})),method:'Implementer source review against frozen rubrics, not independent or fully blinded. Exact duplicate case/turn/answer/source sets may reuse a documented review after canonicalizing research task IDs only. Final-answer format compliance is separate from semantic support, completeness, latest-request relevance and misleading provenance.'}};
console.log(JSON.stringify(result,null,2));
if(!partial){
 verifyFreeze();if(sha('bench/research/v1/freeze.json')!==manifest.freezeSha256)throw Error('Freeze manifest changed');
 if(authIssues.length)throw Error('Successful tool quotation failed independent snapshot verification');
 const packet=JSON.parse(readFileSync(dir+'semantic-review.json','utf8'));
 if(packet.length!==reviewIds.size||packet.some((p:any)=>!reviews.has(p.blindId)))throw Error('Review packet mismatch');
 writeFileSync(dir+'analysis.json',JSON.stringify({...result,inferenceCompletedAt:statSync(dir+'semantic-review.json').mtime.toISOString(),reviewCompletedAt:new Date().toISOString()},null,2)+'\n');
 writeFileSync(dir+'semantic-review-completed.json',JSON.stringify(completed,null,2)+'\n');
}
