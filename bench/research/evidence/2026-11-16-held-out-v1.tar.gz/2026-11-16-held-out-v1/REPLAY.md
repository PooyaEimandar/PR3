# Replaying this evidence

Extract this directory under bench/research/result/ in the matching PR3 checkout. Run commands from the repository root with Node 22.18 or later:

```sh
node bench/research/score.ts bench/research/result/2026-11-16-held-out-v1
node bench/research/result/2026-11-16-held-out-v1/analysis-replay.ts --partial
```

The first command replays the frozen automatic checks. The second replays source-review aggregation and independently checks accepted report-tool quotations against saved source snapshots; --partial keeps the original analysis files untouched. Omitting --partial also requires the original production-source freeze, checks the review packet and writes new analysis/review output with the current review-completion timestamp. It does not redo inference or independently judge the existing review decisions.

Review decisions are implementation-session source reviews, not independent human ratings. Exact-equivalent decisions record their parent ID and a hash of the case, turn, normalized answer and source set. Only numeric research task IDs are canonicalized. Original answers, complete model/tool IPC, source snapshots, the unfilled review packet and completed reviews are preserved. Live app traces and API credentials are excluded.

`integrity-replay.ts` additionally requires the matching local GGUF files and research_bridge binary. It checks their hashes, all recorded harness hashes, the production freeze and the automatic-summary replay. It writes a new integrity-check timestamp but does not perform inference. The archived integrity.json records the original successful post-run check. Performance observations record that power changed from AC to battery; latency is observational.
