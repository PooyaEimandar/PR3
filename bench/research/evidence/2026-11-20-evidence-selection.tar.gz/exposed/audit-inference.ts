/** Verify the exact post-fit evidence, independently of answer grading. */
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
const dir=resolve(process.argv[2]??'');
if(!process.argv[2])throw Error('MATRIX required');
const read=(name:string)=>JSON.parse(readFileSync(resolve(dir,name),'utf8'));
const hash=(parts:Buffer[])=>{const h=createHash('sha256');for(const part of parts){const len=Buffer.alloc(8);len.writeBigUInt64BE(BigInt(part.length));h.update(len);h.update(part);}return h.digest('hex');};
const quoteRef=(source:string,offset:number,text:string)=>{const range=Buffer.alloc(4);range.writeUInt32BE(offset*512+Buffer.byteLength(text));return 'q:'+range.toString('hex')+hash([Buffer.from('pr3:quote-reference:v1'),Buffer.from(source),range,Buffer.from(text)]).slice(0,16);};
if(quoteRef('s:245ef49028e5e7bc',0,'Brisa cuesta 27 euros al mes.')!=='q:0000001d1a73c1a3fd4b72cb')throw Error('Reference control failed');
const progress=read('progress.json'),manifest=read('manifest.json');
if(!progress.complete)throw Error('Matrix incomplete');
let turns=0,passes=0,quotes=0,maxPromptTokens=0,clockDivergences=0;
const coverage:Record<string,{turns:number;anyComplete:number;everyReportPassComplete:number;reportPasses:number}>= {};
const timings:Record<string,number[]>= {};
for(const run of progress.runs){
  for(const line of readFileSync(resolve(dir,run.file),'utf8').trim().split('\n')){
    const row=JSON.parse(line);
    for(const [index,turn]of row.turns.entries()){
      turns++;
      const task=turn.events.find((e:{type:string})=>e.type==='started')?.task;
      if(!Number.isSafeInteger(task))throw Error('Missing task binding');
      const taskBytes=Buffer.alloc(8);taskBytes.writeBigUInt64LE(BigInt(task));
      const sources=new Map<string,{text:string;captured_at:number}>(turn.evidence.sources.map((s:{source:string;text:string;captured_at:number})=>[
        's:'+hash([Buffer.from('pr3-research-reference-v1'),Buffer.from('s'),taskBytes,Buffer.from(s.source)]).slice(0,16),s]));
      if(!Array.isArray(turn.inference_evidence)||(!turn.inference_evidence.length&&turn.error===null))throw Error('Missing inference evidence');
      const start=turn.wall_started_ms,end=turn.wall_finished_ms;
      if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||end<start)throw Error('Invalid wall clock interval');
      const wall=(end-start)/1000;(timings[run.model]??=[]).push(wall);
      clockDivergences+=Number(Math.abs(wall-turn.seconds)>1);
      const reportViews:string[][]=[];
      for(const pass of turn.inference_evidence){
        passes++;
        if(!Number.isInteger(pass.prompt_tokens)||pass.prompt_tokens<=0||pass.answer_reservation!==512||pass.prompt_tokens+pass.answer_reservation>4096)throw Error('Inference context budget exceeded');
        maxPromptTokens=Math.max(maxPromptTokens,pass.prompt_tokens);
        const reportQuotes:string[]=[];let report=false;
        for(const raw of pass.source_views){
          const packet=JSON.parse(raw);
          if(!Array.isArray(packet.sources)||packet.sources.length>4)throw Error('Inference source limit exceeded');
          for(const source of packet.sources){
            const saved=sources.get(source.source);
            if(!saved||source.captured_at!==saved.captured_at)throw Error('Inference source binding mismatch');
            const excerpts=source.quotes??[source,...(source.additional_excerpts??[])];
            report ||= Array.isArray(source.quotes);
            for(const quote of excerpts){
              const bytes=Buffer.from(quote.text??'');
              if(!Number.isSafeInteger(quote.offset)||quote.offset<0||bytes.length<1||bytes.length>500
                ||!Buffer.from(saved.text).subarray(quote.offset,quote.offset+bytes.length).equals(bytes)
                ||quoteRef(source.source,quote.offset,quote.text)!==quote.quote_ref
                ||(quote.source!==undefined&&quote.source!==source.source))throw Error('Inference quotation integrity failure');
              quotes++;if(Array.isArray(source.quotes))reportQuotes.push(quote.text);
            }
          }
        }
        if(report)reportViews.push(reportQuotes);
      }
      if(index===0&&['fresh-python-zip','fresh-git-diff','fresh-cargo-features','public-sqlite-comparison-restart','late-comparison-restart','late-conditions-restart'].includes(row.id)){
        const complete=(q:string[])=>{
          const has=(literal:string)=>q.some(text=>text.includes(literal));
          if(row.id==='fresh-python-zip')return has('zip() is lazy')&&has('By default, zip() stops when the shortest iterable is exhausted.')&&q.some(text=>text.includes('strict=True')&&text.includes('raises a ValueError if one iterable is exhausted before the others'));
          if(row.id==='fresh-git-diff')return has('This form is to compare the given two paths on the filesystem.')&&has('when running the command outside a working tree controlled by Git. This form implies --exit-code.')&&q.some(text=>text.includes('--exit-code\nMake the program exit')&&text.includes('0 means no differences'));
          if(row.id==='public-sqlite-comparison-restart')return has('readers to continue operating from the original unaltered database while changes are simultaneously being committed into the WAL')&&has('writer must make sure no other process is reading the database')&&has('All processes using a database must be on the same host computer');
          if(row.id==='late-comparison-restart')return has('Orchid lets readers continue while a writer commits.')&&has('Reed waits for existing readers to finish before commit and excludes new readers until the commit completes.')&&has('Orchid requires every process to run on the same host.');
          if(row.id==='late-conditions-restart')return has('Delta export is available only to administrators.')&&has('Free accounts cannot export.')&&has('The trial export quota is 3 reports per day.');
          return has('Dependencies automatically enable default features unless default-features = false is specified.')&&has('If another dependency includes flate2')&&has('dep: prefix anywhere in the [features] table, that disables the implicit feature.');
        };
        const c=coverage[`${run.model}/${row.id}`]??={turns:0,anyComplete:0,everyReportPassComplete:0,reportPasses:0};
        c.turns++;c.anyComplete+=Number(reportViews.some(complete));c.everyReportPassComplete+=Number(reportViews.length>0&&reportViews.every(complete));c.reportPasses+=reportViews.length;
      }
    }
  }
}
if(turns!==manifest.expectedTurns)throw Error('Incomplete inference audit');
console.log(JSON.stringify({turns,passes,verifiedInferenceQuotes:quotes,maxPromptTokens,answerReservation:512,clockDivergences,coverage,wallSeconds:Object.fromEntries(Object.entries(timings).map(([model,times])=>{times.sort((a,b)=>a-b);return[model,{median:(times[(times.length-1)>>1]!+times[times.length>>1]!)/2,p95:times[Math.ceil(times.length*.95)-1],max:times.at(-1)}];}))},null,2));
