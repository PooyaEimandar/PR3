import {cpSync,mkdtempSync,readFileSync,rmSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath} from 'node:url';
const here=fileURLToPath(new URL('.',import.meta.url));
const original=process.argv[2];if(!original)throw Error('MATRIX required');
const scratch=mkdtempSync(join(tmpdir(),'pr3-inference-controls-')),matrix=join(scratch,'matrix');
const run=()=>spawnSync(process.execPath,[join(here,'audit-inference.ts'),matrix],{encoding:'utf8'});
const results:{control:string;pass:boolean}[]=[];
function check(control:string,change:(rows:any[])=>void,expected:string){
  rmSync(matrix,{recursive:true,force:true});cpSync(original!,matrix,{recursive:true});
  const path=join(matrix,'4b-seed1.jsonl');const rows=readFileSync(path,'utf8').trim().split('\n').map(line=>JSON.parse(line));
  change(rows);writeFileSync(path,rows.map(row=>JSON.stringify(row)).join('\n')+'\n');
  const result=run(),pass=result.status!==0&&result.stderr.includes(expected);results.push({control,pass});if(!pass)throw Error(control+': '+result.stderr);
}
const source=(rows:any[])=>rows.flatMap(row=>row.turns).flatMap(turn=>turn.inference_evidence).find(pass=>pass.source_views.length>0);
try{
  cpSync(original,matrix,{recursive:true});const valid=run();if(valid.status!==0)throw Error(valid.stderr);
  results.push({control:'unaltered inference evidence accepted',pass:true});
  check('missing audit rejected',rows=>{rows[0].turns[0].inference_evidence=[];},'Missing inference evidence');
  check('context overflow rejected',rows=>{rows[0].turns[0].inference_evidence[0].prompt_tokens=4096;},'Inference context budget exceeded');
  check('answer reservation reduced',rows=>{rows[0].turns[0].inference_evidence[0].answer_reservation=128;},'Inference context budget exceeded');
  check('edited inference quote rejected',rows=>{const pass=source(rows),packet=JSON.parse(pass.source_views[0]),s=packet.sources[0];(s.quotes?.[0]??s).text='FORGED EVIDENCE';pass.source_views[0]=JSON.stringify(packet);},'Inference quotation integrity failure');
  check('foreign inference source rejected',rows=>{const pass=source(rows),packet=JSON.parse(pass.source_views[0]);packet.sources[0].source='s:foreign';pass.source_views[0]=JSON.stringify(packet);},'Inference source binding mismatch');
  check('altered quote offset rejected',rows=>{const pass=source(rows),packet=JSON.parse(pass.source_views[0]),s=packet.sources[0];(s.quotes?.[0]??s).offset+=1;pass.source_views[0]=JSON.stringify(packet);},'Inference quotation integrity failure');
  check('reversed wall clock rejected',rows=>{rows[0].turns[0].wall_finished_ms=rows[0].turns[0].wall_started_ms-1;},'Invalid wall clock interval');
  console.log(JSON.stringify({controls:results},null,2));
}finally{rmSync(scratch,{recursive:true,force:true});}
