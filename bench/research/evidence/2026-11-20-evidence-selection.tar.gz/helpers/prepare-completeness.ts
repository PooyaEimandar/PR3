import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {join,dirname} from 'node:path';
const work='/private/tmp/pr3-evidence-selection-2026-11-20';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const files=['crate/pr3-memory/src/retrieval.rs','crate/pr3-llamacpp/src/evidence.rs','crate/pr3-llamacpp/src/prompt.rs','crate/pr3-llamacpp/src/lib.rs','crate/pr3-tool/src/research/identity.rs','app/pr3-app/src-tauri/src/host/research_context.rs'];
if(existsSync(join(work,'candidate9')))throw Error('Candidate staging already exists');
for(const file of files){
  const bytes=readFileSync(join(root,file));
  if(!bytes.equals(readFileSync(join(work,'source-selection8',file))))throw Error('Current source differs from frozen build: '+file);
  const target=join(work,'candidate9',file);mkdirSync(dirname(target),{recursive:true});writeFileSync(target,bytes,{flag:'wx'});
}
console.log('Prepared six isolated source copies; frozen production files unchanged.');
