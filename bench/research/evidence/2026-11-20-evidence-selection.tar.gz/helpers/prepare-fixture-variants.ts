import {readFileSync, writeFileSync} from 'node:fs';
const work='/private/tmp/pr3-evidence-selection-2026-11-20';
const path='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/crate/pr3-llamacpp/tests/fixtures/technical-evidence.json';
const fixture=JSON.parse(readFileSync(path,'utf8'));
if(fixture.cases.some((c:{base?:string})=>c.base))throw Error('Variants already saved');
const rows=readFileSync(`${work}/selection3-4b-seed1.jsonl`,'utf8').trim().split('\n').map(line=>JSON.parse(line));
for(const row of rows) {
  const original=fixture.cases.find((c:{id:string})=>c.id===row.id);
  fixture.cases.push({id:row.id+'-scope-variant',base:row.id,query:original.query,
    sources:row.turns[0].evidence.sources.map((s:{text:string;title:string;location:string},i:number)=>({source:`s:${row.id}:${i}`,origin:row.id,text:s.text,title:s.title,location:s.location}))});
}
writeFileSync(path,JSON.stringify(fixture,null,2)+'\n');
