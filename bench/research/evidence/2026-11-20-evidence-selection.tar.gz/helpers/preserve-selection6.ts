import {existsSync,readFileSync,renameSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
const work='/private/tmp/pr3-evidence-selection-2026-11-20';
const source='bench/research/result/evidence-selection-dev-2026-11-20';
const target='bench/research/result/evidence-selection-inspection-candidate-2026-11-20';
if(existsSync(target))throw Error('Candidate already preserved');
const rows=[1,2].flatMap(seed=>readFileSync(join(source,`4b-seed${seed}.jsonl`),'utf8').trim().split('\n').map(JSON.parse));
const turns=rows.reduce((n,r)=>n+r.turns.length,0);
const review=JSON.parse(readFileSync(join(source,'source-review.json'),'utf8'));
if(review.decisions.length!==turns)throw Error('All complete candidate turns must be reviewed');
const metadata={complete:false,turns,reviewed:review.decisions.length,passed:review.decisions.filter(d=>d.pass).length,borderline:review.decisions.filter(d=>d.borderline).length,traceRejections:rows.flatMap(r=>r.turns).flatMap(t=>t.traces).flatMap(t=>t.steps).filter(s=>s.step_type==='tool_call'&&s.output?.success===false).length,reason:'Stopped selection6 after repeated authority-inspection citation-format failures. Preserve all completed outputs; no substitution into final matrix.'};
writeFileSync(join(source,'partial-candidate.json'),JSON.stringify(metadata,null,2)+'\n',{flag:'wx'});
renameSync(source,target);
for(const [old,name]of [['matrices.log','matrices-inspection-candidate.log'],['performance.jsonl','performance-inspection-candidate.jsonl']]){
 if(existsSync(join(work,name)))throw Error('Existing log target');renameSync(join(work,old),join(work,name));
}
console.log(JSON.stringify(metadata));
