import { readFileSync, writeFileSync } from 'node:fs';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const corpus=JSON.parse(readFileSync(`${root}/bench/research/result/generalization-2026-11-20/corpus.json`,'utf8'));
const cases=corpus.cases.filter((c:{id:string})=>['fresh-python-zip','fresh-git-diff','fresh-cargo-features'].includes(c.id));
if(cases.length!==3)throw Error('Missing baseline case');
writeFileSync('/private/tmp/pr3-evidence-selection-2026-11-20/diagnostic.json',JSON.stringify({status:'Exposed technical-page diagnostics; unchanged prior cases',cases},null,2)+'\n',{flag:'wx'});
