import { readFileSync } from 'node:fs';
const [file,id]=process.argv.slice(2);
for(const line of readFileSync(file!,'utf8').split('\n').slice(0,-1)) {
  const row=JSON.parse(line);if(id&&row.id!==id)continue;
  for(const [turn,t]of row.turns.entries()) {
    console.log(JSON.stringify({id:row.id,turn,answer:t.answer,seconds:t.seconds,errors:t.traces.flatMap((t:{steps:any[]})=>t.steps).filter((s:any)=>s.step_type==='tool_call'&&s.output.success===false).map((s:any)=>s.output.result)},null,2));
    for(const [pass,p]of (t.inference_evidence??[]).entries()) {
      console.log(JSON.stringify({pass,prompt_tokens:p.prompt_tokens,answer_reservation:p.answer_reservation,views:p.source_views.map((s:string)=>JSON.parse(s))},null,2));
    }
  }
}
