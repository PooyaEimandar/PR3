import {readFileSync, writeFileSync, cpSync, mkdirSync} from 'node:fs';
const old='/private/tmp/pr3-research-quality-2026-11-20';
const work='/private/tmp/pr3-evidence-selection-2026-11-20';
cpSync(`${old}/record-review.ts`,`${work}/record-review.ts`,{errorOnExist:true,force:false});
writeFileSync(`${work}/next-review.ts`,readFileSync(`${old}/next-review.ts`,'utf8').replaceAll('quality-2026-11-20-final','evidence-selection-dev-2026-11-20').replaceAll('generalization-2026-11-20','evidence-selection-exposed-2026-11-20'),{flag:'wx'});
for(const name of ['development','exposed']) {
  const dir=`${work}/archive/${name}`;mkdirSync(dir,{recursive:true});
  cpSync(`${old}/archive/development/replay.ts`,`${dir}/replay.ts`,{errorOnExist:true,force:false});
  cpSync(`${old}/archive/${name==='development'?'development':'generalization'}/check-replay.ts`,`${dir}/check-replay.ts`,{errorOnExist:true,force:false});
}
