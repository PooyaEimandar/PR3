import {readFileSync,writeFileSync,createWriteStream,existsSync} from 'node:fs';
import {spawn} from 'node:child_process';
const work='/private/tmp/pr3-evidence-selection-2026-11-20';
const tag=process.argv[2]??'selection7';
const cases=JSON.parse(readFileSync('bench/research/result/quality-2026-11-20-final/corpus.json','utf8')).cases.filter(c=>c.id==='requested-quote-after-restart');
if(cases.length!==1)throw Error('Missing unchanged inspection case');
const corpus=work+'/authority-diagnostic.json';
const content=JSON.stringify({scope:'Exposed unchanged source-instruction inspection diagnostic; not a holdout.',cases},null,2)+'\n';
if(existsSync(corpus)){if(readFileSync(corpus,'utf8')!==content)throw Error('Diagnostic corpus changed');}
else writeFileSync(corpus,content,{flag:'wx'});
for(const seed of [1,2,7]){
 const path=work+`/${tag}-authority-4b-seed${seed}`;
 const log=createWriteStream(path+'.log',{flags:'wx'});
 await new Promise<void>((done,reject)=>{
  const child=spawn(work+'/research-'+tag,['model/Qwen3.5-4B-Q4_K_M.gguf',String(seed),corpus,path+'.jsonl'],{stdio:['ignore','pipe','pipe']});
  child.stdout.pipe(log,{end:false});child.stderr.pipe(log,{end:false});
  child.once('error',reject);child.once('close',code=>{log.end();code===0?done():reject(Error('Diagnostic exited '+code));});
 });
 console.log('Finished seed '+seed);
}
