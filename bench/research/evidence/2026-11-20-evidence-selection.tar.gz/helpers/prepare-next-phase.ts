import {readFileSync,writeFileSync,mkdirSync,cpSync} from 'node:fs';
import {join} from 'node:path';
const old='/private/tmp/pr3-evidence-selection-2026-11-20',work='/private/tmp/pr3-evidence-completeness-2026-11-20';
mkdirSync(work);
for(const name of ['run-matrices.ts','freeze-build.ts','check-freeze.ts','next-review.ts','record-review.ts','power-summary.ts','audit-inference.ts','check-inference.ts','read-evidence.ts']) {
 const text=readFileSync(join(old,name),'utf8').replaceAll(old,work).replaceAll('evidence-selection-dev-2026-11-20','evidence-completeness-dev-2026-11-20').replaceAll('evidence-selection-exposed-2026-11-20','evidence-completeness-exposed-2026-11-20');
 writeFileSync(join(work,name),text,{flag:'wx'});
}
for(const name of ['development','exposed']) {
 const dir=join(work,'archive',name);mkdirSync(dir,{recursive:true});
 for(const helper of ['replay.ts','check-replay.ts'])cpSync(join(old,'archive',name,helper),join(dir,helper),{force:false,errorOnExist:true});
}
writeFileSync(join(work,'scope.json'),JSON.stringify({scope:'Follow-up completeness fix after the full selection8 rerun. Both unchanged exposed matrices; all seeds/models; all actual answers reviewed. Previous attempts remain in the selection archive. No retry substitution.',previousEvidence:'2026-11-20-evidence-selection.tar.gz',models:['4B','27B'],seeds:[1,2,7]},null,2)+'\n',{flag:'wx'});
console.log('Prepared separate follow-up evaluation helpers; production unchanged.');
