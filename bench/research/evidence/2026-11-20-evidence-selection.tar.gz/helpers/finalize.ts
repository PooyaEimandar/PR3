import {cpSync,createReadStream,existsSync,mkdirSync,mkdtempSync,readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {isDeepStrictEqual} from 'node:util';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const work='/private/tmp/pr3-evidence-selection-2026-11-20',stage=join(work,'archive');
const dest=join(root,'bench/research/evidence'),prefix='2026-11-20-evidence-selection';
const tag=process.argv[2]??'selection8';
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const run=(dir:string,file:string,args:string[]=[])=>JSON.parse(execFileSync(process.execPath,[join(dir,file),...args],{cwd:dir,encoding:'utf8'}));
const summaries:Record<string,unknown>={},controls:Record<string,unknown>={},inference:Record<string,unknown>={},inferenceControls:Record<string,unknown>={};
let finalManifest:any;
for(const [name,folder]of [['development','evidence-selection-dev-2026-11-20'],['exposed','evidence-selection-exposed-2026-11-20']]){
  const matrix=join(root,'bench/research/result',folder!),target=join(stage,name!);
  const manifest=read(join(matrix,'manifest.json'));finalManifest=manifest;
  if(!read(join(matrix,'progress.json')).complete||!read(join(matrix,'source-review.json')).complete)throw Error('Evaluation/review incomplete: '+name);
  if(hash(manifest.binary)!==manifest.binarySha256)throw Error('Frozen executable changed');
  for(const[p,h]of Object.entries(manifest.productionSources))if(hash(join(root,p))!==h||hash(join(work,'source-'+tag,p))!==h)throw Error('Frozen source changed: '+p);
  if(!existsSync(join(matrix,'review-required.json')))execFileSync(process.execPath,[join(root,'bench/research/review-reliability.ts'),matrix],{cwd:root,stdio:['ignore','ignore','inherit']});
  cpSync(matrix,join(target,'matrix'),{recursive:true,errorOnExist:true,force:false});
  cpSync(join(work,'source-'+tag),join(target,'source'),{recursive:true,errorOnExist:true,force:false});
  for(const helper of ['audit-inference.ts','check-inference.ts'])cpSync(join(work,helper),join(target,helper));
  summaries[name!]=run(target,'replay.ts');controls[name!]=run(target,'check-replay.ts');
  inference[name!]=run(target,'audit-inference.ts',[join(target,'matrix')]);inferenceControls[name!]=run(target,'check-inference.ts',[join(target,'matrix')]);
  for(const [file,value]of [['summary.json',summaries[name!]],['controls.json',controls[name!]],['inference.json',inference[name!]],['inference-controls.json',inferenceControls[name!]]])writeFileSync(join(target,file as string),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
}
for(const model of finalManifest.models){const h=createHash('sha256');for await(const part of createReadStream(model.path))h.update(part);if(h.digest('hex')!==model.sha256)throw Error('Model changed: '+model.name);}
const candidate=join(root,'bench/research/result/evidence-selection-format-candidate-2026-11-20');
const candidateManifest=read(join(candidate,'manifest.json'));
if(hash(candidateManifest.binary)!==candidateManifest.binarySha256)throw Error('Candidate binary changed');
for(const[p,h]of Object.entries(candidateManifest.productionSources))if(hash(join(work,'source-selection4',p))!==h)throw Error('Candidate source changed');
mkdirSync(join(stage,'format-candidate'),{recursive:true});cpSync(candidate,join(stage,'format-candidate','matrix'),{recursive:true});
for(const name of ['verification','exploratory','helpers','builds'])mkdirSync(join(stage,name),{recursive:true});
const inspection=join(root,'bench/research/result/evidence-selection-inspection-candidate-2026-11-20');
const inspectionManifest=read(join(inspection,'manifest.json'));
if(hash(inspectionManifest.binary)!==inspectionManifest.binarySha256)throw Error('Inspection candidate binary changed');
for(const[p,h]of Object.entries(inspectionManifest.productionSources))if(hash(join(work,'source-selection6',p))!==h)throw Error('Inspection candidate source changed');
mkdirSync(join(stage,'inspection-candidate'),{recursive:true});cpSync(inspection,join(stage,'inspection-candidate','matrix'),{recursive:true});
for(const build of ['audit','selection1','selection2','selection3','selection4','selection5','selection6','selection7'])cpSync(join(work,'source-'+build),join(stage,'builds',build),{recursive:true});
cpSync(join(work,'diagnostic-audit'),join(stage,'exploratory','diagnostic-audit'),{recursive:true});
cpSync(join(work,'interim-audit'),join(stage,'verification','interim-audit'),{recursive:true});
for(const entry of readdirSync(work,{withFileTypes:true})){
  if(!entry.isFile())continue;
  if(/\.ts$/.test(entry.name))cpSync(join(work,entry.name),join(stage,'helpers',entry.name));
  else if(/\.(?:json|jsonl|log|patch)$/.test(entry.name)){
    const verify=/^(?:workspace-|clippy-|host-tests-|technical-tests-|selection-tests-|quotation-tests-|format-|token-budget|typescript|performance|matrices)/.test(entry.name);
    cpSync(join(work,entry.name),join(stage,verify?'verification':'exploratory',entry.name));
  }
}
const summary={scope:'PR3-only exposed development and now-exposed former generalization regressions. Unblinded implementation-assistant review, not independent held-out evidence or a matched OpenJarvis comparison. No failed-case retry substitution in either final matrix.',binarySha256:finalManifest.binarySha256,development:summaries.development,exposed:summaries.exposed,inference};
writeFileSync(join(stage,'summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
const archive=join(dest,prefix+'.tar.gz');if(existsSync(archive))throw Error('Archive exists');
execFileSync('tar',['-czf',archive,'-C',stage,'.'],{env:{...process.env,COPYFILE_DISABLE:'1'}});
const extracted=mkdtempSync(join(tmpdir(),'pr3-selection-verify-'));execFileSync('tar',['-xzf',archive,'-C',extracted]);
for(const name of ['development','exposed']){
  const dir=join(extracted,name),matrix=join(dir,'matrix');
  if(!isDeepStrictEqual(summaries[name],run(dir,'replay.ts'))||!isDeepStrictEqual(controls[name],run(dir,'check-replay.ts'))||!isDeepStrictEqual(inference[name],run(dir,'audit-inference.ts',[matrix]))||!isDeepStrictEqual(inferenceControls[name],run(dir,'check-inference.ts',[matrix])))throw Error('Extracted replay mismatch: '+name);
}
const verification={verifiedAt:new Date().toISOString(),archiveSha256:hash(archive),binarySha256:finalManifest.binarySha256,currentSourcesMatchFrozenManifest:true,frozenExecutableMatchesManifest:true,modelFilesMatchManifest:true,extractedReplaysMatch:true,controls,inferenceControls};
writeFileSync(join(dest,prefix+'-summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
writeFileSync(join(dest,prefix+'-archive-check.json'),JSON.stringify(verification,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({archive,archiveSha256:verification.archiveSha256},null,2));
