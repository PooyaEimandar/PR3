import {readFileSync,writeFileSync} from 'node:fs';
const work='/private/tmp/pr3-evidence-selection-2026-11-20';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const basic=JSON.parse(readFileSync(`${root}/bench/research/result/quality-2026-11-20-final/corpus.json`,'utf8')).cases.slice(0,9);
const technical=JSON.parse(readFileSync(`${work}/diagnostic.json`,'utf8')).cases;
const cases=[...basic,...technical];
writeFileSync(`${work}/format-diagnostic.json`,JSON.stringify({status:'Exposed formatting and technical-page diagnostic; unchanged cases, not a holdout.',cases},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({cases:cases.length,turns:cases.reduce((n,c)=>n+(c.restart?2:1),0)}));
