import {mkdirSync,cpSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
const work='/private/tmp/pr3-evidence-selection-2026-11-20',dir=`${work}/diagnostic-audit`;
mkdirSync(dir);
cpSync(`${work}/selection4-4b-seed1.jsonl`,`${dir}/4b-seed1.jsonl`);
writeFileSync(`${dir}/manifest.json`,JSON.stringify({diagnosticOnly:true,expectedTurns:5}));
writeFileSync(`${dir}/progress.json`,JSON.stringify({complete:true,runs:[{model:'Qwen3.5-4B-Q4_K_M.gguf',file:'4b-seed1.jsonl',seed:1}]}));
for(const [script,out]of [['audit-inference.ts','summary.json'],['check-inference.ts','controls.json']]){
  const result=execFileSync(process.execPath,[`${work}/${script}`,dir],{encoding:'utf8'});writeFileSync(`${dir}/${out}`,result);console.log(result);
}
