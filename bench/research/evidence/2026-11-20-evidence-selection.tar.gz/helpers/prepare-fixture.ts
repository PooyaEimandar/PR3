import {readFileSync, writeFileSync, mkdirSync} from 'node:fs';
const work='/private/tmp/pr3-evidence-selection-2026-11-20';
const corpus=JSON.parse(readFileSync(`${work}/diagnostic.json`,'utf8'));
const rows=readFileSync(`${work}/audit-4b-seed1.jsonl`,'utf8').trim().split('\n').map(line=>JSON.parse(line));
const fixtures=rows.map(row=>({id:row.id,query:corpus.cases.find((c:{id:string})=>c.id===row.id).topic,
  sources:row.turns[0].evidence.sources.map((s:{text:string;title:string;location:string},i:number)=>({source:`s:${row.id}:${i}`,origin:row.id,text:s.text,title:s.title,location:s.location}))}));
const dir='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/crate/pr3-llamacpp/tests/fixtures';
mkdirSync(dir,{recursive:true});
writeFileSync(`${dir}/technical-evidence.json`,JSON.stringify({provenance:'Saved passages from the exposed 2026-11-20 Python 3.13, Git diff and Cargo features fixtures; original text and part locations, no model answers.',cases:fixtures},null,2)+'\n',{flag:'wx'});
