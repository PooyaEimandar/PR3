import {readFileSync,writeFileSync,mkdirSync,copyFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
const work='/private/tmp/pr3-evidence-selection-2026-11-20';
const matrix='bench/research/result/evidence-selection-dev-2026-11-20';
const progress=JSON.parse(readFileSync(join(matrix,'progress.json'),'utf8'));
const manifest=JSON.parse(readFileSync(join(matrix,'manifest.json'),'utf8'));
const out=join(work,'interim-audit');mkdirSync(out);
for(const run of progress.runs)copyFileSync(join(matrix,run.file),join(out,run.file));
writeFileSync(join(out,'progress.json'),JSON.stringify({...progress,complete:true,scope:'Only already completed runs; this is not the full matrix.'}));
writeFileSync(join(out,'manifest.json'),JSON.stringify({...manifest,diagnosticOnly:true,expectedTurns:progress.runs.reduce((n,r)=>n+r.turns,0)}));
for(const [script,file]of [['audit-inference.ts','summary.json'],['check-inference.ts','controls.json']]){
 const result=execFileSync(process.execPath,[join(work,script),out],{encoding:'utf8'});
 writeFileSync(join(out,file),result,{flag:'wx'});console.log(result);
}
