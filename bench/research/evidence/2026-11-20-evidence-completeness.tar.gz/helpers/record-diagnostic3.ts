import {readFileSync,writeFileSync} from 'node:fs';
const work='/private/tmp/pr3-evidence-completeness-2026-11-20';
const turns=readFileSync(work+'/diagnostic3-4b-seed1.jsonl','utf8').trim().split('\n').flatMap(line=>{const row=JSON.parse(line);return row.turns.map((t,turn)=>({id:row.id,turn}));});
if(turns.length!==3)throw Error('Diagnostic incomplete');
const reasons=['Substantive Keene historian/exhibition quotations with no namesake evidence.','Same saved substantive biography after restart; duplicate findings cosmetic; no rejected calls or runtime loop.','Both roles separately quoted with explicit uncertainty about identity; missing mentions not treated as absence of work.'];
writeFileSync(work+'/diagnostic3-review.json',JSON.stringify({scope:'Unblinded implementation-assistant diagnostic review, not independent validation or final-matrix evidence.',build:'completeness3',binarySha256:'e60b538a3451cbc6d4dede1178796b5154dbb8a88d367ab084fea8fd94427b9e',model:'Qwen3.5-4B-Q4_K_M.gguf',seed:1,complete:true,decisions:turns.map((t,i)=>({...t,pass:true,reason:reasons[i]}))},null,2)+'\n',{flag:'wx'});
