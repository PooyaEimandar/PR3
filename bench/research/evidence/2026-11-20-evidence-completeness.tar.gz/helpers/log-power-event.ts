import {appendFileSync} from 'node:fs';
const event=process.argv[2];if(!event)throw Error('Event required');
appendFileSync('/private/tmp/pr3-evidence-completeness-2026-11-20/power-events.jsonl',JSON.stringify({at:new Date().toISOString(),event})+'\n');
