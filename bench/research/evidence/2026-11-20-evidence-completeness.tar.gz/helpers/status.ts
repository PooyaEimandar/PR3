import {existsSync,readFileSync} from 'node:fs';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/research/result';
for(const name of ['evidence-completeness-dev-2026-11-20','evidence-completeness-exposed-2026-11-20']){
 const dir=root+'/'+name;if(!existsSync(dir+'/manifest.json'))continue;
 const manifest=JSON.parse(readFileSync(dir+'/manifest.json','utf8'));
 const review=existsSync(dir+'/source-review.json')?JSON.parse(readFileSync(dir+'/source-review.json','utf8')).decisions:[];
 const runs=[];
 for(const model of ['4b','27b'])for(const seed of [1,2,7]){
  const file=`${dir}/${model}-seed${seed}.jsonl`;if(!existsSync(file))continue;
  const rows=readFileSync(file,'utf8').split('\n').slice(0,-1).map(line=>JSON.parse(line));
  const decisions=review.filter(d=>d.seed===seed&&d.model.includes(model==='4b'?'-4B-':'-27B-'));
  runs.push({model,seed,completedTurns:rows.reduce((n,r)=>n+r.turns.length,0),lastCase:rows.at(-1)?.id,reviewed:decisions.length,mainPass:decisions.filter(d=>d.pass).length,strictPass:decisions.filter(d=>d.pass&&!d.borderline).length});
 }
 console.log(JSON.stringify({matrix:name,expected:manifest.expectedTurns,reviewed:review.length,runs}));
}
