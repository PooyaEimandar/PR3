import { spawn, execFileSync } from 'node:child_process';
import { appendFileSync } from 'node:fs';
import { basename } from 'node:path';
import { loadavg, freemem } from 'node:os';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const work='/private/tmp/pr3-evidence-completeness-2026-11-20';
const binary=process.argv[2];
if(!binary)throw Error('FROZEN_BINARY required');
const sample=()=>{
  const categories={model:0,compiler:0,other:0};
  for(const line of execFileSync('ps',['-Ao','pcpu=,comm='],{encoding:'utf8'}).split('\n')) {
    const m=line.trim().match(/^([\d.]+)\s+(.+)$/);if(!m)continue;
    const name=basename(m[2]!);const type=name===basename(binary)?'model':/^(?:rustc|cargo|clang|cmake|ninja|ld)$/.test(name)?'compiler':'other';
    categories[type]+=Number(m[1]);
  }
  appendFileSync(`${work}/performance.jsonl`,JSON.stringify({at:new Date().toISOString(),loadavg:loadavg(),freeBytes:freemem(),cpu:categories,power:execFileSync('pmset',['-g','batt'],{encoding:'utf8'}).trim()})+'\n');
};
sample();const timer=setInterval(sample,30000);
try {
  for(const [name,baseline] of [['evidence-completeness-dev-2026-11-20','quality-2026-11-20-final'],['evidence-completeness-exposed-2026-11-20','generalization-2026-11-20']]) {
    console.log(JSON.stringify({matrix:name,startedAt:new Date().toISOString()}));
    await new Promise<void>((done,reject)=>{
      const child=spawn(process.execPath,['bench/research/run-reliability.ts',binary,`bench/research/result/${name}`,`bench/research/result/${baseline}/corpus.json`,'--replay-only'],{cwd:root,stdio:'inherit'});
      child.once('error',reject);child.once('exit',code=>code===0?done():reject(Error(`Matrix exited ${code}; preserve partial output`)));
    });
    console.log(JSON.stringify({matrix:name,finishedAt:new Date().toISOString()}));
  }
} finally {sample();clearInterval(timer);}
