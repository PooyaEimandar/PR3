import {readFileSync,readdirSync,existsSync,mkdirSync,cpSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join,dirname} from 'node:path';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3',old='/private/tmp/pr3-evidence-selection-2026-11-20',work='/private/tmp/pr3-evidence-completeness-2026-11-20';
const archive=join(root,'bench/research/evidence/2026-11-20-evidence-selection.tar.gz');
const check=JSON.parse(readFileSync(join(root,'bench/research/evidence/2026-11-20-evidence-selection-archive-check.json'),'utf8'));
const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
if(hash(archive)!==check.archiveSha256||!check.extractedReplaysMatch)throw Error('Previous matrix not verified');
if(existsSync(join(work,'applied-candidate.json')))throw Error('Candidate already applied');
const collect=(dir:string,prefix=''):string[]=>readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?collect(join(dir,e.name),join(prefix,e.name)):[join(prefix,e.name)]);
const files=collect(join(old,'candidate9'));
for(const file of files){
 const current=join(root,file),frozen=join(old,'source-selection8',file);
 if(existsSync(frozen)){if(!readFileSync(current).equals(readFileSync(frozen)))throw Error('Current source changed: '+file);}
 else if(existsSync(current))throw Error('Unexpected existing file: '+file);
}
cpSync(join(old,'candidate9'),join(work,'candidate-before-validation'),{recursive:true,errorOnExist:true,force:false});
for(const file of files){mkdirSync(dirname(join(root,file)),{recursive:true});cpSync(join(old,'candidate9',file),join(root,file));}
writeFileSync(join(work,'applied-candidate.json'),JSON.stringify({appliedAt:new Date().toISOString(),previousArchiveSha256:check.archiveSha256,files:Object.fromEntries(files.map(file=>[file,hash(join(root,file))]))},null,2)+'\n',{flag:'wx'});
console.log('Applied '+files.length+' candidate files after verifying archived prior build.');
