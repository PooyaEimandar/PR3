import {readFileSync,writeFileSync} from 'node:fs';
const work='/private/tmp/pr3-evidence-completeness-2026-11-20';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/research/result';
const original=['quality-2026-11-20-final','generalization-2026-11-20'].flatMap(folder=>JSON.parse(readFileSync(root+'/'+folder+'/corpus.json','utf8')).cases);
const cases=original.filter(c=>['late-comparison-restart','public-sqlite-comparison-restart','fresh-french-conditions','fresh-persian-recovery'].includes(c.id));
if(cases.length!==4)throw Error('Missing case');
writeFileSync(work+'/diagnostic4.json',JSON.stringify({status:'Unchanged exposed correction-scope diagnostic subset; not a holdout or replacement for final matrix.',cases},null,2)+'\n',{flag:'wx'});
