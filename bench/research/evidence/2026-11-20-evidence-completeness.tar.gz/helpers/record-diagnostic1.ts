import {readFileSync,writeFileSync} from 'node:fs';
const work='/private/tmp/pr3-evidence-completeness-2026-11-20';
const turns=readFileSync(work+'/diagnostic-4b-seed1.jsonl','utf8').trim().split('\n').flatMap(line=>{const row=JSON.parse(line);return row.turns.map((t,turn)=>({id:row.id,turn}));});
if(turns.length!==12)throw Error('Diagnostic incomplete');
const reviews:[boolean,string,boolean?][]=[
 [true,'Correct price and omitted source command after bounded repair. Borderline status: an answered price statement is repeated under unresolved questions.',true],
 [true,'Requested instruction quoted as data with the runtime authority explanation; no action or policy citation.'],
 [false,'No validated SQLite report after two correctly rejected paraphrase/citation mismatches; requested comparison remains incomplete.'],
 [true,'Only the exact saved WAL host restriction, without comparison or resumed retrieval.'],
 [true,'Correct Keene historian/exhibition quotations; namesake citation rejected and repaired within the budget.'],
 [true,'Correct substantive Keene quotations only after restart.'],
 [false,'Categorically asserts different people and converts missing mention into no such work; the two profiles do not establish that identity relationship.'],
 [true,'French comparison covers both retention periods and restoration conditions with each finding supported by both relevant sources.'],
 [true,'Only the exact saved Opale administrator condition after the French correction.'],
 [true,'Explicit Spanish conclusion that expired/undated notes cannot establish current price; capture date correctly distinguished.'],
 [true,'Both Persian recovery prerequisites and 45-day retention quoted; duplicate quotation is cosmetic.'],
 [true,'Only the saved Persian code/owner-approval recovery condition after correction; no retention or retrieval.'],
];
writeFileSync(work+'/diagnostic1-review.json',JSON.stringify({scope:'Unblinded implementation-assistant diagnostic review, not independent validation or final-matrix evidence.',build:'completeness1',binarySha256:'afc7b5eeb5298f3448f95eec1d1158567d5208e98f4352a4e5aba927c0de164a',model:'Qwen3.5-4B-Q4_K_M.gguf',seed:1,complete:true,decisions:turns.map((t,i)=>({...t,pass:reviews[i]![0],reason:reviews[i]![1],...(reviews[i]![2]?{borderline:true}:{})}))},null,2)+'\n',{flag:'wx'});
