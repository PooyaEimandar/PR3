import {readFileSync,writeFileSync} from 'node:fs';
const work='/private/tmp/pr3-evidence-completeness-2026-11-20';
const original=JSON.parse(readFileSync(work+'/diagnostic.json','utf8'));
const cases=original.cases.filter(c=>['fresh-similar-name','fresh-identical-name'].includes(c.id));
if(cases.length!==2)throw Error('Missing case');
writeFileSync(work+'/diagnostic3.json',JSON.stringify({status:'Unchanged exposed biography diagnostic subset; not a holdout or replacement for final matrix.',cases},null,2)+'\n',{flag:'wx'});
