import {readFileSync,writeFileSync} from 'node:fs';
const work='/private/tmp/pr3-evidence-completeness-2026-11-20';
const turns=readFileSync(work+'/diagnostic4-4b-seed1.jsonl','utf8').trim().split('\n').flatMap(line=>{const row=JSON.parse(line);return row.turns.map((t,turn)=>({id:row.id,turn}));});
if(turns.length!==8)throw Error('Diagnostic incomplete');
const reasons=[
 'All three SQLite commit-reader/host facts quoted, including the full rollback condition and antecedent.',
 'Only the saved same-host restriction after correction.',
 'All three late-page comparison facts correctly quoted.',
 'Only the corrected host restriction; the fitted restart view also excludes the obsolete reader passage.',
 'French comparison covers both retention periods and both restoration conditions. Borderline per-finding support: the local-key condition in finding 1 is quoted only in finding 2.',
 'Only the saved Opale administrator condition after correction.',
 'Persian quotation includes retention and both recovery prerequisites; duplication cosmetic.',
 'Only code and owner approval after the Persian correction.',
];
writeFileSync(work+'/diagnostic4-review.json',JSON.stringify({scope:'Unblinded implementation-assistant diagnostic review, not independent validation or final-matrix evidence.',build:'completeness4',binarySha256:'caf0999241365b0402079cb41f3c05ae410314bd3c280e9dd6fb04271f087d9b',model:'Qwen3.5-4B-Q4_K_M.gguf',seed:1,complete:true,decisions:turns.map((t,i)=>({...t,pass:true,reason:reasons[i],...(i===4?{borderline:true}:{})}))},null,2)+'\n',{flag:'wx'});
