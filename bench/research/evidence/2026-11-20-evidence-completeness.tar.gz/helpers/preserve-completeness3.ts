import {readFileSync,writeFileSync,renameSync,mkdirSync,cpSync} from 'node:fs';
const work='/private/tmp/pr3-evidence-completeness-2026-11-20';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const source=root+'/bench/research/result/evidence-completeness-dev-2026-11-20';
const dest=source+'-candidate3';
const review=JSON.parse(readFileSync(source+'/source-review.json','utf8'));
const files=['4b-seed1.jsonl','4b-seed2.jsonl','4b-seed7.jsonl','27b-seed1.jsonl','27b-seed2.jsonl'];
let turns=0;for(const file of files){const raw=readFileSync(source+'/'+file,'utf8');if(raw&&!raw.endsWith('\n'))throw Error('Partial JSON line requires preservation and separate inspection');turns+=raw.trim().split('\n').filter(Boolean).reduce((n,line)=>n+JSON.parse(line).turns.length,0);}
if(turns!==112||review.decisions.length!==turns)throw Error('Partial review incomplete');
const summary={complete:false,scope:'Interrupted candidate3 development evaluation; all completed answers reviewed, not substituted into the final full matrix.',reason:'A confirmed negated-comparison bug still enabled comparison guidance and disabled focused evidence pruning after a correction.',stoppedAt:new Date().toISOString(),binarySha256:'e60b538a3451cbc6d4dede1178796b5154dbb8a88d367ab084fea8fd94427b9e',turns,sourceReviewedPass:review.decisions.filter(d=>d.pass).length,strictPass:review.decisions.filter(d=>d.pass&&!d.borderline).length,failures:review.decisions.filter(d=>!d.pass),borderlines:review.decisions.filter(d=>d.borderline)};
writeFileSync(source+'/partial-candidate.json',JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
renameSync(source,dest);
renameSync(work+'/matrices.log',work+'/matrices-completeness3-partial.log');
renameSync(work+'/performance.jsonl',work+'/performance-completeness3-partial.jsonl');
mkdirSync(work+'/partial',{recursive:true});cpSync(dest,work+'/partial/completeness3-development',{recursive:true,errorOnExist:true,force:false});
writeFileSync(work+'/partial-completeness3-summary.json',JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({turns,main:summary.sourceReviewedPass,strict:summary.strictPass}));
