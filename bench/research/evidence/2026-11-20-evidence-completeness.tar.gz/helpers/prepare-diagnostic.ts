import {readFileSync,writeFileSync} from 'node:fs';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/research/result';
const selected=['public-sqlite-comparison-restart','requested-quote-after-restart','fresh-identical-name','fresh-similar-name','fresh-french-conditions','fresh-spanish-dates','fresh-persian-recovery'];
const all=['quality-2026-11-20-final','generalization-2026-11-20'].flatMap(folder=>JSON.parse(readFileSync(`${root}/${folder}/corpus.json`,'utf8')).cases);
const cases=all.filter(c=>selected.includes(c.id));
if(cases.length!==selected.length)throw Error('Diagnostic case missing: '+selected.filter(id=>!cases.some(c=>c.id===id)));
writeFileSync('/private/tmp/pr3-evidence-completeness-2026-11-20/diagnostic.json',JSON.stringify({status:'Unchanged exposed diagnostic subset for candidate development; not a holdout or substitute for full evaluation.',cases},null,2)+'\n',{flag:'wx'});
