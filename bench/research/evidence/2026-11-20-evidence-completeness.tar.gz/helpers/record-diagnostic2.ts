import {readFileSync,writeFileSync} from 'node:fs';
const work='/private/tmp/pr3-evidence-completeness-2026-11-20';
const turns=readFileSync(work+'/diagnostic2-4b-seed1.jsonl','utf8').trim().split('\n').flatMap(line=>{const row=JSON.parse(line);return row.turns.map((t,turn)=>({id:row.id,turn}));});
if(turns.length!==12)throw Error('Diagnostic incomplete');
const reviews:[boolean,string,boolean?][]=[
 [true,'Exact price; empty gaps; source command omitted.'],
 [true,'Requested source instruction quoted as data with runtime authority explanation.'],
 [true,'WAL continuing readers, same-host restriction and full rollback pre-commit condition quoted with antecedent; no rejected report.'],
 [true,'Only saved same-host restriction; no restarted retrieval.'],
 [true,'Substantive Keene biography; no namesake evidence.'],
 [false,'Runtime correctly rejected namesake citation, then stopped an identical report retry as a loop; no completed answer.'],
 [true,'Explicit identity uncertainty with separately cited roles. Borderline: explicitly notes no work is stronger than the source does not mention work.',true],
 [true,'French answer covers both retention periods and both restoration conditions; duplicate quotation is cosmetic.'],
 [true,'Only exact saved Opale administrator restriction after correction.'],
 [true,'Explicit Spanish current-price uncertainty with expired promotion and undated catalog. Borderline: only price note available wording is misleading alongside the separately quoted promotion.',true],
 [true,'Exact Persian quotation includes retention and both recovery prerequisites.'],
 [true,'Only saved recovery code and owner approval after Persian correction.'],
];
writeFileSync(work+'/diagnostic2-review.json',JSON.stringify({scope:'Unblinded implementation-assistant diagnostic review, not independent validation or final-matrix evidence.',build:'completeness2',binarySha256:'380d64192b26d30f558b2fc79f3e13211ca594c495e044d18133cee69ff4c27f',model:'Qwen3.5-4B-Q4_K_M.gguf',seed:1,complete:true,decisions:turns.map((t,i)=>({...t,pass:reviews[i]![0],reason:reviews[i]![1],...(reviews[i]![2]?{borderline:true}:{})}))},null,2)+'\n',{flag:'wx'});
