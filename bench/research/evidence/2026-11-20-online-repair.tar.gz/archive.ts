import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const work='/private/tmp/pr3-online-fix';
const evidence=root+'/bench/research/evidence';
const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
for (const [from,to] of [
  ['2026-11-20-online-repair-summary.json','summary.json'],
  ['2026-11-20-online-repair-report.md','report.md'],
  ['2026-11-20-android-online-repair-v2.json','android-install.json'],
]) copyFileSync(join(evidence,from),join(work,to));
const files=['manifest.json','final-source','identity-candidate-manifest.json','identity-candidate-source','heading-candidate-manifest.json','heading-candidate-source','excerpt-candidate-manifest.json','excerpt-candidate-source','live-attempts.jsonl','baseline-live.jsonl','summary.json','report.md','android-install.json','before-regression.log','excerpt-regression.log','workspace-final-v6.log','research-final-v5.log','clippy-final-v6.log','e2e-v6.log','typescript-tests.log','macos-build-v6.log','android-build-v6.log','android-package-check-v2.json','summarize.ts','archive.ts'];
const archive=join(evidence,'2026-11-20-online-repair.tar.gz');
execFileSync('tar',['-czf',archive,'-C',work,...files]);
const scratch=mkdtempSync('/private/tmp/pr3-online-archive-check-');
let verified=0;
try {
  execFileSync('tar',['-xzf',archive,'-C',scratch]);
  const manifest=JSON.parse(readFileSync(join(scratch,'manifest.json'),'utf8'));
  for (const [p,expected] of Object.entries(manifest.productionSources)) {
    if(hash(join(scratch,'final-source',p))!==expected)throw Error('Source archive mismatch: '+p);
    verified++;
  }
  for(const p of files.filter(p=>!p.endsWith('-source'))) {
    if(hash(join(scratch,p))!==hash(join(work,p)))throw Error('Artifact archive mismatch: '+p);
  }
} finally {rmSync(scratch,{recursive:true,force:true});}
const result={checkedAt:new Date().toISOString(),archive:'2026-11-20-online-repair.tar.gz',archiveSha256:hash(archive),frozenSourcesVerified:verified,filesVerifiedAfterExtraction:true,excludes:['API keys','encrypted app databases','original app configuration','unrelated personal traces','model weights','APK binaries'],scope:'Archive integrity only. Live outcome status is recorded separately in the report and summary.'};
writeFileSync(join(evidence,'2026-11-20-online-repair-archive-check.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));
