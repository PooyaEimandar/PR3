import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const root = '/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const work = '/private/tmp/pr3-online-fix';
const rows = readFileSync(work + '/live-attempts.jsonl', 'utf8').trim().split('\n').map(line => JSON.parse(line));
const reviews = [
  {phase:'baseline', pass:false, reason:'Tavily returned five candidates, but the model did not read a page. It twice cited discovery snippets/candidate IDs, then returned zero supported findings.'},
  {phase:'read-and-repair-candidate', pass:false, reason:'Read pages and produced valid quotations, but merged a different person sharing the given name into the biography. Additional paraphrases were not fully supported by their quotations.'},
  {phase:'identity-candidate', pass:false, reason:'The namesake was excluded, but the answer included a heading-only finding and an AI-applications paraphrase unsupported by its attached quotation. The full page separately mentions AI products; this review is about citation support, not a claim that the fact itself is false.'},
  {phase:'heading-candidate', pass:false, reason:'The model repeated a name-only heading after rejection and produced no validated report within four rounds.'},
  {phase:'excerpt-candidate-recovery', pass:true, reason:'Recovered the failed task after restart with Web off and no SEARCH/READ calls. Four substantive quoted facts. A literal empty-string gaps placeholder remains a presentation defect.'},
  {phase:'excerpt-candidate-live', pass:true, reason:'Fresh Tavily discovery read two pages and returned two supported quotations from the correct biography. Both quotations were visually checked in the saved passage.'},
  {phase:'excerpt-candidate-restart', pass:false, reason:'Runtime recovery succeeded without SEARCH/READ and repaired a rejected quotation within budget, but the report included a GitHub Follow label as a finding. Counted as an answer-quality failure; the final revision removes profile-only labels from inference choices and report findings.'},
  {phase:'final-live', pass:true, reason:'Exact user request: Tavily completed discovery, two pages were read, and the report returned two substantive quotations about the correct person, with no rejected calls. The source passage remained inspectable.'},
  {phase:'final-restart', pass:true, reason:'After full app restart with Web off, Continue returned four supported biographical quotations without SEARCH/READ or rejected calls. The previously cited source retained its identity and displayed capture time. Cosmetic defect: the gaps field displays /gaps.'},
];
if (rows.length !== reviews.length) throw Error('Every live attempt needs explicit review before publication');
const manifest = JSON.parse(readFileSync(work + '/manifest.json', 'utf8'));
for (const [path, expected] of Object.entries(manifest.productionSources)) {
  const actual = createHash('sha256').update(readFileSync(root + '/' + path)).digest('hex');
  if (actual !== expected) throw Error('Frozen source changed: ' + path);
}
const tests = readFileSync(work + '/workspace-final-v6.log', 'utf8');
const totals = [...tests.matchAll(/test result: ok\. (\d+) passed; 0 failed; (\d+) ignored/g)];
const result = {
  generatedAt: new Date().toISOString(), scope: manifest.scope,
  finalLiveStatus: 'passed exact online request and offline continuation after full macOS app restart; 4B only, one final task',
  finalMacBinarySha256: manifest.binarySha256,
  sourcesVerified: Object.keys(manifest.productionSources).length,
  regressions: {rustPassed: totals.reduce((s,m)=>s+Number(m[1]),0), rustIgnored: totals.reduce((s,m)=>s+Number(m[2]),0), nativeWorkflowsPassed: 9, stopTestsPassed: 4, researchHarnessTestsPassed: 9, finalFocusedResearchTestsPassed: 31, strictClippy: 'pass'},
  attempts: rows.map((r,i) => ({...reviews[i], query:r.query, seconds:r.ended_at-r.started_at, model:r.steps.find((s:any)=>s.step_type==='generate')?.input?.model, result:r.result, toolRounds:r.steps.filter((s:any)=>s.step_type==='generate' && s.output.tool_calls?.length).length, maxPromptTokens:Math.max(0,...r.steps.filter((s:any)=>s.step_type==='generate').map((s:any)=>s.output.prompt_tokens??0)), toolCalls:r.steps.filter((s:any)=>s.step_type==='tool_call').map((s:any)=>({tool:s.input.tool,success:s.output.success}))})),
};
for (const turn of result.attempts.slice(-2)) {
  if (!turn.toolCalls.every((t:any)=>t.success)) throw Error('Final turn has a rejected call');
  if (turn.toolRounds>4 || turn.toolCalls.length>12) throw Error('Execution limit exceeded');
}
if(result.attempts.at(-1)!.toolCalls.some((t:any)=>t.tool!=='answer_research')) throw Error('Restart performed retrieval');
const sources=(r:any)=>[...r.result.matchAll(/\[research:(\d+):[^\]]+\]/gu)].map((m:any)=>m[0]);
const onlineSources=sources(rows.at(-2)), restartedSources=sources(rows.at(-1));
if(!onlineSources.length||!restartedSources.length||!onlineSources.every((s:string)=>restartedSources.includes(s))) throw Error('Previously cited source identity changed across restart');
writeFileSync(root + '/bench/research/evidence/2026-11-20-online-repair-summary.json', JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({attempts:rows.length,regressions:result.regressions,final:result.attempts.slice(-2).map(({result,...r})=>r)}));
