import {readFileSync,writeFileSync,mkdirSync,cpSync} from 'node:fs';
import {join} from 'node:path';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const previous='/private/tmp/pr3-research-contract-2026-11-21';
const work='/private/tmp/pr3-research-coverage-2026-11-22';
for(const name of ['audit-inference.ts','check-inference.ts','check-freeze.ts','freeze-build.ts','status.ts','next-review.ts','record-review.ts','read-answers.ts','read-evidence.ts','read-generations.ts','read-summary.ts','inspect-rejections.ts','run-matrices.ts','power-summary.ts','log-power-event.ts','finalize.ts','validate.ts','collect-validation.ts','compare-prior.ts','final-metrics.ts','progress-audit.ts','check-doc-links.ts']) {
 const source=readFileSync(join(previous,name),'utf8')
 .replaceAll(previous,work)
 .replaceAll('2026-11-21-evidence-repair','2026-11-21-research-contract')
 .replaceAll('research-contract-dev-2026-11-21','research-coverage-dev-2026-11-22')
 .replaceAll('research-contract-exposed-2026-11-21','research-coverage-exposed-2026-11-22')
 .replaceAll("prefix='2026-11-21-research-contract'","prefix='2026-11-22-research-coverage'")
 .replaceAll('pr3-contract-verify-','pr3-coverage-verify-');
 writeFileSync(join(work,name),source,{flag:'wx'});
}
for(const matrix of ['development','exposed']){
 const dir=join(work,'archive',matrix);mkdirSync(dir,{recursive:true});
 for(const helper of ['replay.ts','check-replay.ts'])cpSync(join(previous,'archive',matrix,helper),join(dir,helper),{errorOnExist:true,force:false});
}
const wanted=new Set(['replay-h05','replay-h08','public-sqlite-comparison-restart','fresh-git-diff','fresh-similar-name','fresh-cargo-features','fresh-python-zip']);
const cases=['research-contract-dev-2026-11-21','research-contract-exposed-2026-11-21'].flatMap(name=>JSON.parse(readFileSync(join(root,'bench/research/result',name,'corpus.json'),'utf8')).cases).filter(c=>wanted.has(c.id));
writeFileSync(join(work,'targeted.json'),JSON.stringify({status:'Exposed targeted diagnostics. Unchanged cases, not held-out.',cases},null,2)+'\n',{flag:'wx'});
writeFileSync(join(work,'scope.json'),JSON.stringify({scope:'Fix eight remaining research failures. Full unchanged development and exposed matrices, 4B/27B seeds 1/2/7. Review every actual answer. No retry substitution or new held-out/OpenJarvis claim.',previousArchive:'2026-11-21-research-contract.tar.gz'},null,2)+'\n',{flag:'wx'});
console.log({targetedCases:cases.length,targetedTurns:cases.reduce((n,c)=>n+(c.restart?2:1),0)});
