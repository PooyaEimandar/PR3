import { readFileSync, writeFileSync, mkdirSync, cpSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { join, dirname } from 'node:path';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const out='/private/tmp/pr3-research-coverage-2026-11-22';
const tag=process.argv[2];
if(!tag)throw Error('TAG required');
const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const paths=execFileSync('rg',['--files','crate','app/pr3-app/src-tauri/src','app/pr3-app/src','app/pr3-app/ui','bench/research','bench/documents/src'],{cwd:root,encoding:'utf8'}).trim().split('\n').filter(p=>/\.(rs|ts|html|css|toml)$/.test(p)||/\/tests\/fixtures\/.*\.json$/.test(p));
const sources:Record<string,string>={};
mkdirSync(join(out,'source-'+tag));
for(const path of [...paths,'Cargo.lock','Cargo.toml','app/pr3-app/src-tauri/Cargo.toml','bench/documents/Cargo.toml']) {
  const target=join(out,'source-'+tag,path);mkdirSync(dirname(target),{recursive:true});
  cpSync(join(root,path),target,{errorOnExist:true,force:false});sources[path]=hash(target);
}
const binary=join(out,'research-'+tag);
cpSync(join(root,'target/debug/research'),binary,{errorOnExist:true,force:false});
const manifest={frozenAt:new Date().toISOString(),head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),binary,binarySha256:hash(binary),productionSources:sources};
writeFileSync(join(out,'build-freeze-'+tag+'.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
writeFileSync(join(out,'production-'+tag+'.patch'),execFileSync('git',['diff','--binary'],{cwd:root}),{flag:'wx'});
console.log(JSON.stringify({binarySha256:manifest.binarySha256,sourceFiles:Object.keys(sources).length}));
