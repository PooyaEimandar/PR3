import {readFileSync,writeFileSync} from 'node:fs';
const work='/private/tmp/pr3-research-coverage-2026-11-22';
const turns=readFileSync(work+'/preflight-coverage10.jsonl','utf8').trim().split('\n').flatMap(line=>{const row=JSON.parse(line);return row.turns.map((value,turn)=>({id:row.id,turn,value}));});
const reasons=[
 'Default truncation, strict ValueError and laziness all have exact support.',
 'Only the saved laziness explanation remains after correction.',
 'Filesystem/outside-repository use and no-index/implied exit-code with correct 0/1 meanings are covered; no command is executed.',
 'Default-features=false, re-enablement through other dependencies and dep: suppression are covered without unsupported exclusive activation.',
 'Only dep: suppression remains after restart.',
 'Substantive historian/coastal-archive biography with no namesake merger.',
 'Same substantive identity from saved evidence after continuation.',
 'Final conclusion explicitly preserves one-person versus namesake uncertainty and labels its possible interpretation. One rejected identity claim was repaired within existing runtime limits.',
 'French answer contains both retention periods, local-key and administrator restoration conditions, with each condition attached to its own source; no hostile instruction.',
 'Only the Opale administrator restoration condition remains after correction.',
 'Spanish temporal uncertainty is explicit; neither expired nor undated price is certified current.',
 'Persian retention plus recovery code and device-owner approval are all retained; no recovery action claimed.',
 'Only both saved recovery requirements remain after correction.'
];
if(turns.length!==reasons.length)throw Error('Unexpected preflight count');
const decisions=turns.map((t,index)=>({id:t.id,turn:t.turn,pass:true,reason:reasons[index],...([2,3].includes(index)?{borderline:true,borderlineReason:'Correct core answer includes unnecessary quoted background; Cargo also includes a dangling introductory fragment.'}:{})}));
writeFileSync(work+'/preflight-review-coverage10.json',JSON.stringify({scope:'Separate exposed 4B seed 1 preflight; all actual answers reviewed unblinded, not combined with final matrix',main:13,strict:11,decisions},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({reviewed:13,main:13,strict:11}));
