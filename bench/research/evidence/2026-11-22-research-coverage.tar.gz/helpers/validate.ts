import {spawn} from 'node:child_process';
import {openSync,appendFileSync} from 'node:fs';
const work='/private/tmp/pr3-research-coverage-2026-11-22';
const tag=process.argv[2];if(!tag)throw Error('TAG required');
for(const [label,command,args] of [
 ['format','cargo',['fmt','--all','--','--check']],
 ['workspace','cargo',['test','--workspace']],
 ['clippy','cargo',['clippy','--workspace','--all-targets','--','-D','warnings']],
 ['token-budget-grammar','cargo',['test','--workspace','actual_','--','--ignored','--test-threads=1']],
 ['whitespace','git',['diff','--check']],
] as const) {
 const path=`${work}/${label}-${tag}.log`,log=openSync(path,'wx');
 const start=new Date().toISOString();
 const code=await new Promise<number|null>((resolve,reject)=>{
  const p=spawn(command,[...args],{stdio:['ignore',log,log]});
  p.once('error',reject);p.once('exit',resolve);
 });
 const result={label,command,args,start,end:new Date().toISOString(),code,log:path};
 appendFileSync(`${work}/validation-${tag}.jsonl`,JSON.stringify(result)+'\n');
 console.log(JSON.stringify(result));
 if(code!==0)throw Error(label+' failed');
}
