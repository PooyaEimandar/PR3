/** Data-entry helper, ONLY for explicitly selected rows whose exact displayed
 * answers the reviewer has already compared. Never scores a new answer. */
import {readFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
const [dir,label,seedText,indicesText]=process.argv.slice(2);
if(!dir||!label||!seedText||!indicesText)throw Error('MATRIX LABEL SEED INDICES required');
const seed=Number(seedText),indices=JSON.parse(indicesText) as number[];
if(!Array.isArray(indices)||!indices.length||new Set(indices).size!==indices.length||indices.some(i=>!Number.isSafeInteger(i)||i<0))throw Error('Invalid explicit index selection');
const display=(text:string)=>text.replace(/ \[(?:research|document):[^\]\n]+\]/gu,'');
const readRun=(label:string,seed:number)=>readFileSync(join(dir,`${label}-seed${seed}.jsonl`),'utf8').split('\n').slice(0,-1).flatMap(line=>{
 const row=JSON.parse(line);return row.turns.map((value:any,turn:number)=>({id:row.id,turn,value}));
});
const current=readRun(label,seed),review=JSON.parse(readFileSync(join(dir,'source-review.json'),'utf8'));
const decisions=indices.map(index=>{
 const row=current[index];if(!row||row.value.error)throw Error('Missing or failed row: '+index);
 let prior;
 for(const d of review.decisions) {
  if(d.id!==row.id||d.turn!==row.turn)continue;
  const other=readRun(d.model.includes('-4B-')?'4b':'27b',d.seed).find(r=>r.id===row.id&&r.turn===row.turn);
  if(other&&!other.value.error&&display(other.value.answer)===display(row.value.answer)){prior=d;break;}
 }
 if(!prior)throw Error('No identical previously reviewed display: '+index);
 const [reason,borderline]=prior.reason.split(' Borderline: ');
 if(prior.borderline&&!borderline)throw Error('Missing prior borderline rationale');
 return [index,prior.pass,`Byte-identical display to reviewed ${prior.model}/seed${prior.seed}/${prior.id}/turn${prior.turn}. Same assessment: ${reason}`,...(prior.borderline?[borderline]:[])];
});
process.stdout.write(execFileSync(process.execPath,[join('/private/tmp/pr3-research-coverage-2026-11-22','record-review.ts'),dir,label,seedText,JSON.stringify(decisions)],{encoding:'utf8'}));
