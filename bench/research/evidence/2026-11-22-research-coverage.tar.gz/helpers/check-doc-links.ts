import {existsSync,readFileSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
let checked=0;
for(const file of process.argv.slice(2)){
 const text=readFileSync(file,'utf8');
 for(const match of text.matchAll(/\[[^\]]*\]\(([^)]+)\)/g)){
  const target=match[1]!;
  if(/^(?:https?:|#)/.test(target))continue;
  if(!existsSync(resolve(dirname(file),target.split('#')[0]!)))throw Error(`${file}: missing ${target}`);
  checked++;
 }
}
console.log(JSON.stringify({checkedLocalLinks:checked}));
