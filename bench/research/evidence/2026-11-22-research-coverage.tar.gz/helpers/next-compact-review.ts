/** Show new answers, or prove exact semantic-display equality to an already
 * reviewed answer of the same case/turn in THIS frozen matrix. Never grades. */
import {existsSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/research/result';
const display=(text:string)=>text.replace(/ \[(?:research|document):[^\]\n]+\]/gu,'');
const hash=(text:string)=>createHash('sha256').update(text).digest('hex');
const deadline=Date.now()+45000;
let pending:unknown[]=[];
do {
 pending=[];
 scan: for(const matrix of ['research-coverage-dev-2026-11-22','research-coverage-exposed-2026-11-22']) {
  const dir=join(root,matrix);if(!existsSync(join(dir,'corpus.json')))continue;
  const corpus=JSON.parse(readFileSync(join(dir,'corpus.json'),'utf8')).cases;
  const reviewPath=join(dir,'source-review.json');
  const decisions=existsSync(reviewPath)?JSON.parse(readFileSync(reviewPath,'utf8')).decisions:[];
  const runs=[];
  for(const label of ['4b','27b'])for(const seed of [1,2,7]) {
   const path=join(dir,`${label}-seed${seed}.jsonl`);if(!existsSync(path))continue;
   const rows=readFileSync(path,'utf8').split('\n').slice(0,-1).map(line=>JSON.parse(line));
   runs.push({label,seed,rows});
  }
  const decided=(label:string,seed:number,id:string,turn:number)=>decisions.find((d:any)=>d.model.includes(label==='4b'?'-4B-':'-27B-')&&d.seed===seed&&d.id===id&&d.turn===turn);
  const known=new Map<string,any>();
  for(const run of runs)for(const row of run.rows)for(const [turn,t] of row.turns.entries()) {
   const decision=decided(run.label,run.seed,row.id,turn);
   if(decision&&!t.error)known.set(`${row.id}/${turn}/${hash(display(t.answer))}`,{label:run.label,seed:run.seed,id:row.id,turn,decision});
  }
  for(const run of runs) {
   let index=0;
   for(const row of run.rows)for(const [turn,t] of row.turns.entries()) {
    const current=index++;if(decided(run.label,run.seed,row.id,turn)||pending.length>=8)continue;
    const test=corpus.find((c:any)=>c.id===row.id),answer=display(t.answer),sha256=hash(answer);
    const same=!t.error?known.get(`${row.id}/${turn}/${sha256}`):undefined;
    pending.push({matrix,label:run.label,seed:run.seed,index:current,id:row.id,turn,
     request:turn===0?test.topic:test.restart,rubric:(turn===0?test.review:test.restart_review??test.review)?.rubric,
     displaySha256:sha256,...(same?{sameDisplayAsReviewed:same}:{answer}),error:t.error,diagnosticPass:t.pass,seconds:t.seconds,
     traceRejections:t.traces.flatMap((trace:any)=>trace.steps).filter((s:any)=>s.step_type==='tool_call'&&s.output?.success===false).map((s:any)=>({tool:s.input?.tool,error:s.output?.result}))});
   }
   if(pending.length)break scan;
  }
 }
 if(pending.length>=8)break;
 if(Date.now()<deadline)await new Promise(resolve=>setTimeout(resolve,2000));
}while(Date.now()<deadline);
for(const row of pending)console.log(JSON.stringify(row));
if(!pending.length)console.log('No new complete case yet.');
