/** Preflight the verifier on the completed 4B subset; never alters full results. */
import {readFileSync,writeFileSync,cpSync,mkdtempSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {execFileSync} from 'node:child_process';
const work='/private/tmp/pr3-research-coverage-2026-11-22';
const original='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/research/result/research-coverage-dev-2026-11-22';
const fixture=mkdtempSync(join(tmpdir(),'pr3-plan-subset-'));
try{
 const manifest=JSON.parse(readFileSync(join(original,'manifest.json'),'utf8'));
 const progress=JSON.parse(readFileSync(join(original,'progress.json'),'utf8'));
 const runs=progress.runs.filter(run=>run.model.includes('-4B-'));
 if(runs.length!==3||runs.some(run=>run.turns!==27))throw Error('4B subset incomplete');
 for(const run of runs)cpSync(join(original,run.file),join(fixture,run.file));
 writeFileSync(join(fixture,'manifest.json'),JSON.stringify({...manifest,scope:'Verifier fixture from completed 4B subset, not a full matrix',models:manifest.models.filter(m=>m.name.includes('-4B-')),expectedTurns:81}));
 writeFileSync(join(fixture,'progress.json'),JSON.stringify({complete:true,runs}));
 const run=(file:string)=>JSON.parse(execFileSync(process.execPath,[join(work,file),fixture],{encoding:'utf8'}));
 const result={scope:'Preflight of citation-plan verifier on completed 4B subset only',audit:run('audit-plan.ts'),controls:run('check-plan.ts')};
 writeFileSync(join(work,'preflight-plan-controls.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(result,null,2));
}finally{rmSync(fixture,{recursive:true,force:true});}
