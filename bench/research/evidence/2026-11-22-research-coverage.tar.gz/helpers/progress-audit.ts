import {existsSync,readFileSync,readdirSync} from 'node:fs';
const base='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/research/result';
for(const folder of ['research-coverage-dev-2026-11-22','research-coverage-exposed-2026-11-22']){
 const dir=`${base}/${folder}`;if(!existsSync(dir))continue;
 let completedTurns=0,restartTurns=0;const restartRetrievals:unknown[]=[],rejectedCalls:unknown[]=[];
 for(const file of readdirSync(dir).filter(p=>/^(?:4b|27b)-seed(?:1|2|7)\.jsonl$/.test(p))){
  for(const line of readFileSync(`${dir}/${file}`,'utf8').split('\n').slice(0,-1)){
   const row=JSON.parse(line);
   for(const [turn,value]of row.turns.entries()){
    completedTurns++;if(turn>0)restartTurns++;
    const retrieval=value.events.filter((e:{name?:string})=>e.name==='research_sources'||e.name==='read_research_source');
    if(turn>0&&retrieval.length)restartRetrievals.push({file,id:row.id,turn,count:retrieval.length});
    const rejected=value.traces.flatMap((t:{steps:unknown[]})=>t.steps).filter((s:any)=>s.step_type==='tool_call'&&s.output?.success===false);
    if(rejected.length)rejectedCalls.push({file,id:row.id,turn,calls:rejected});
   }
  }
 }
 console.log(JSON.stringify({scope:'Partial progress audit, not a completed verification or answer score',folder,completedTurns,restartTurns,restartRetrievals,rejectedCalls}));
}
