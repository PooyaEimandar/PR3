import {readFileSync,writeFileSync} from 'node:fs';
const work='/private/tmp/pr3-research-coverage-2026-11-22';
const tag=process.argv[2];if(!tag)throw Error('TAG required');
const checks=readFileSync(`${work}/validation-${tag}.jsonl`,'utf8').trim().split('\n').map(s=>JSON.parse(s));
if(checks.length!==5||checks.some(c=>c.code!==0))throw Error('Validation incomplete or failed');
const totals=(path:string)=>[...readFileSync(path,'utf8').matchAll(/test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored/g)].reduce((a,m)=>({passed:a.passed+Number(m[1]),failed:a.failed+Number(m[2]),ignored:a.ignored+Number(m[3])}),{passed:0,failed:0,ignored:0});
const summary={checks,workspace:totals(`${work}/workspace-${tag}.log`),native:totals(`${work}/token-budget-grammar-${tag}.log`)};
writeFileSync(`${work}/validation-summary-${tag}.json`,JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(summary));
