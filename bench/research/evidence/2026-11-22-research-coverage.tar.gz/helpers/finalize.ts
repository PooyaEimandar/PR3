import {cpSync,createReadStream,existsSync,mkdirSync,mkdtempSync,readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {isDeepStrictEqual} from 'node:util';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const work='/private/tmp/pr3-research-coverage-2026-11-22',stage=join(work,'archive');
const dest=join(root,'bench/research/evidence'),prefix='2026-11-22-research-coverage';
const tag=process.argv[2];if(!tag)throw Error('Frozen build tag required');
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const run=(dir:string,file:string,args:string[]=[])=>JSON.parse(execFileSync(process.execPath,[join(dir,file),...args],{cwd:dir,encoding:'utf8'}));
const summaries:Record<string,unknown>={},controls:Record<string,unknown>={},inference:Record<string,unknown>={},inferenceControls:Record<string,unknown>={},plans:Record<string,unknown>={},planControls:Record<string,unknown>={};
let finalManifest:any;
for(const [name,folder]of [['development','research-coverage-dev-2026-11-22'],['exposed','research-coverage-exposed-2026-11-22']]){
 const matrix=join(root,'bench/research/result',folder!),target=join(stage,name!);
 const manifest=read(join(matrix,'manifest.json'));finalManifest=manifest;
 if(!read(join(matrix,'progress.json')).complete||!read(join(matrix,'source-review.json')).complete)throw Error('Evaluation/review incomplete: '+name);
 if(hash(manifest.binary)!==manifest.binarySha256)throw Error('Frozen executable changed');
 for(const[p,h]of Object.entries(manifest.productionSources))if(hash(join(root,p))!==h||hash(join(work,'source-'+tag,p))!==h)throw Error('Frozen source changed: '+p);
 if(!existsSync(join(matrix,'review-required.json')))execFileSync(process.execPath,[join(root,'bench/research/review-reliability.ts'),matrix],{cwd:root,stdio:['ignore','ignore','inherit']});
 cpSync(matrix,join(target,'matrix'),{recursive:true,errorOnExist:true,force:false});
 cpSync(join(work,'source-'+tag),join(target,'source'),{recursive:true,errorOnExist:true,force:false});
 for(const helper of ['audit-inference.ts','check-inference.ts','audit-plan.ts','check-plan.ts'])cpSync(join(work,helper),join(target,helper));
 summaries[name!]=run(target,'replay.ts');controls[name!]=run(target,'check-replay.ts');
 inference[name!]=run(target,'audit-inference.ts',[join(target,'matrix')]);inferenceControls[name!]=run(target,'check-inference.ts',[join(target,'matrix')]);
 plans[name!]=run(target,'audit-plan.ts',[join(target,'matrix')]);planControls[name!]=run(target,'check-plan.ts',[join(target,'matrix')]);
 for(const[file,value]of [['summary.json',summaries[name!]],['controls.json',controls[name!]],['inference.json',inference[name!]],['inference-controls.json',inferenceControls[name!]]])writeFileSync(join(target,file as string),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
 for(const[file,value]of [['plans.json',plans[name!]],['plan-controls.json',planControls[name!]]])writeFileSync(join(target,file as string),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
}
for(const model of finalManifest.models){const h=createHash('sha256');for await(const part of createReadStream(model.path))h.update(part);if(h.digest('hex')!==model.sha256)throw Error('Model changed: '+model.name);}
const previous=join(dest,'2026-11-21-research-contract.tar.gz');
const previousCheck=read(join(dest,'2026-11-21-research-contract-archive-check.json'));
if(hash(previous)!==previousCheck.archiveSha256)throw Error('Prior archive changed');
for(const dir of ['verification','helpers','exploratory','builds'])mkdirSync(join(stage,dir),{recursive:true});
if(existsSync(join(work,'candidate-before-validation')))cpSync(join(work,'candidate-before-validation'),join(stage,'builds','candidate-before-validation'),{recursive:true});
if(existsSync(join(work,'partial')))cpSync(join(work,'partial'),join(stage,'partial'),{recursive:true});
for(const entry of readdirSync(work,{withFileTypes:true})){
 if(entry.isDirectory()&&entry.name.startsWith('source-')&&entry.name!=='source-'+tag){cpSync(join(work,entry.name),join(stage,'builds',entry.name),{recursive:true});continue;}
 if(!entry.isFile())continue;
 if(/\.ts$/.test(entry.name))cpSync(join(work,entry.name),join(stage,'helpers',entry.name));
 else if(/\.(?:json|jsonl|log|patch|rs)$/.test(entry.name))cpSync(join(work,entry.name),join(stage,/^(?:workspace-|clippy-|host-tests-|token-budget|typescript|performance|matrices|format-)/.test(entry.name)?'verification':'exploratory',entry.name));
}
const summary={scope:'PR3-only exposed development and formerly fresh regressions. Unblinded implementation-assistant review, not independent held-out evidence or a matched OpenJarvis comparison. No failed-case retry substitution in the final matrices.',previousArchive:{name:'2026-11-21-research-contract.tar.gz',sha256:previousCheck.archiveSha256},binarySha256:finalManifest.binarySha256,development:summaries.development,exposed:summaries.exposed,inference,plans};
writeFileSync(join(stage,'summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
const archive=join(dest,prefix+'.tar.gz');if(existsSync(archive))throw Error('Archive exists');
execFileSync('tar',['-czf',archive,'-C',stage,'.'],{env:{...process.env,COPYFILE_DISABLE:'1'}});
const extracted=mkdtempSync(join(tmpdir(),'pr3-coverage-verify-'));execFileSync('tar',['-xzf',archive,'-C',extracted]);
for(const name of ['development','exposed']){
 const dir=join(extracted,name),matrix=join(dir,'matrix');
 if(!isDeepStrictEqual(summaries[name],run(dir,'replay.ts'))||!isDeepStrictEqual(controls[name],run(dir,'check-replay.ts'))||!isDeepStrictEqual(inference[name],run(dir,'audit-inference.ts',[matrix]))||!isDeepStrictEqual(inferenceControls[name],run(dir,'check-inference.ts',[matrix])))throw Error('Extracted replay mismatch: '+name);
 if(!isDeepStrictEqual(plans[name],run(dir,'audit-plan.ts',[matrix]))||!isDeepStrictEqual(planControls[name],run(dir,'check-plan.ts',[matrix])))throw Error('Extracted plan replay mismatch: '+name);
}
const verification={verifiedAt:new Date().toISOString(),archiveSha256:hash(archive),binarySha256:finalManifest.binarySha256,currentSourcesMatchFrozenManifest:true,frozenExecutableMatchesManifest:true,modelFilesMatchManifest:true,extractedReplaysMatch:true,controls,inferenceControls,planControls};
writeFileSync(join(dest,prefix+'-summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
writeFileSync(join(dest,prefix+'-archive-check.json'),JSON.stringify(verification,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({archive,archiveSha256:verification.archiveSha256},null,2));
