/** Render report tables from completed replay and review artifacts. No scoring. */
import {readFileSync} from 'node:fs';
const work='/private/tmp/pr3-research-coverage-2026-11-22';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/research/evidence';
const read=(path:string)=>JSON.parse(readFileSync(path,'utf8'));
const metrics=read(`${work}/final-metrics.json`);
const summary=read(`${root}/2026-11-22-research-coverage-summary.json`);
const prior=read(`${work}/prior-comparison.json`);
const names=['Qwen3.5-4B-Q4_K_M.gguf','Qwen3.8-27B-Q4_K_M.gguf'];
console.log('| Matrix | Model | Main | Strict | Lenient |');
console.log('|---|---|---:|---:|---:|');
for(const matrix of ['development','exposed'])for(const [i,model]of names.entries()){
 const c=metrics.counts[`${matrix}/${model}`];
 console.log(`| ${matrix} | ${i===0?'4B':'27B'} | ${c.main}/${c.turns} | ${c.strict}/${c.turns} | ${c.lenient}/${c.turns} |`);
}
for(const label of ['all','restart']){
 const c=metrics.counts[label];
 console.log(`| ${label} | both | ${c.main}/${c.turns} | ${c.strict}/${c.turns} | ${c.lenient}/${c.turns} |`);
}
console.log('\n| Matrix | Model | Seed | Main | Strict |');
console.log('|---|---|---:|---:|---:|');
for(const matrix of ['development','exposed'])for(const [i,model]of names.entries())for(const seed of [1,2,7]){
 const c=metrics.counts[`${matrix}/${model}/seed${seed}`];
 console.log(`| ${matrix} | ${i===0?'4B':'27B'} | ${seed} | ${c.main}/${c.turns} | ${c.strict}/${c.turns} |`);
}
console.log('\n| Matrix | Model | Median turn (s) | p95 (s) | Maximum (s) |');
console.log('|---|---|---:|---:|---:|');
for(const matrix of ['development','exposed'])for(const [i,model]of names.entries()){
 const g=summary[matrix].groups[`${model}/all`];
 console.log(`| ${matrix} | ${i===0?'4B':'27B'} | ${g.medianSeconds.toFixed(2)} | ${g.p95Seconds.toFixed(2)} | ${g.maxSeconds.toFixed(2)} |`);
}
console.log('\n| Previous failing configuration | Final main | Final strict |');
console.log('|---|---|---|');
for(const matrix of ['development','exposed'])for(const d of prior[matrix].previousFailures){
 console.log(`| ${matrix}; ${d.model.includes('-4B-')?'4B':'27B'} seed ${d.seed}; ${d.id}, turn ${d.turn} | ${d.currentPass?'Pass':'Fail'} | ${d.currentPass&&!d.currentBorderline?'Pass':'Fail'} |`);
}
