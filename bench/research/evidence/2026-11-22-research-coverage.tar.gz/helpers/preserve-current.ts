import {mkdirSync,renameSync,readFileSync,writeFileSync,readdirSync,existsSync,copyFileSync,constants} from 'node:fs';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const work='/private/tmp/pr3-research-coverage-2026-11-22';
const [tag,reason]=process.argv.slice(2);if(!/^coverage\d+$/.test(tag??'')||!reason)throw Error('TAG REASON required');
const target=work+'/partial/'+tag;mkdirSync(target,{recursive:false});
const counts=[];
for(const [name,folder]of [['development','research-coverage-dev-2026-11-22'],['exposed','research-coverage-exposed-2026-11-22']]){
 const matrix=root+'/bench/research/result/'+folder;if(!existsSync(matrix))continue;
 const rows=readdirSync(matrix).filter(p=>/^(4b|27b)-seed[127]\.jsonl$/.test(p)).flatMap(p=>readFileSync(matrix+'/'+p,'utf8').split('\n').slice(0,-1).map(line=>JSON.parse(line)));
 const review=JSON.parse(readFileSync(matrix+'/source-review.json','utf8'));
 const turns=rows.reduce((n,r)=>n+r.turns.length,0);
 if(review.decisions.length!==turns)throw Error('Unreviewed completed turns: '+name);
 counts.push({name,turns,main:review.decisions.filter(d=>d.pass).length,strict:review.decisions.filter(d=>d.pass&&!d.borderline).length});
 renameSync(matrix,target+'/'+name);
}
for(const file of ['matrices.log','performance.jsonl'])renameSync(work+'/'+file,target+'/'+file);
copyFileSync(work+'/run-matrices.ts',target+'/run-matrices.ts',constants.COPYFILE_EXCL);
writeFileSync(target+'/scope.json',JSON.stringify({status:'Superseded partial matrices, never combined with final results',build:tag,counts,reason},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({preserved:target,counts}));
