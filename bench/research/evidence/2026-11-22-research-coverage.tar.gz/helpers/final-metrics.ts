import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const work='/private/tmp/pr3-research-coverage-2026-11-22';
type Decision={model:string;seed:number;id:string;turn:number;pass:boolean;borderline?:boolean};
type Count={turns:number;main:number;strict:number;lenient:number};
const counts:Record<string,Count>={};
const add=(name:string,d:Decision)=>{
 const c=counts[name]??={turns:0,main:0,strict:0,lenient:0};
 c.turns++;c.main+=Number(d.pass);c.strict+=Number(d.pass&&!d.borderline);c.lenient+=Number(d.pass||d.borderline===true);
};
for(const [name,folder]of [['development','research-coverage-dev-2026-11-22'],['exposed','research-coverage-exposed-2026-11-22']]){
 const review=JSON.parse(readFileSync(`${root}/bench/research/result/${folder}/source-review.json`,'utf8')) as {complete:boolean;decisions:Decision[]};
 if(!review.complete)throw Error('Incomplete review: '+name);
 for(const d of review.decisions){
  for(const group of ['all',name!,`${name}/${d.model}`,`${name}/${d.model}/seed${d.seed}`,`all/${d.model}`])add(group,d);
  if(d.turn>0)for(const group of ['restart',`restart/${d.model}`])add(group,d);
 }
}
if(counts.all?.turns!==240||counts.restart?.turns!==84)throw Error('Unexpected denominator');
const power=JSON.parse(execFileSync(process.execPath,[`${work}/power-summary.ts`,`${work}/performance.jsonl`],{encoding:'utf8'}));
const result={scope:'Unblinded implementation-assistant review of exposed regressions; descriptive counts and observational desktop samples, not independent or controlled comparative evidence.',counts,power};
writeFileSync(`${work}/final-metrics.json`,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result,null,2));
