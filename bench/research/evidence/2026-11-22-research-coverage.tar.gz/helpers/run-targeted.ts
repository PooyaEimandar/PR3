import {spawn} from 'node:child_process';
import {openSync,existsSync} from 'node:fs';
const work='/private/tmp/pr3-research-coverage-2026-11-22';
const [tag,label,seed]=process.argv.slice(2);
if(!tag||!['4b','27b'].includes(label!)||!['1','2','7'].includes(seed!))throw Error('TAG MODEL SEED required');
const model=label==='4b'?'Qwen3.5-4B-Q4_K_M.gguf':'Qwen3.8-27B-Q4_K_M.gguf';
const prefix=`${work}/${tag}${process.argv[5]?'-'+process.argv[5]:''}-${label}-seed${seed}`;
if(existsSync(prefix+'.jsonl'))throw Error('Refusing to overwrite');
const log=openSync(prefix+'.log','wx');
console.log(JSON.stringify({label,seed,start:new Date().toISOString()}));
await new Promise<void>((resolve,reject)=>{
 const child=spawn(`${work}/research-${tag}`,[`model/${model}`,seed!,`${work}/targeted.json`,prefix+'.jsonl'],{stdio:['ignore',log,log]});
 child.once('error',reject);child.once('exit',code=>code===0?resolve():reject(Error('Diagnostic exited '+code)));
});
console.log(JSON.stringify({label,seed,end:new Date().toISOString()}));
