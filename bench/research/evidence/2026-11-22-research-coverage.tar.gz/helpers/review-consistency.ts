/** Check consistency of manually entered judgments for identical displayed
 * answers to the same request. This never creates or changes a decision. */
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/research/result';
const groups=new Map<string,any[]>();let turns=0;
for(const matrix of ['research-coverage-dev-2026-11-22','research-coverage-exposed-2026-11-22']) {
 const dir=join(root,matrix),review=JSON.parse(readFileSync(join(dir,'source-review.json'),'utf8'));
 if(!review.complete)throw Error('Review incomplete');
 for(const label of ['4b','27b'])for(const seed of [1,2,7]) {
  const rows=readFileSync(join(dir,`${label}-seed${seed}.jsonl`),'utf8').trim().split('\n').map(s=>JSON.parse(s));
  for(const row of rows)for(const [turn,t]of row.turns.entries()) {
   const d=review.decisions.find((d:any)=>d.model.includes(label==='4b'?'-4B-':'-27B-')&&d.seed===seed&&d.id===row.id&&d.turn===turn);
   if(!d)throw Error('Missing decision');turns++;
   const display=t.answer.replace(/ \[(?:research|document):[^\]\n]+\]/gu,'');
   const hash=createHash('sha256').update(JSON.stringify({display,error:t.error})).digest('hex');
   const key=`${matrix}/${row.id}/${turn}/${hash}`;
   const list=groups.get(key)??[];list.push({label,seed,pass:d.pass,borderline:d.borderline??false});groups.set(key,list);
  }
 }
}
if(turns!==240)throw Error('Unexpected denominator');
for(const [key,list]of groups)if(list.some(d=>d.pass!==list[0].pass||d.borderline!==list[0].borderline))throw Error('Inconsistent judgments: '+key+' '+JSON.stringify(list));
const result={turns,normalization:'Only internal research/document citation annotations removed; all answer wording, quotations and source metadata retained. Same matrix/case/turn and error required.',distinctDisplays:groups.size,repeatedGroups:[...groups].filter(([,list])=>list.length>1).map(([key,decisions])=>({key,decisions})),consistent:true};
writeFileSync('/private/tmp/pr3-research-coverage-2026-11-22/review-consistency.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({turns,distinctDisplays:groups.size,repeatedGroups:result.repeatedGroups.length,consistent:true}));
