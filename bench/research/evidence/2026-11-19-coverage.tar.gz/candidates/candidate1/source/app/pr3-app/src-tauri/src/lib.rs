//! PR3 reference app. The Rust side owns the runtime; the webview only renders.

#![cfg_attr(test, allow(clippy::disallowed_macros))] // tests may assert (clippy.toml)

#[cfg(feature = "legacy-email-bench")]
#[path = "../../../../bench/legacy-email/actions.rs"]
mod actions;
#[cfg(not(feature = "legacy-email-bench"))]
mod actions;
#[cfg(all(feature = "legacy-email-bench", not(debug_assertions)))]
compile_error!("Historical email fixtures must never be compiled into release builds");
#[cfg(target_os = "android")]
mod android_speech;
#[cfg(target_os = "android")]
mod android_vault;
mod backup;
mod config;
#[cfg(feature = "legacy-email-bench")]
#[path = "../../../../bench/legacy-email/contacts.rs"]
mod contacts;
mod continuity;
#[cfg(feature = "legacy-email-bench")]
#[path = "../../../../bench/legacy-email/device_mail.rs"]
mod device_mail;
mod documents;
#[cfg(feature = "e2e")]
mod e2e;
mod research;
#[cfg(all(feature = "e2e", not(debug_assertions)))]
compile_error!("The e2e driver and fixtures must never be compiled into a release build");
mod host;
mod hybrid;
mod llama;
mod memory;
mod models;
mod network;
mod share;
mod speech;
mod storage;
mod task;
mod trace_export;
mod web;

use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use actions::Actions;
use host::{Backend, Host, MockBackend, TurnEvent};
use serde::Serialize;
use tauri::ipc::Channel;
use tauri::{Emitter, Manager};

/// Event the UI listens to when the active model changes (e.g. loading finished).
const MODEL_CHANGED: &str = "model-changed";

#[derive(Serialize)]
struct PlatformInfo {
    os: &'static str,
    arch: &'static str,
    /// A CI build's version (script/version.py), such as
    /// 2026.10.27.30184-dev+fd9a2875dc06; none for a local build.
    version: Option<&'static str>,
    model: String,
}

#[tauri::command]
fn platform_info(host: tauri::State<'_, Host>) -> PlatformInfo {
    PlatformInfo {
        os: std::env::consts::OS,
        arch: std::env::consts::ARCH,
        version: option_env!("PR3_VERSION"),
        model: host.backend_label(),
    }
}

/// Runs one user turn through the core. Async, so Tauri runs it off the main thread;
/// tokens and tool activity stream through `on_event` while the turn runs. The UI
/// passes the device's UTC offset so tools can tell local time without a tz database.
/// Once it has answered, the task gets ready for the next message in the background.
#[tauri::command]
async fn send_message(
    text: String,
    research_controls: Option<host::chat::ChatControls>,
    utc_offset_minutes: i32,
    on_event: Channel<TurnEvent>,
    app: tauri::AppHandle,
    host: tauri::State<'_, Host>,
) -> Result<Vec<pr3_core::Action>, String> {
    storage::require_ready(&app)?;
    let emit = move |event| {
        #[cfg(feature = "e2e")]
        e2e::hold_turn_event(&event);
        // A closed channel only means the window went away; the turn still completes.
        let _ = on_event.send(event);
    };
    let result = match research_controls {
        Some(controls) => {
            host.send_chat(text, controls, utc_offset_minutes, emit)
                .await
        }
        None => host.send(text, utc_offset_minutes, emit).await,
    }
    .map_err(|e| e.to_string());
    settle_later(app);
    result
}

/// Gets the task the next message goes to ready for it in the background
/// ([`Host::settle`]). Without it, that message's turn does the same first; nothing is lost.
pub(crate) fn settle_later(app: tauri::AppHandle) {
    tauri::async_runtime::spawn(async move {
        let _ = app.state::<Host>().settle(|_| {}).await;
    });
}

/// On a computer: the node lending its model, if it runs, and where it listens.
struct NodeHandle(Option<Arc<pr3_hybrid::Node>>, String);

/// What the devices panel shows: on a computer, its node and paired phones; on a phone,
/// the computer it is paired with.
#[tauri::command]
fn devices_info(app: tauri::AppHandle) -> hybrid::DevicesInfo {
    if let Some(link) = app.try_state::<hybrid::Link>() {
        return hybrid::DevicesInfo::Phone {
            node: link.node().as_ref().map(Into::into),
        };
    }
    match app.try_state::<NodeHandle>() {
        Some(handle) => match &handle.0 {
            Some(node) => hybrid::DevicesInfo::Node {
                name: node.name().to_string(),
                listen: handle.1.clone(),
                phones: node.phones().iter().map(Into::into).collect(),
            },
            None => hybrid::DevicesInfo::Off,
        },
        None => hybrid::DevicesInfo::Off,
    }
}

#[derive(Serialize)]
struct PairingInfo {
    code: String,
    expires_in_s: u64,
    listen: String,
}

/// On a computer: a fresh pairing code to type on the phone.
#[tauri::command]
fn start_pairing(app: tauri::AppHandle) -> Result<PairingInfo, String> {
    let handle = app
        .try_state::<NodeHandle>()
        .ok_or("this device is not a node")?;
    let node = handle
        .0
        .as_ref()
        .ok_or("the node is off (see [node] in pr3.toml)")?;
    let code = node.start_pairing().map_err(|e| e.to_string())?;
    Ok(PairingInfo {
        code: code.code,
        expires_in_s: code.expires_in.as_secs(),
        listen: handle.1.clone(),
    })
}

/// On a computer: stops lending to a phone.
#[tauri::command]
fn forget_phone(app: tauri::AppHandle, id: String) -> Result<(), String> {
    let handle = app
        .try_state::<NodeHandle>()
        .ok_or("this device is not a node")?;
    let node = handle.0.as_ref().ok_or("the node is off")?;
    continuity::pairing_change(&app, || {
        node.forget(&id).map(|_| ()).map_err(|e| e.to_string())
    })
}

/// On a phone: pairs with the computer at `address` using the code it shows.
#[tauri::command]
async fn pair_with_node(
    app: tauri::AppHandle,
    address: String,
    code: String,
) -> Result<hybrid::PeerInfo, String> {
    let link = app
        .try_state::<hybrid::Link>()
        .ok_or("only a phone pairs with a computer")?
        .inner()
        .clone();
    let dir = app.path().app_data_dir().map_err(|e| e.to_string())?;
    let pairing_app = app.clone();
    let node = tauri::async_runtime::spawn_blocking(move || {
        continuity::pairing_change(&pairing_app, || link.pair(&dir, &address, &code))
    })
    .await
    .map_err(|e| e.to_string())??;
    let _ = app.emit(MODEL_CHANGED, ());
    Ok((&node).into())
}

/// On a phone: stops using the paired computer.
#[tauri::command]
fn unpair(app: tauri::AppHandle) -> Result<(), String> {
    let link = app
        .try_state::<hybrid::Link>()
        .ok_or("this device is not paired")?;
    let dir = app.path().app_data_dir().map_err(|e| e.to_string())?;
    continuity::pairing_change(&app, || link.unpair(&dir))?;
    let _ = app.emit(MODEL_CHANGED, ());
    Ok(())
}

/// A phone remembers the computer it paired with; a computer lends its model.
fn start_hybrid(app: &tauri::AppHandle, settings: &config::Node) {
    if storage::require_ready(app).is_err() {
        return;
    }
    let Ok(dir) = app.path().app_data_dir() else {
        return;
    };
    if cfg!(mobile) {
        app.manage(hybrid::Link::open(&dir));
    } else {
        let node = hybrid::start_node(app, &dir, settings);
        app.manage(NodeHandle(node, settings.listen.clone()));
    }
    continuity::refresh_pairing(app);
}

/// The user's answer on the confirmation card for a consequential action.
#[tauri::command]
fn answer_approval(
    request: String,
    approve: bool,
    host: tauri::State<'_, Host>,
) -> Result<(), String> {
    host.answer_approval(&request, approve)
}

/// Frees the model before the process exits: llama.cpp's Metal backend aborts if its
/// device is torn down while model buffers are alive. Stops any answer in progress, waits
/// for models still loading (which are then dropped, not installed) and for in-flight
/// work to let go of the model, then drops it. Bounded, so quitting never hangs.
fn shut_down(app: &tauri::AppHandle, host: &Host) {
    let deadline = Instant::now() + Duration::from_secs(10);
    let model = host.shut_down();
    let loaders = app
        .try_state::<models::Models>()
        .map(|m| m.take_loaders())
        .unwrap_or_default();
    for loader in loaders {
        while !loader.is_finished() && Instant::now() < deadline {
            std::thread::sleep(Duration::from_millis(20));
        }
        if loader.is_finished() {
            let _ = loader.join();
        }
    }
    while Arc::strong_count(&model) > 1 && Instant::now() < deadline {
        std::thread::sleep(Duration::from_millis(10));
    }
    drop(model);
}

fn set_backend(app: &tauri::AppHandle, backend: Arc<dyn Backend>) {
    // A paired phone asks its computer first and falls back to this model.
    let backend: Arc<dyn Backend> = match app.try_state::<hybrid::Link>() {
        Some(link) => Arc::new(hybrid::Delegating::new(link.inner().clone(), backend)),
        None => backend,
    };
    let label = backend.label();
    app.state::<Host>().set_backend(backend);
    // The window may not be listening yet at startup; it also asks on load.
    let _ = app.emit(MODEL_CHANGED, label);
}

/// The app's host, on the memory store and trusted path in its data folder.
fn host(
    app: &tauri::AppHandle,
    tasks: config::Tasks,
    web: Option<Box<dyn pr3_tool::web::Fetch>>,
) -> Result<Host, host::HostError> {
    let store = storage::open(app);
    if let Some(store) = &store {
        let memory: pr3_tool::SharedMemory = store.clone();
        // The panel where the user reviews what PR3 remembers uses the same store.
        app.manage(memory::MemoryHandle(memory));
        app.manage(documents::Library(store.clone()));
        match app
            .path()
            .app_data_dir()
            .map_err(|e| e.to_string())
            .and_then(|dir| {
                pr3_hybrid::DeviceKey::open(&dir.join("device.key")).map_err(|e| e.to_string())
            }) {
            Ok(key) => {
                let ready = store
                    .lock()
                    .map_err(|_| "Memory unavailable".to_string())
                    .and_then(|mut db| {
                        db.continuity_init(&key.public_hex())
                            .map_err(|e| e.to_string())
                    });
                if ready.is_ok() {
                    app.manage(continuity::State::new(store.clone()));
                } else if let Err(e) = ready {
                    eprintln!("PR3 continuity unavailable: {e}");
                }
            }
            Err(e) => eprintln!("PR3 continuity unavailable: {e}"),
        }
    }
    compose_host(
        Arc::new(MockBackend::default()),
        store,
        None,
        tasks.keep_days,
        web,
    )
}

/// The host with the built-in tools, plus memory tools, per-message recall and kept
/// tasks when there is a memory store, reading the pages the user links when there is a
/// fetcher, and consequential actions when there is a trusted path. The task benchmark
/// builds the same host, so it measures this one.
pub fn compose_host(
    backend: Arc<dyn Backend>,
    store: Option<Arc<Mutex<pr3_memory_sqlite::SqliteMemory>>>,
    actions: Option<Arc<Actions>>,
    keep_days: u64,
    web: Option<Box<dyn pr3_tool::web::Fetch>>,
) -> Result<Host, host::HostError> {
    let mut tools = pr3_tool::builtin();
    let web: Option<Arc<dyn pr3_tool::web::Fetch>> = web.map(Arc::from);
    if let Some(fetch) = &web {
        tools.push(Box::new(pr3_tool::web::ReadWebPage::shared(fetch.clone())));
    }
    let host = match store {
        Some(store) => {
            let memory: pr3_tool::SharedMemory = store.clone();
            tools.extend(pr3_tool::memory_tools(Arc::clone(&memory)));
            tools.extend(pr3_tool::documents::tools(store.clone()));
            tools.extend(pr3_tool::research::tools(
                store.clone(),
                web.clone(),
                web.as_ref().map(|fetch| {
                    Arc::new(crate::web::Search::new(store.clone(), fetch.clone()))
                        as Arc<dyn pr3_tool::research::SearchWeb>
                }),
            ));
            Host::new(backend, tools)?
                .with_memory(memory)
                .with_tasks(store, keep_days)?
        }
        None => Host::new(backend, tools)?,
    };
    match actions {
        Some(actions) => host.with_actions(actions),
        None => Ok(host),
    }
}

/// What the task benchmark (bench/task) drives besides [`compose_host`]. Benchmark
/// only: the app itself reaches these through their own modules.
#[doc(hidden)]
pub mod bench {
    pub use crate::actions::Actions;
    pub use crate::host::{Backend, Generation, Host, HostError, SUMMARY, TurnEvent};
    pub use crate::llama::LlamaBackend;
    /// The runtime the host's async calls run on.
    pub use tauri::async_runtime::block_on;

    /// The same bounded, read-only correction review used by the app. A benchmark
    /// gets candidates and the incomplete flag, never a write or confirmation.
    pub async fn review_memory(
        backend: std::sync::Arc<dyn Backend>,
        memory: pr3_tool::SharedMemory,
        text: String,
    ) -> Result<(Vec<i64>, bool, Option<String>), String> {
        let review = crate::memory::semantic::inspect(
            backend,
            memory,
            text,
            "user".into(),
            None,
            std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false)),
        )
        .await?;
        let mut ids: Vec<i64> = review.candidates.into_iter().map(|c| c.id).collect();
        ids.sort_unstable();
        Ok((ids, review.incomplete, review.notice))
    }
}

/// Finished turns are appended as OpenJarvis trace records to `traces.jsonl` in the app's
/// data folder, where OpenJarvis's analysis and learning tools can read them.
fn start_tracing(app: &tauri::AppHandle, settings: config::Traces) {
    let Ok(dir) = app.path().app_data_dir() else {
        return;
    };
    if !settings.enabled {
        return;
    }
    let path = dir.join("traces.jsonl");
    let max_bytes = settings.max_mb.saturating_mul(1024 * 1024);
    eprintln!("PR3: tracing to {}", path.display());
    app.state::<Host>().set_trace_sink(Arc::new(move |trace| {
        if let Err(e) = trace_export::append(&path, trace, max_bytes) {
            eprintln!("PR3: could not write trace to {}: {e}", path.display());
        }
    }));
}

/// Creates the app's data folder and keeps it out of backups (see [`backup`]).
fn prepare_data_dir(app: &tauri::AppHandle) {
    let Ok(dir) = app.path().app_data_dir() else {
        return;
    };
    let ready = std::fs::create_dir_all(&dir)
        .map_err(|e| e.to_string())
        .and_then(|()| backup::exclude(&dir));
    if let Err(e) = ready {
        eprintln!("PR3: data folder {}: {e}", dir.display());
    }
    // Retire the old opt-in flag; no address book is read by this build.
    match std::fs::remove_file(dir.join("contacts-sync")) {
        Err(e) if e.kind() != std::io::ErrorKind::NotFound => {
            eprintln!("PR3: could not remove retired contact-sync flag: {e}")
        }
        _ => {}
    }
    // Earlier builds kept models in `models/`; the folder is `model/` now.
    let (old, new) = (dir.join("models"), dir.join("model"));
    if old.is_dir()
        && !new.exists()
        && let Err(e) = std::fs::rename(&old, &new)
    {
        eprintln!(
            "PR3: could not move {} to {}: {e}",
            old.display(),
            new.display()
        );
    }
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let builder = tauri::Builder::default();
    #[cfg(feature = "e2e")]
    let builder = builder.plugin(tauri_plugin_wdio_webdriver::init());
    #[cfg(target_os = "android")]
    let builder = builder
        .plugin(android_vault::plugin())
        .plugin(android_speech::plugin())
        .plugin(network::plugin())
        .plugin(share::plugin());
    let context = tauri::generate_context!();
    #[cfg(feature = "e2e")]
    let context = {
        let mut context = context;
        context.config_mut().identifier = "ai.pooya.pr3.e2e".into();
        context
    };
    let app = builder
        .setup(|app| {
            #[cfg(feature = "e2e")]
            if app.config().identifier == "ai.pooya.pr3.e2e" {
                return e2e::setup(app);
            }
            prepare_data_dir(app.handle());
            // An export waits in the cache for the share sheet; it holds a chat in plain text.
            if let Ok(dir) = task::export::dir(app.handle()) {
                task::export::clear(&dir);
            }
            let data_dir = app.path().app_data_dir().ok();
            let config = config::Config::load(data_dir.as_deref());
            let tasks = config.as_ref().map(|c| c.tasks).unwrap_or_default();
            let reading = config.as_ref().map(|c| c.web).unwrap_or_default();
            let (web, fetcher) = web::open(data_dir.as_deref(), reading.enabled);
            app.manage(web);
            app.manage(host(app.handle(), tasks, fetcher)?);
            let node = config.as_ref().map(|c| c.node.clone()).unwrap_or_default();
            start_hybrid(app.handle(), &node);
            start_tracing(
                app.handle(),
                config.as_ref().map(|c| c.traces).unwrap_or_default(),
            );
            app.manage(models::Models::new(data_dir.as_deref(), config));
            app.state::<models::Models>().start(app.handle());
            app.manage(speech::Speech::open(app.handle()));
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            storage::storage_info,
            storage::storage_recovery_code,
            storage::recover_storage,
            continuity::continuity_info,
            continuity::sync_continuity,
            continuity::share_item,
            continuity::recover_item,
            documents::list_documents,
            documents::import_document,
            documents::search_documents,
            documents::document_source,
            documents::remove_document,
            research::research_source,
            research::chat_scope,
            research::research_settings,
            research::set_research_provider,
            research::set_research_key,
            platform_info,
            send_message,
            answer_approval,
            devices_info,
            start_pairing,
            forget_phone,
            pair_with_node,
            unpair,
            speech::speech_status,
            speech::speech_languages,
            speech::set_speech_language,
            speech::start_listening,
            speech::stop_listening,
            speech::cancel_listening,
            speech::speak,
            speech::stop_speaking,
            memory::list_memories,
            memory::add_memory,
            memory::confirm_memory,
            memory::keep_memory_separately,
            memory::correct_memory,
            memory::forget_memory,
            models::list_models,
            models::download_model,
            models::cancel_download,
            models::set_mobile_data,
            web::web_reading,
            web::set_web_reading,
            models::use_model,
            models::delete_model,
            task::list_tasks,
            task::open_task,
            task::current_task,
            task::ask_again,
            task::start_new_task,
            task::new_topic,
            task::continue_task,
            task::finish_task,
            task::stop_task,
            task::retry_task_save,
            task::retry_task,
            task::follow_up_task,
            task::task_words,
            task::export_task,
            task::delete_task
        ])
        .build(context);
    match app {
        Ok(app) => app.run(|handle, event| {
            if let tauri::RunEvent::Exit = event
                && let Some(host) = handle.try_state::<Host>()
            {
                shut_down(handle, &host);
            }
        }),
        Err(e) => {
            eprintln!("PR3 failed to start: {e}");
            std::process::exit(1);
        }
    }
}
