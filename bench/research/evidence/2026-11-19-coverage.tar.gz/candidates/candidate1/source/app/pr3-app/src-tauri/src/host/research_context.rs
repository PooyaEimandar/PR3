//! An inference-only projection, never a change to task history, provenance, loop
//! counters or stored sources. Rebuilt from this task's database on every inference.
use super::*;
use pr3_memory_sqlite::research::source_reference;
use pr3_tool::research::{ANSWER, READ, SEARCH};
use serde_json::json;

pub(crate) const SAVED_EVIDENCE: &str = "pr3:saved-research-evidence";

impl Host {
    pub(super) fn research_context(
        &self,
        request: &mut InferenceRequest,
        query: &str,
    ) -> Result<(), HostError> {
        let Some(last_user) = request.messages.iter().rposition(|m| m.role == Role::User) else {
            return Ok(());
        };
        // Earlier reports/tool transcripts are not evidence for a new answer. Keep
        // the latest user message (including task corrections) and this turn's status.
        request.messages.drain(..last_user);
        // This exact System message is emitted from the core's actual counter.
        // User/source text cannot reserve a round by imitating its wording.
        let limit = Config::default().max_tool_rounds;
        let final_round =
            pr3_core::tool_round_budget(limit.saturating_sub(1), limit).is_some_and(|budget| {
                request
                    .messages
                    .iter()
                    .any(|m| m.role == Role::System && m.content == budget)
            });
        if final_round {
            request.tools.retain(|tool| tool.name == ANSWER);
            request.messages.push(Message::new(Role::System,
                "The final research round is reserved for answer_research. Use the saved evidence now. Put any unanswered part in gaps; no search or source read is available in this round.".into(), now()));
        }
        // Keep remembered user wording separate from the actual current request.
        // The protected report continuation repeats only the current question,
        // rather than doubling all remembered details and research scope notes.
        if let Some(user) = request.messages.first_mut()
            && let Some(context) = user
                .content
                .strip_suffix(query)
                .filter(|s| !s.trim().is_empty())
        {
            let context = Message::new(Role::User, context.trim_end().into(), user.at);
            user.content = query.into();
            request.messages.insert(0, context);
        }
        let Some(store) = &self.research_store else {
            return Ok(());
        };
        let earlier = self
            .tasks
            .lock()
            .map(|tasks| tasks.said(request.session))
            .unwrap_or_default();
        let db = store
            .lock()
            .map_err(|_| HostError::Host("Research storage is unavailable".into()))?;
        let scope = db
            .research(request.session.0)
            .map_err(|e| HostError::Host(e.to_string()))?
            .map(|r| {
                pr3_tool::research_scope::SourceScope::from_user(
                    &r.topic,
                    earlier
                        .iter()
                        .map(String::as_str)
                        .chain(std::iter::once(query)),
                )
            })
            .unwrap_or_default();
        let sources = db
            .research_sources(request.session.0)
            .map_err(|e| HostError::Host(e.to_string()))?;
        // research_source also checks that a local passage still exists.
        let sources = sources
            .into_iter()
            .filter(|s| scope.allows_evidence(s))
            .filter_map(|s| match db.research_source(request.session.0, &s.source) {
                Ok(Some(s)) => Some(Ok(s)),
                Ok(None) => None,
                Err(e) => Some(Err(HostError::Host(e.to_string()))),
            })
            .collect::<Result<Vec<_>, _>>()?;
        let candidates = db
            .research_candidates(request.session.0)
            .map_err(|e| HostError::Host(e.to_string()))?
            .into_iter()
            .filter(|c| scope.allows_url(&c.url))
            .collect::<Vec<_>>();
        let run = db
            .research(request.session.0)
            .map_err(|e| HostError::Host(e.to_string()))?;
        let web = run.as_ref().is_some_and(|run| run.web);
        let fresh = run.as_ref().is_some_and(|run| run.searches == 0);
        drop(db);
        // A comparison of explicit links must not spend its remaining rounds
        // rereading one source while another requested page is still unopened.
        // Derive this only from the CURRENT user message, never a source or an
        // earlier topic on an offline/corrected continuation.
        let missing = requested_candidates(query, &candidates, &sources, request);
        if !missing.is_empty() {
            if !final_round && web {
                request.tools.retain(|tool| tool.name == READ);
                if let Some(tool) = request.tools.first_mut() {
                    let mut parameters: Value = serde_json::from_str(&tool.parameters)
                        .map_err(|e| HostError::Host(e.to_string()))?;
                    parameters["properties"]["source"]["enum"] = json!(missing);
                    tool.parameters = parameters.to_string();
                }
                request.messages.push(Message::new(Role::System,
                    "Some links in this request have not been read or attempted. Read the offered candidate references, preferably together, before reporting. Do not reread saved passages. Every call still uses the existing execution budget.".into(),now()));
            } else {
                request.messages.push(Message::new(Role::System,
                    "Some explicitly requested pages have not been read. Do not imply complete coverage. If new reads are unavailable, report only supported findings and identify the unexamined part in gaps.".into(),now()));
            }
        }
        if asks_current(query) {
            request.messages.push(Message::new(Role::System,
                "This request asks what can be established CURRENTLY. The direct answer must explicitly state whether the sources establish a current fact. If they are expired or undated, say that the current fact cannot be established, in findings or gaps. Listing historical/undated values without that conclusion does not answer this request. An unspecified validity period does not mean an offer remains valid.".into(),now()));
        }
        if query
            .split(|c: char| !c.is_alphanumeric())
            .any(|w| w.eq_ignore_ascii_case("compare") || w.eq_ignore_ascii_case("comparison"))
        {
            request.messages.push(Message::new(Role::System,
                "Comparison checklist: give a separate, cited finding for EACH subject's requested behavior or property, followed by any additional requested restriction. Explicitly state what each side does under the requested conditions. Saying that the subjects differ is not enough. Each quotation must support its finding, not merely mention the subject. Put a missing side in gaps rather than substituting background details.".into(),now()));
        }
        if let Some(problem) = scope.problem() {
            request.tools.retain(|tool| tool.name == ANSWER);
            request.messages.push(Message::new(Role::System, format!("Website scope needs user clarification: {problem} No source may be used until this is resolved. Call answer_research now with findings: [] and explain the required clarification in gaps. No search is needed."), now()));
            return Ok(());
        }
        let calls = request
            .messages
            .iter()
            .flat_map(|m| &m.tool_calls)
            .map(|c| (c.id.clone(), (c.name.clone(), c.arguments.clone())))
            .collect::<BTreeMap<_, _>>();
        let mut selected = BTreeMap::new();
        let mut rejected_reports = std::collections::BTreeSet::new();
        let mut completed_retrieval = std::collections::BTreeSet::new();
        for message in &mut request.messages {
            if message.role != Role::Tool {
                continue;
            }
            let Some((name, arguments)) =
                message.tool_call_id.as_ref().and_then(|id| calls.get(id))
            else {
                continue;
            };
            if name == ANSWER && message.content.starts_with("error:") {
                if let Some(id) = &message.tool_call_id {
                    rejected_reports.insert(id.clone());
                }
                message.content =
                    json!({"tool":ANSWER,"status":"failed","error":message.content}).to_string();
                continue;
            }
            let Ok(value) = serde_json::from_str::<Value>(&message.content) else {
                continue;
            }; // retain real failures
            if final_round
                && matches!(name.as_str(), READ | SEARCH)
                && let Some(id) = &message.tool_call_id
            {
                completed_retrieval.insert(id.clone());
            }
            if name == READ {
                if let Some(id) = value["source"].as_str().and_then(|id| {
                    sources.iter().find(|s| {
                        s.source == id || source_reference(request.session.0, &s.source) == id
                    })
                }) {
                    if let Some(call) = &message.tool_call_id {
                        completed_retrieval.insert(call.clone());
                    }
                    message.content = json!({"saved_source":source_reference(request.session.0,&id.source),"status":"Read succeeded; evidence is in the saved-source view."}).to_string();
                    // Fetching a candidate saves all its parts. Do not pin the
                    // default first part (often navigation) above relevant later
                    // passages. Exact-source reads and explicit later parts/byte
                    // ranges still express a request for that particular evidence.
                    let args: Value = serde_json::from_str(arguments).unwrap_or(Value::Null);
                    if pin_read(&args) {
                        selected.insert(id.source.clone(), value);
                    }
                }
            } else if name == SEARCH {
                // The snapshot view already carries stored passages. Preserve
                // discovery outcomes and candidate IDs, without repeating the
                // whole topic, inventory and instructions in every inference.
                message.content = json!({
                    "web_candidates":value["web_candidates"],
                    "search_state":value["scope"]["search_state"],
                    "search_error":value["scope"]["search_error"],
                    "saved_source_count":sources.len(),
                })
                .to_string();
            }
        }
        // A rejected report can be larger than its sources. Keep its real error,
        // but do not replay unvalidated prose/quotations into the repair attempt.
        // Completed reads are represented by the snapshot view; final-round
        // discovery is obsolete too. Keep saved evidence and real failures;
        // only this inference copy changes.
        // The core still holds the exact calls, trace and unchanged loop counters.
        for message in &mut request.messages {
            if message.role == Role::Assistant
                && message.tool_calls.iter().any(|c| {
                    rejected_reports.contains(&c.id) || completed_retrieval.contains(&c.id)
                })
            {
                message.tool_calls.retain(|c| {
                    !rejected_reports.contains(&c.id) && !completed_retrieval.contains(&c.id)
                });
                if message.tool_calls.is_empty() {
                    message.content.clear();
                }
            }
        }
        request.messages.retain(|m| {
            (m.role != Role::Assistant || !m.content.is_empty() || !m.tool_calls.is_empty())
                && !m
                    .tool_call_id
                    .as_ref()
                    .is_some_and(|id| completed_retrieval.contains(id))
        });
        if sources.is_empty() {
            if fresh && missing.is_empty() && !final_round {
                request.tools.retain(|tool| tool.name == SEARCH);
            }
            request.messages.push(Message::new(Role::System,
                if final_round {
                    "No saved evidence is available. Call answer_research with no findings and explain the missing evidence in gaps. Never invent a source or quotation."
                } else if !missing.is_empty() && web {
                    "Read the offered requested candidates now. No saved evidence is available yet. A failed attempt can be reported as a gap; do not invent source content."
                } else {
                    "No saved evidence is available for this task. Call research_sources with nonempty, distinctive LOCAL keywords from the user's request; an empty inventory query cannot discover documents. Then read relevant candidates before reporting. Never invent sources or quotations. The existing execution budget still applies."
                }.into(), now()));
            return Ok(());
        }
        let source_count = sources.len();
        let packet = json!({"source_count":source_count,"sources":sources.into_iter().map(|s| {
            let origin = s.document.map(|id| format!("document:{id}")).unwrap_or_else(|| s.location.split(" · part ").next().unwrap_or(&s.source).to_string());
            let origin = pr3_core::trusted::Hash::of(&[origin.as_bytes()]).to_hex()[..16].to_string();
            let split_quotes = !pr3_tool::research::whole_quote_suitable(&s.text, "", &earlier, query);
            let mut source = json!({"source":source_reference(request.session.0,&s.source),"origin":origin,"title":s.title,"location":s.location,"text":s.text,"captured_at":s.captured_at,"selected":selected.contains_key(&s.source),"split_quotes":split_quotes});
            if let Some(read) = selected.get(&s.source).filter(|r| r["offset"].is_u64()) {
                for key in ["text", "offset", "text_bytes", "excerpted"] { source[key] = read[key].clone(); }
            }
            source
        }).collect::<Vec<_>>()}).to_string();
        // Use the same 8 KiB ceiling as tool outputs. Token-aware shrinking happens
        // in the engine, reserving its unchanged answer budget.
        let fallback = request
            .messages
            .first()
            .filter(|m| m.role == Role::User && m.content != query)
            .map(|m| m.content.as_str())
            .unwrap_or_default();
        for count in (1..=4).rev() {
            if let Some(content) =
                pr3_llamacpp::saved_evidence_view(&packet, query, fallback, 1200, count)
                && content.len() <= Config::default().max_tool_output_bytes
            {
                let mut message = Message::new(Role::Tool, content, now());
                message.tool_call_id = Some(SAVED_EVIDENCE.into());
                request.messages.push(message);
                break;
            }
        }
        Ok(())
    }
}

fn asks_current(query: &str) -> bool {
    query.split(|c: char| !c.is_alphanumeric()).any(|w| {
        w.eq_ignore_ascii_case("current")
            || w.eq_ignore_ascii_case("currently")
            || w.eq_ignore_ascii_case("latest")
    })
}

fn requested_candidates(
    query: &str,
    candidates: &[pr3_memory_sqlite::research::Candidate],
    sources: &[pr3_memory_sqlite::research::Evidence],
    request: &InferenceRequest,
) -> Vec<String> {
    let links = pr3_tool::web::links(
        &query
            .split_whitespace()
            .filter(|w| w.contains("://"))
            .collect::<Vec<_>>()
            .join(" "),
    );
    candidates
        .iter()
        .filter(|c| {
            links
                .iter()
                .filter_map(|url| pr3_tool::web::normalize(url))
                .any(|url| url == c.url)
        })
        .filter(|c| {
            let prefix = c.id.replacen("candidate:", "research:", 1) + ":";
            !sources.iter().any(|s| s.source.starts_with(&prefix))
        })
        .filter_map(|c| {
            let reference =
                pr3_memory_sqlite::research::candidate_reference(request.session.0, &c.id);
            let attempted = request
                .messages
                .iter()
                .filter(|m| m.role == Role::Assistant)
                .flat_map(|m| &m.tool_calls)
                .filter(|call| call.name == READ)
                .any(|call| {
                    let args: Value = serde_json::from_str(&call.arguments).unwrap_or(Value::Null);
                    (args["source"] == reference || args["source"] == c.id)
                        && request.messages.iter().any(|m| {
                            m.role == Role::Tool && m.tool_call_id.as_deref() == Some(&call.id)
                        })
                });
            (!attempted).then_some(reference)
        })
        .take(3)
        .collect()
}

fn pin_read(args: &Value) -> bool {
    args["offset"].is_u64()
        || args["part"].as_u64().is_some_and(|p| p > 1)
        || args["source"].as_str().is_some_and(|s| {
            s.starts_with("s:") || s.starts_with("research:") || s.starts_with("document:")
        })
}

#[cfg(test)]
mod tests {
    use super::*;
    struct Unused;
    impl Backend for Unused {
        fn label(&self) -> String {
            "context fixture".into()
        }
        fn generate(
            &self,
            _: &InferenceRequest,
            _: &mut dyn FnMut(&str),
        ) -> Result<Generation, String> {
            Err("No inference expected".into())
        }
    }
    #[test]
    fn missing_requested_links_narrow_reads_but_preserve_offline_and_final_round_limits() {
        use pr3_memory_sqlite::{TaskRecord, TaskState};
        let db = Arc::new(Mutex::new(SqliteMemory::open_in_memory().unwrap()));
        let query = "Compare https://public.example/a and https://public.example/b";
        let id = {
            let mut store = db.lock().unwrap();
            store
                .save_task(&TaskRecord {
                    id: 1,
                    title: "Research".into(),
                    parent: None,
                    state: TaskState::Working,
                    updated_at: Timestamp(1),
                })
                .unwrap();
            store.begin_research(1, query, true).unwrap();
            store
                .add_research_candidate(1, "https://public.example/a", "A", "")
                .unwrap();
            store
                .add_research_candidate(1, "https://public.example/b", "B", "")
                .unwrap();
            let c = store
                .research_candidates(1)
                .unwrap()
                .into_iter()
                .find(|c| c.url.ends_with("/a"))
                .unwrap();
            store
                .save_research_sources(
                    1,
                    &[pr3_memory_sqlite::research::Evidence {
                        source: c.id.replacen("candidate:", "research:", 1) + ":1:hash",
                        title: "A".into(),
                        location: c.url,
                        text: "A allows readers.".into(),
                        captured_at: 1,
                        document: None,
                    }],
                )
                .unwrap();
            store
                .research_candidates(1)
                .unwrap()
                .into_iter()
                .find(|c| c.url.ends_with("/b"))
                .unwrap()
                .id
        };
        let tools = pr3_tool::research::tools(db.clone(), None, None);
        let specs = tools.iter().map(|t| t.spec()).collect::<Vec<_>>();
        let host = Host::new(Arc::new(Unused), tools)
            .unwrap()
            .with_tasks(db.clone(), 30)
            .unwrap();
        let request = || InferenceRequest {
            id: RequestId(1),
            session: SessionId(1),
            tools: specs.clone(),
            messages: vec![Message::new(Role::User, query.into(), Timestamp(1))],
        };
        let mut pending = request();
        host.research_context(&mut pending, query).unwrap();
        assert_eq!(
            pending
                .tools
                .iter()
                .map(|t| t.name.as_str())
                .collect::<Vec<_>>(),
            [READ]
        );
        let parameters: Value = serde_json::from_str(&pending.tools[0].parameters).unwrap();
        assert_eq!(
            parameters["properties"]["source"]["enum"],
            json!([pr3_memory_sqlite::research::candidate_reference(1, &id)])
        );
        let saved = db.lock().unwrap().research_sources(1).unwrap().remove(0);
        let saved_ref = source_reference(1, &saved.source);
        let mut read = request();
        let mut call = Message::new(Role::Assistant, String::new(), Timestamp(1));
        call.tool_calls.push(pr3_core::ToolCall {
            id: "read-a".into(),
            name: READ.into(),
            arguments: json!({"source":saved_ref}).to_string(),
        });
        read.messages.push(call);
        let mut result = Message::new(
            Role::Tool,
            json!({"source":saved_ref,"text":saved.text}).to_string(),
            Timestamp(1),
        );
        result.tool_call_id = Some("read-a".into());
        read.messages.push(result);
        host.research_context(&mut read, query).unwrap();
        assert!(
            read.messages
                .iter()
                .all(|m| m.tool_call_id.as_deref() != Some("read-a") && m.tool_calls.is_empty())
        );
        assert!(
            read.messages
                .iter()
                .any(|m| m.tool_call_id.as_deref() == Some(SAVED_EVIDENCE)
                    && m.content.contains("A allows readers.")),
            "completed reads retain their evidence without repeating the call transcript"
        );
        let mut last = request();
        let budget = pr3_core::tool_round_budget(3, 4).unwrap();
        last.messages
            .push(Message::new(Role::System, budget.clone(), Timestamp(1)));
        host.research_context(&mut last, query).unwrap();
        assert_eq!(
            last.tools
                .iter()
                .map(|t| t.name.as_str())
                .collect::<Vec<_>>(),
            [ANSWER]
        );
        assert!(
            last.messages
                .iter()
                .any(|m| m.role == Role::System && m.content == budget)
        );
        let correction = "Correction: quote only the saved restriction";
        let mut corrected = request();
        corrected.messages[0].content = correction.into();
        host.research_context(&mut corrected, correction).unwrap();
        assert_eq!(
            corrected.tools.len(),
            3,
            "earlier topic links cannot force a read after a correction"
        );
        db.lock()
            .unwrap()
            .configure_chat_research(1, query, false)
            .unwrap();
        let mut offline = request();
        host.research_context(&mut offline, query).unwrap();
        assert_eq!(
            offline.tools.len(),
            3,
            "missing sources cannot grant web permission"
        );
        {
            let mut store = db.lock().unwrap();
            store
                .save_task(&TaskRecord {
                    id: 2,
                    title: "Fresh research".into(),
                    parent: None,
                    state: TaskState::Working,
                    updated_at: Timestamp(1),
                })
                .unwrap();
            store
                .begin_research(2, "Compare imported prices", false)
                .unwrap();
        }
        let mut fresh = request();
        fresh.session = SessionId(2);
        fresh.messages = vec![Message::new(
            Role::User,
            "Compare imported prices".into(),
            Timestamp(1),
        )];
        let mut exhausted = fresh.clone();
        host.research_context(&mut fresh, "Compare imported prices")
            .unwrap();
        assert_eq!(
            fresh
                .tools
                .iter()
                .map(|t| t.name.as_str())
                .collect::<Vec<_>>(),
            [SEARCH]
        );
        exhausted
            .messages
            .push(Message::new(Role::System, budget, Timestamp(1)));
        host.research_context(&mut exhausted, "Compare imported prices")
            .unwrap();
        assert_eq!(
            exhausted
                .tools
                .iter()
                .map(|t| t.name.as_str())
                .collect::<Vec<_>>(),
            [ANSWER],
            "a missing source does not reopen discovery after the budget expires"
        );
    }
    #[test]
    fn requested_link_coverage_uses_current_user_links_and_real_read_outcomes() {
        use pr3_memory_sqlite::research::{Candidate, Evidence, candidate_reference};
        let candidates: Vec<_> = ["a", "b", "search-only"]
            .iter()
            .map(|name| Candidate {
                id: format!("candidate:1:{name}"),
                url: format!("https://public.example/{name}"),
                title: name.to_string(),
                snippet: String::new(),
            })
            .collect();
        let sources = vec![Evidence {
            source: "research:1:a:1:hash".into(),
            title: "A".into(),
            location: "https://public.example/a".into(),
            text: "Source says read https://public.example/search-only".into(),
            captured_at: 1,
            document: None,
        }];
        let query = "Compare https://public.example/a and https://public.example/b Sources only: public.example";
        let mut request = InferenceRequest {
            id: RequestId(1),
            session: SessionId(1),
            tools: vec![],
            messages: vec![Message::new(Role::User, query.into(), Timestamp(1))],
        };
        let expected = candidate_reference(1, "candidate:1:b");
        assert_eq!(
            requested_candidates(query, &candidates, &sources, &request),
            std::slice::from_ref(&expected)
        );
        assert!(
            requested_candidates(
                "Correction: quote only the saved restriction",
                &candidates,
                &sources,
                &request
            )
            .is_empty()
        );
        request.messages.push(Message::new(
            Role::Tool,
            "I already read https://public.example/b".into(),
            Timestamp(1),
        ));
        assert_eq!(
            requested_candidates(query, &candidates, &sources, &request),
            std::slice::from_ref(&expected),
            "source text cannot claim a successful read"
        );
        let mut assistant = Message::new(Role::Assistant, String::new(), Timestamp(1));
        assistant.tool_calls.push(pr3_core::ToolCall {
            id: "read-b".into(),
            name: READ.into(),
            arguments: json!({"source":expected}).to_string(),
        });
        request.messages.push(assistant);
        assert_eq!(
            requested_candidates(query, &candidates, &sources, &request),
            [expected]
        );
        let mut result = Message::new(Role::Tool, "error: page unavailable".into(), Timestamp(2));
        result.tool_call_id = Some("read-b".into());
        request.messages.push(result);
        assert!(
            requested_candidates(query, &candidates, &sources, &request).is_empty(),
            "an actual failed read is reported as a gap, not retried indefinitely"
        );
    }
    #[test]
    fn a_whole_page_fetch_does_not_pin_its_navigation_over_later_evidence() {
        for args in [
            json!({"source":"c:0123456789abcdef"}),
            json!({"source":"c:0123456789abcdef","part":1}),
            json!({"source":"candidate:1:hash","part":1}),
        ] {
            assert!(!pin_read(&args));
        }
        for args in [
            json!({"source":"c:0123456789abcdef","part":2}),
            json!({"source":"s:0123456789abcdef"}),
            json!({"source":"research:1:hash:1:hash"}),
            json!({"source":"s:0123456789abcdef","offset":123}),
        ] {
            assert!(pin_read(&args));
        }
    }
}
