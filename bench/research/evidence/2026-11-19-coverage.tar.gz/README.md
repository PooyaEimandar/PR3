# Long-page evidence coverage — 19 November 2026

This archive contains exposed development regressions, not a fresh held-out evaluation or a new matched OpenJarvis comparison. The production Host and local models ran against offline page fixtures, including the unchanged SQLite HTML captured for the 17 November baseline. No live Tavily or Android measurements were made in this run.

## Contents

- `matrix/`: the final frozen v13 corpus, manifest, six complete model/seed traces, diagnostic checks and explicit all-turn source review. The baseline corpus is copied byte-for-byte; its 16 cases are unchanged. Two exposed long-page cases add four turns per run.
- `source/`: the 136 source/build files named and hashed in the final manifest, including the added retrieval module and TypeScript coverage generator.
- `verification/`: passing final workspace, strict Clippy and native workflow logs, plus the separately run real-tokenizer budget test, TypeScript checks and Thumb build. The tokenizer test predates only the final one-based READ description and malformed-part recovery guard; its engine/retrieval implementation is identical to the frozen build.
- `candidates/`: both stopped earlier candidate matrices and their own source overlays. Candidate 1 exposed command-contaminated excerpt selection and a narrow-request ranking error. Candidate 2 exposed malformed `part: 0` being counted as an attempted read. They are not combined with the final matrix or reported as complete evaluations.
- `exploratory/`: earlier smoke inputs/outputs, development logs and failed verification attempts, retained separately. The exploratory Delta question was made explicit about free accounts before the final corpus freeze. The final corpus is identical across both candidate matrices and v13.
- `replay.ts`: recomputes counts from raw traces and reviewer decisions. Checks exact quotations, source/corpus hashes, unchanged baseline cases and restart snapshots, source caps, saved presence of every requested late-page fact and recorded tool budgets. It does not independently judge semantic support.
- `check-replay.ts`: negative controls using disposable copies: incomplete matrix, missing/duplicate review, changed quotation/corpora, changed restart capture time, missing late-page facts and exceeded execution limits must fail verification.

Model weights, executables, credentials and private application profiles are not included.

## Inspect without running a model

With Node 24 or later:

```sh
node replay.ts
node check-replay.ts
```

`source-review.json` records unblinded implementation-assistant judgments for every turn, including failures and borderline wording. Material unsupported claims, missing requested facts and obsolete or unrequested findings fail. Harmless redundancy and formatting do not. These judgments are not independent human validation. Both source attributions and each claim's associated quotations are reviewed; quote equality alone does not establish entailment.

## Reproduce inference

Use a separate PR3 checkout at `matrix/manifest.json`'s `pr3Head` and copy the `source/` overlay into that checkout. The final manifest records all overlay hashes, binary/model hashes, engine settings and hardware. Build the diagnostic there:

```sh
cargo build -p pr3-bench-documents --bin research --locked
```

Use the exact archived `matrix/corpus.json`, not regenerated page content. For each recorded model file and seed 1, 2 and 7, run the diagnostic sequentially into a new output path:

```sh
target/debug/research /absolute/path/to/model.gguf 1 /absolute/path/to/archive/matrix/corpus.json /absolute/path/to/new-output.jsonl
```

Repeat for the other seeds and model. Do not overwrite the evidence or rerun only failed cases. Keep the same 4096 context, 512 output reservation, sampling parameters and four-round/four-calls-per-round/twelve-call limits from the manifest. The diagnostic uses Cargo's development profile; timings are not release-build benchmarks. Fixed seeds do not guarantee identical output because task IDs and capture times vary. Model loading is excluded from recorded turn times. Offline fixtures omit provider latency; AC samples do not control thermal or other background effects.

The archived source may require the native toolchain/dependencies documented by PR3. A local rebuild need not reproduce the executable hash byte-for-byte; compare all source and model hashes before interpreting any result.
