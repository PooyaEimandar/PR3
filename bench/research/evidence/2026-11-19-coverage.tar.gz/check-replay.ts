/** Negative controls for the archive verifier. Only disposable copies are changed. */
import { cpSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const here=fileURLToPath(new URL('.',import.meta.url));
const scratch=mkdtempSync(join(tmpdir(),'pr3-evidence-controls-'));
const matrix=join(scratch,'matrix');
const read=(file:string)=>JSON.parse(readFileSync(join(matrix,file),'utf8'));
const write=(file:string,data:unknown)=>writeFileSync(join(matrix,file),JSON.stringify(data,null,2)+'\n');
const run=()=>spawnSync(process.execPath,[join(here,'replay.ts'),matrix],{encoding:'utf8'});
const results:{control:string;pass:boolean}[]=[];
function check(name:string,change:()=>void,expected:string) {
  rmSync(matrix,{recursive:true,force:true});cpSync(join(here,'matrix'),matrix,{recursive:true});
  change();const r=run();const pass=r.status!==0&&r.stderr.includes(expected);
  results.push({control:name,pass});if(!pass)throw Error(`${name}: unexpected verifier result ${r.status}\n${r.stderr}`);
}
try {
  cpSync(join(here,'matrix'),matrix,{recursive:true});
  const valid=run();if(valid.status!==0)throw Error('Valid archive rejected: '+valid.stderr);
  results.push({control:'unaltered evidence accepted',pass:true});
  check('incomplete matrix rejected',()=>{const p=read('progress.json');p.complete=false;write('progress.json',p);},'Matrix incomplete');
  check('missing source review rejected',()=>{const p=read('source-review.json');p.decisions.pop();write('source-review.json',p);},'Source review incomplete');
  check('duplicate source review rejected',()=>{const p=read('source-review.json');p.decisions[1]=p.decisions[0];write('source-review.json',p);},'Duplicate review decision');
  check('changed displayed quotation rejected',()=>{const p=join(matrix,'4b-seed1.jsonl');const rows=readFileSync(p,'utf8').trim().split('\n').map(x=>JSON.parse(x));rows[0].turns[0].answer=rows[0].turns[0].answer.replace(/^> .*$/mu,'> CORRUPTED-QUOTATION-NOT-IN-SOURCE');writeFileSync(p,rows.map(x=>JSON.stringify(x)).join('\n')+'\n');},'Quotation/source integrity failure');
  check('changed frozen corpus rejected',()=>writeFileSync(join(matrix,'corpus.json'),readFileSync(join(matrix,'corpus.json'),'utf8')+' '),'Corpus hash mismatch');
  check('changed baseline corpus rejected',()=>writeFileSync(join(matrix,'baseline-corpus.json'),readFileSync(join(matrix,'baseline-corpus.json'),'utf8')+' '),'Baseline corpus hash mismatch');
  check('changed restart capture time rejected',()=>{const p=join(matrix,'4b-seed1.jsonl');const rows=readFileSync(p,'utf8').trim().split('\n').map(x=>JSON.parse(x));rows[0].turns[1].evidence.sources[0].captured_at+=1;writeFileSync(p,rows.map(x=>JSON.stringify(x)).join('\n')+'\n');},'Restart source snapshot changed');
  check('exceeded execution limit rejected',()=>{const p=join(matrix,'4b-seed1.jsonl');const rows=readFileSync(p,'utf8').trim().split('\n').map(x=>JSON.parse(x));rows[0].turns[0].traces=[{steps:Array.from({length:5},()=>({step_type:'generate',output:{tool_calls:[{name:'answer_research'}]}}))}];writeFileSync(p,rows.map(x=>JSON.stringify(x)).join('\n')+'\n');},'Recorded execution limit exceeded');
  check('missing late-page fact rejected',()=>{const p=join(matrix,'4b-seed2.jsonl');const rows=readFileSync(p,'utf8').trim().split('\n').map(x=>JSON.parse(x));const row=rows.find(x=>x.id==='late-conditions-restart');for(const turn of row.turns)for(const source of turn.evidence.sources)source.text=source.text.replace('Delta export is available only to administrators.','REMOVED ADMINISTRATOR FACT.');writeFileSync(p,rows.map(x=>JSON.stringify(x)).join('\n')+'\n');},'Requested late-page fact missing from saved evidence');
  console.log(JSON.stringify({controls:results},null,2));
} finally {rmSync(scratch,{recursive:true,force:true});}
