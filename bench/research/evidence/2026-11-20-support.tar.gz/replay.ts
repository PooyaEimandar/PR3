/** Recompute the final development report from raw rows and explicit source review.
 * node replay.ts [matrix-directory]
 * Prints JSON; never overwrites evidence. Model weights/executables are not required.
 */
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const here = fileURLToPath(new URL('.', import.meta.url));
const dir = resolve(process.argv[2] ?? resolve(here, 'matrix'));
const read = <T>(name: string): T => JSON.parse(readFileSync(resolve(dir, name), 'utf8')) as T;
const digest = (bytes: Buffer | string) => createHash('sha256').update(bytes).digest('hex');
type Manifest = { corpusSha256: string; baselineCorpusSha256:string; productionSources: Record<string,string>; models: {name:string}[]; seeds:number[]; expectedRows:number; expectedTurns:number; limits:{toolRounds:number;callsPerRound:number;toolCalls:number} };
type Test = { id:string; suite:string; restart?:string; quotes?:string[] };
type Turn = { traces:{steps:{step_type:string;output:{tool_calls?:unknown[]}}[]}[]; answer:string; error:string|null; seconds:number; pass:boolean; events:{name?:string;success?:boolean}[]; evidence:{sources:{source:string;text:string;location:string;captured_at:number}[]} };
type Row = {id:string;seed:number;turns:Turn[]};
type Decision = {model:string;seed:number;id:string;turn:number;pass:boolean;borderline?:boolean;reason:string};
type Totals = {turns:number;diagnosticPass:number;validatedReports:number;runtimeErrors:number;failedToolCalls:number;sourceReviewedPass:number;borderlineFailures:number;restartRetrievalTurns:number;verifiedQuotations:number;maxToolRounds:number;maxToolCalls:number;seconds:number[]};
const manifest = read<Manifest>('manifest.json');
const bytes = readFileSync(resolve(dir,'corpus.json'));
if (digest(bytes) !== manifest.corpusSha256) throw Error('Corpus hash mismatch');
const cases = (JSON.parse(bytes.toString()) as {cases:Test[]}).cases;
const baselineBytes=readFileSync(resolve(dir,'baseline-corpus.json'));
if(digest(baselineBytes)!==manifest.baselineCorpusSha256)throw Error('Baseline corpus hash mismatch');
const baseline=(JSON.parse(baselineBytes.toString()) as {cases:Test[]}).cases;
if(baseline.some(c=>JSON.stringify(cases.find(x=>x.id===c.id))!==JSON.stringify(c)))throw Error('Baseline case changed');
if (new Set(cases.map(c=>c.id)).size !== cases.length) throw Error('Duplicate corpus case');
for(const [path,hash] of Object.entries(manifest.productionSources)) {
  if(path.startsWith('/') || path.split('/').includes('..')) throw Error('Unsafe source path');
  if(digest(readFileSync(resolve(here,'source',path))) !== hash) throw Error('Source overlay hash mismatch: '+path);
}
const progress = read<{complete:boolean;runs:{model:string;seed:number;file:string}[]}>('progress.json');
if(!progress.complete || progress.runs.length !== manifest.models.length*manifest.seeds.length) throw Error('Matrix incomplete');
const review = read<{complete:boolean;decisions:Decision[]}>('source-review.json');
if(!review.complete || review.decisions.length !== manifest.expectedTurns) throw Error('Source review incomplete');
const key = (m:string,s:number,id:string,t:number) => `${m}/${s}/${id}/${t}`;
const decisions = new Map(review.decisions.map(d=>[key(d.model,d.seed,d.id,d.turn),d]));
if(decisions.size !== review.decisions.length) throw Error('Duplicate review decision');
const groups: Record<string,Totals> = {};
const caseScores: Record<string,{turns:number;sourceReviewedPass:number}> = {};
const seen = new Set<string>(), consumed = new Set<string>();
let rowCount=0, turnCount=0;
let unchangedRestartSnapshots=0, lateCitedPassages=0;
let coverageSnapshotsWithAllRequestedFacts=0;
function quotations(turn:Turn) {
  const sources = new Map(turn.evidence.sources.map(s=>[s.source,s.text]));
  let quote:string[]=[], verified=0;
  for(const line of turn.answer.split('\n')) {
    if(line.startsWith('> ')) quote.push(line.slice(2));
    else if(line.startsWith('Source: ')) {
      const id=line.match(/\[((?:research|document):[^\]\s]+)\]$/u)?.[1];
      const text=quote.join('\n');
      if(!id || !text || Buffer.byteLength(text)>500 || !sources.get(id)?.includes(text)) throw Error('Quotation/source integrity failure');
      verified++;quote=[];
    } else if(line.trim()) quote=[];
  }
  return verified;
}
for(const run of progress.runs) {
  const runKey=`${run.model}/${run.seed}`;
  if(seen.has(runKey) || !manifest.models.some(m=>m.name===run.model) || !manifest.seeds.includes(run.seed) || !/^(?:4b|27b)-seed(?:1|2|7)\.jsonl$/u.test(run.file)) throw Error('Duplicate/foreign run');
  seen.add(runKey);
  const rows=readFileSync(resolve(dir,run.file),'utf8').trim().split('\n').filter(Boolean).map(line=>JSON.parse(line) as Row);
  if(rows.length!==cases.length || new Set(rows.map(r=>r.id)).size!==rows.length) throw Error('Missing/duplicate case');
  rowCount+=rows.length;
  for(const row of rows) {
    const test=cases.find(c=>c.id===row.id);
    if(!test || row.seed!==run.seed || row.turns.length!==(test.restart?2:1)) throw Error('Foreign case/seed/turn');
    if(test.restart) {
      const stable=(t:Turn)=>JSON.stringify(t.evidence.sources.toSorted((a,b)=>a.source.localeCompare(b.source)));
      if(stable(row.turns[0]!)!==stable(row.turns[1]!))throw Error('Restart source snapshot changed');
      unchangedRestartSnapshots++;
    }
    for(const [index,turn] of row.turns.entries()) {
      const id=key(run.model,run.seed,row.id,index), decision=decisions.get(id);
      if(!decision || typeof decision.pass!=='boolean' || !decision.reason.trim() || !Number.isFinite(turn.seconds) || turn.seconds<0 || typeof turn.pass!=='boolean') throw Error('Invalid turn/review');
      consumed.add(id);turnCount++;
      const caseScore=caseScores[`${run.model}/${row.id}/${index}`]??={turns:0,sourceReviewedPass:0};
      caseScore.turns++;caseScore.sourceReviewedPass+=Number(decision.pass);
      const verified=quotations(turn);
      if(test.suite==='coverage') {
        if(!test.quotes?.length || test.quotes.some(q=>!turn.evidence.sources.some(s=>s.text.includes(q))))throw Error('Requested late-page fact missing from saved evidence');
        coverageSnapshotsWithAllRequestedFacts++;
      }
      if(turn.evidence.sources.length>96 || turn.evidence.sources.reduce((n,s)=>n+Buffer.byteLength(s.text),0)>128*1024)throw Error('Task source cap exceeded');
      const pages=new Map<string,number>();
      for(const s of turn.evidence.sources) {
        const [origin]=s.location.split(' · part ');
        if(s.source.startsWith('research:'))pages.set(origin!,1+(pages.get(origin!)??0));
        if(test.suite==='coverage' && Number(s.location.match(/ · part (\d+) of /u)?.[1]??0)>12 && turn.answer.includes('['+s.source+']'))lateCitedPassages++;
      }
      if([...pages.values()].some(n=>n>12))throw Error('Page source cap exceeded');
      if(turn.events.some(e=>e.name&&!['research_sources','read_research_source','answer_research'].includes(e.name)))throw Error('Unexpected executed research tool');
      const rounds=turn.traces.flatMap(t=>t.steps).filter(s=>s.step_type==='generate' && (s.output.tool_calls?.length??0)>0);
      const callCount=rounds.reduce((n,s)=>n+(s.output.tool_calls?.length??0),0);
      if(rounds.length>manifest.limits.toolRounds || callCount>manifest.limits.toolCalls || rounds.some(s=>(s.output.tool_calls?.length??0)>manifest.limits.callsPerRound)) throw Error('Recorded execution limit exceeded');
      const report=turn.events.some(e=>e.name==='answer_research' && e.success===true);
      if(decision.pass && (turn.error!==null || !report)) throw Error('A failed runtime cannot be a source-reviewed success');
      for(const groupKey of [`${run.model}/all`,`${run.model}/${test.suite}`]) {
        const g=groups[groupKey]??={turns:0,diagnosticPass:0,validatedReports:0,runtimeErrors:0,failedToolCalls:0,sourceReviewedPass:0,borderlineFailures:0,restartRetrievalTurns:0,verifiedQuotations:0,maxToolRounds:0,maxToolCalls:0,seconds:[]};
        g.turns++;g.diagnosticPass+=Number(turn.pass);g.validatedReports+=Number(report);g.runtimeErrors+=Number(turn.error!==null);g.failedToolCalls+=turn.events.filter(e=>e.name && e.success===false).length;
        g.sourceReviewedPass+=Number(decision.pass);g.borderlineFailures+=Number(!decision.pass && decision.borderline===true);
        g.restartRetrievalTurns+=Number(index>0 && turn.events.some(e=>e.name==='research_sources'||e.name==='read_research_source'));
        g.verifiedQuotations+=verified;g.maxToolRounds=Math.max(g.maxToolRounds,rounds.length);g.maxToolCalls=Math.max(g.maxToolCalls,callCount);g.seconds.push(turn.seconds);
      }
    }
  }
}
if(rowCount!==manifest.expectedRows || turnCount!==manifest.expectedTurns || consumed.size!==decisions.size) throw Error('Incomplete/foreign evidence');
console.log(JSON.stringify({
  scope:'Exposed development cases, not held-out or a current OpenJarvis comparison. Source review is unblinded and non-independent. Timings are observational desktop measurements.',
  rows:rowCount,turns:turnCount,sourceFilesVerified:Object.keys(manifest.productionSources).length,baselineCasesUnchanged:baseline.length,unchangedRestartSnapshots,lateCitedPassages,coverageSnapshotsWithAllRequestedFacts,
  caseScores,
  failures:review.decisions.filter(d=>!d.pass),
  borderlineJudgments:review.decisions.filter(d=>d.borderline),
  groups:Object.fromEntries(Object.entries(groups).map(([key,g])=>{
    const s=g.seconds.toSorted((a,b)=>a-b);
    return [key,{...g,seconds:undefined,medianSeconds:(s[(s.length-1)>>1]!+s[s.length>>1]!)/2,p95Seconds:s[Math.ceil(s.length*.95)-1]}];
  })),
},null,2));
