
    #[test]
    fn a_two_passage_repair_keeps_complementary_rules_from_the_same_document() {
        let fixtures: Value = serde_json::from_str(include_str!("../tests/fixtures/technical-evidence.json")).unwrap();
        for case in fixtures["cases"].as_array().unwrap().iter().filter(|case| {
            case["base"].as_str().or_else(|| case["id"].as_str()) == Some("fresh-git-diff")
        }) {
            let query = case["query"].as_str().unwrap();
            let packet = json!({"sources":case["sources"]}).to_string();
            let host = saved_evidence_view(&packet, query, "", 1200, 4).unwrap();
            for bytes in [800, 500] {
                let repair = saved_evidence_view(&host, query, "", bytes, 2).unwrap();
                let view: Value = serde_json::from_str(&repair).unwrap();
                let quotes = view["sources"].as_array().unwrap().iter().flat_map(spans).collect::<Vec<_>>();
                for required in ["--no-index", "outside a working tree controlled by Git", "--exit-code\nMake the program exit", "0 means no differences"] {
                    assert!(quotes.iter().any(|(_, text)| text.contains(required)), "{} budget {bytes} lost {required}: {repair}", case["id"]);
                }
                assert!(view["sources"].as_array().unwrap().len() <= 2);
                for source in view["sources"].as_array().unwrap() {
                    let original = case["sources"].as_array().unwrap().iter().find(|s| s["source"] == source["source"]).unwrap()["text"].as_str().unwrap();
                    for (at, text) in spans(source) {
                        assert!(text.len() <= 500);
                        assert_eq!(original.get(at as usize..at as usize+text.len()), Some(text));
                    }
                }
            }
        }
    }
