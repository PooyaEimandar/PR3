
    #[test]
    #[ignore = "requires the local 4B tokenizer; no generation or network"]
    fn actual_token_budget_keeps_complementary_sources_during_report_repair() {
        let config = EngineConfig { n_ctx: 4096, max_new_tokens: 512, gpu_layers: 0, capture_prompt_evidence: true, ..EngineConfig::default() };
        let path = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../model/Qwen3.5-4B-Q4_K_M.gguf");
        let model = load(&path, &config).unwrap();
        let session = Session::new(&model, config).unwrap();
        let fixtures: serde_json::Value = serde_json::from_str(include_str!("../tests/fixtures/technical-evidence.json")).unwrap();
        let case = fixtures["cases"].as_array().unwrap().iter().find(|case| case["id"] == "fresh-git-diff").unwrap();
        let query = case["query"].as_str().unwrap();
        let packet = serde_json::json!({"sources":case["sources"]}).to_string();
        let host = crate::saved_evidence_view(&packet, query, "", 1200, 4).unwrap();
        let balanced = crate::evidence::saved_evidence_with_budgets(&host, query, "", &[400,500,400]).unwrap();
        let expected_view = crate::evidence::citation_view(&balanced).unwrap();
        let report = ToolDef { name: "answer_research".into(), description: "Report checked quotations".into(), parameters: r#"{"type":"object","properties":{}}"#.into(), read_only: true, report: true };
        let mut checked = 0;
        let mut compressed = 0;
        for padding in (0..512).step_by(4) {
            let mut messages = vec![
                ChatMessage::new(ChatRole::System, "Keep the trusted rules. ".repeat(padding)),
                ChatMessage::new(U, query),
                ChatMessage::new(T, host.clone()),
                ChatMessage::new(T, "error: The previous citation reference was rejected. Repair only this citation using the exact saved source and quotation. Keep the other supported findings within the existing execution budget."),
            ];
            messages[2].saved_evidence = true;
            let original = messages.clone();
            let mut explicit = messages.clone();
            explicit[2].content = balanced.clone();
            let Ok(expected) = session.prompt_tokens(&explicit, &[report.clone()]) else { continue };
            if expected.evidence.unwrap().source_views != vec![expected_view.clone()] { continue }
            checked += 1;
            let fitted = session.prompt_tokens(&messages, &[report.clone()]).unwrap();
            assert!(fitted.tokens.len()+512 <= 4096);
            let evidence = fitted.evidence.unwrap();
            let view: serde_json::Value = serde_json::from_str(&evidence.source_views[0]).unwrap();
            let sources = view["sources"].as_array().unwrap();
            compressed += usize::from(sources.len() < 4);
            let quotes = sources.iter().flat_map(|s| s["quotes"].as_array().unwrap()).map(|q| q["text"].as_str().unwrap()).collect::<Vec<_>>();
            for required in ["--no-index", "outside a working tree controlled by Git", "--exit-code\nMake the program exit", "0 means no differences"] {
                assert!(quotes.iter().any(|quote| quote.contains(required)), "padding {padding}, prompt {} lost {required}: {view}", evidence.prompt_tokens);
            }
            assert_eq!(messages, original, "fitting changes only inference copies");
        }
        assert!(checked > 0 && compressed > 0, "exercise actual context pressure");
    }
