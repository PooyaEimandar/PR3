import {readFileSync,writeFileSync,mkdirSync,cpSync} from 'node:fs';
import {join} from 'node:path';
const previous='/private/tmp/pr3-evidence-completeness-2026-11-20';
const work='/private/tmp/pr3-evidence-repair-2026-11-21';
const helpers=['audit-inference.ts','check-inference.ts','check-freeze.ts','freeze-build.ts','status.ts','next-review.ts','record-review.ts','read-answers.ts','read-evidence.ts','read-summary.ts','inspect-rejections.ts','run-matrices.ts','power-summary.ts','log-power-event.ts','finalize.ts'];
for(const name of helpers){
 let text=readFileSync(join(previous,name),'utf8').replaceAll(previous,work)
  .replaceAll('evidence-completeness-dev-2026-11-20','evidence-repair-dev-2026-11-21')
  .replaceAll('evidence-completeness-exposed-2026-11-20','evidence-repair-exposed-2026-11-21')
  .replaceAll("prefix='2026-11-20-evidence-completeness'","prefix='2026-11-21-evidence-repair'")
  .replaceAll('2026-11-20-evidence-selection','2026-11-20-evidence-completeness')
  .replaceAll('pr3-completeness-verify-','pr3-repair-verify-');
 if(name==='finalize.ts')text=text.replace('json|jsonl|log|patch','json|jsonl|log|patch|rs');
 writeFileSync(join(work,name),text,{flag:'wx'});
}
for(const matrix of ['development','exposed']){
 const dir=join(work,'archive',matrix);mkdirSync(dir,{recursive:true});
 for(const helper of ['replay.ts','check-replay.ts'])cpSync(join(previous,'archive',matrix,helper),join(dir,helper),{errorOnExist:true,force:false});
}
writeFileSync(join(work,'scope.json'),JSON.stringify({scope:'Full unchanged exposed development and regression matrices after the deterministic report-repair evidence loss. No retry substitution. All answers reviewed; no new holdout or OpenJarvis claim.',previousArchive:'2026-11-20-evidence-completeness.tar.gz',models:['4B','27B'],seeds:[1,2,7],preservedAttempts:['failed global ranking candidate','successful conservative budget refinement']},null,2)+'\n',{flag:'wx'});
