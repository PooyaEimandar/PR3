/** Wait at most 45 seconds for unreviewed complete rows; never grades answers. */
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
type Step={step_type:string;input?:{tool?:string};output?:{success?:boolean;result?:string}};
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/research/result';
const deadline=Date.now()+45000;
let pending:unknown[]=[];
do {
  pending=[];
  scan:
  for(const name of ['evidence-repair-dev-2026-11-21','evidence-repair-exposed-2026-11-21']) {
    const dir=join(root,name), corpusPath=join(dir,'corpus.json');
    if(!existsSync(corpusPath))continue;
    const corpus=JSON.parse(readFileSync(corpusPath,'utf8')).cases;
    const reviewPath=join(dir,'source-review.json');
    const decisions=existsSync(reviewPath)?JSON.parse(readFileSync(reviewPath,'utf8')).decisions:[];
    for(const label of ['4b','27b'])for(const seed of [1,2,7]) {
      const path=join(dir,`${label}-seed${seed}.jsonl`);
      if(!existsSync(path))continue;
      let index=0, emitted=0;
      for(const line of readFileSync(path,'utf8').split('\n').slice(0,-1)) {
        const row=JSON.parse(line), test=corpus.find((c:{id:string})=>c.id===row.id);
        for(const [turn,t]of row.turns.entries()) {
          const current=index++;
          if(decisions.some((d:{model:string;seed:number;id:string;turn:number})=>d.model.includes(label==='4b'?'-4B-':'-27B-')&&d.seed===seed&&d.id===row.id&&d.turn===turn))continue;
          if(emitted++>=8)continue;
          pending.push({matrix:name,label,seed,index:current,id:row.id,turn,request:turn===0?test.topic:test.restart,
            rubric:(turn===0?test.review:test.restart_review??test.review)?.rubric,
            expectedQuotes:turn===0?test.quotes:test.restart_checks?.quotes,
            answer:t.answer.replace(/ \[(?:research|document):[^\]\n]+\]/gu,'').replace('Research findings\n\nThe analysis below is model-generated. The attached quotations are checked against saved sources.\n\n',''),error:t.error,diagnosticPass:t.pass,seconds:t.seconds,
            failedCalls:t.events.filter((e:{success?:boolean})=>e.success===false).map((e:{name:string;output:string})=>({tool:e.name,error:e.output})),
            traceRejections:t.traces.flatMap((trace:{steps:Step[]})=>trace.steps).filter((step:Step)=>step.step_type==='tool_call'&&step.output?.success===false).map((step:Step)=>({tool:step.input?.tool,error:step.output?.result}))});
        }
      }
      if(pending.length)break scan;
    }
  }
  if(pending.length>=8)break;
  if(Date.now()<deadline)await new Promise(resolve=>setTimeout(resolve,2000));
} while(Date.now()<deadline);
if(pending.length)for(const item of pending)console.log(JSON.stringify(item));
else console.log('No new complete case yet.');
