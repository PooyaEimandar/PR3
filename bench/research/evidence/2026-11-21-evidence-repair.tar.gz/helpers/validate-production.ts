import {spawn} from 'node:child_process';
import {createWriteStream,writeFileSync} from 'node:fs';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const work='/private/tmp/pr3-evidence-repair-2026-11-21';
const results:unknown[]=[];
const checks:[string,string,string[]][]=[
 ['format-final','cargo',['fmt','--all','--','--check']],
 ['workspace-final','cargo',['test','--workspace','--locked','--offline','-j','2']],
 ['clippy-final','cargo',['clippy','--workspace','--all-targets','--locked','--offline','-j','2','--','-D','warnings']],
 ['token-budget-final','cargo',['test','--locked','--offline','-j','2','-p','pr3-llamacpp','--lib','actual_token_budget_','--','--ignored','--test-threads=1']],
 ['build-final','cargo',['build','--locked','--offline','-j','2','-p','pr3-bench-documents','--bin','research']],
 ['whitespace-final','git',['diff','--check']],
];
for(const[name,command,args]of checks){
 const startedAt=new Date().toISOString();console.log(JSON.stringify({check:name,startedAt}));
 const log=createWriteStream(`${work}/${name}.log`,{flags:'wx'});
 const code=await new Promise<number|null>((resolve,reject)=>{const child=spawn(command,args,{cwd:root,stdio:['ignore','pipe','pipe']});child.stdout.pipe(log,{end:false});child.stderr.pipe(log,{end:false});child.once('error',reject);child.once('close',code=>{log.end();resolve(code);});});
 results.push({name,command,args,startedAt,finishedAt:new Date().toISOString(),exitCode:code});
 writeFileSync(`${work}/validation.json`,JSON.stringify(results,null,2)+'\n');
 if(code!==0)throw Error(`Validation failed: ${name}; preserve log before retrying`);
 console.log(JSON.stringify({check:name,exitCode:code}));
}
