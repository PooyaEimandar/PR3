import {cpSync, mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {join} from 'node:path';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const work='/private/tmp/pr3-evidence-repair-2026-11-21';
const probe=join(work,'probe');
mkdirSync(join(probe,'crate/pr3-llamacpp/src'),{recursive:true});
cpSync(join(root,'crate/pr3-llamacpp/tests'),join(probe,'crate/pr3-llamacpp/tests'),{recursive:true});
cpSync(join(root,'Cargo.lock'),join(probe,'Cargo.lock'));
writeFileSync(join(probe,'Cargo.toml'),`[package]
name = "pr3-repair-probe"
version = "0.0.0"
edition = "2024"
[dependencies]
pr3-memory = { path = "${root}/crate/pr3-memory", default-features = false }
serde_json = "1"
[lib]
path = "lib.rs"
`);
writeFileSync(join(probe,'lib.rs'),'#[path="crate/pr3-llamacpp/src/evidence.rs"]\nmod evidence;\n');
const regression=`
    #[test]
    fn a_two_passage_repair_keeps_complementary_rules_from_the_same_document() {
        let fixtures: Value = serde_json::from_str(include_str!("../tests/fixtures/technical-evidence.json")).unwrap();
        for case in fixtures["cases"].as_array().unwrap().iter().filter(|case| {
            case["base"].as_str().or_else(|| case["id"].as_str()) == Some("fresh-git-diff")
        }) {
            let query = case["query"].as_str().unwrap();
            let packet = json!({"sources":case["sources"]}).to_string();
            let host = saved_evidence_view(&packet, query, "", 1200, 4).unwrap();
            for bytes in [800, 500] {
                let repair = saved_evidence_view(&host, query, "", bytes, 2).unwrap();
                let view: Value = serde_json::from_str(&repair).unwrap();
                let quotes = view["sources"].as_array().unwrap().iter().flat_map(spans).collect::<Vec<_>>();
                for required in ["--no-index", "outside a working tree controlled by Git", "--exit-code\\nMake the program exit", "0 means no differences"] {
                    assert!(quotes.iter().any(|(_, text)| text.contains(required)), "{} budget {bytes} lost {required}: {repair}", case["id"]);
                }
                assert!(view["sources"].as_array().unwrap().len() <= 2);
                for source in view["sources"].as_array().unwrap() {
                    let original = case["sources"].as_array().unwrap().iter().find(|s| s["source"] == source["source"]).unwrap()["text"].as_str().unwrap();
                    for (at, text) in spans(source) {
                        assert!(text.len() <= 500);
                        assert_eq!(original.get(at as usize..at as usize+text.len()), Some(text));
                    }
                }
            }
        }
    }
`;
const source=readFileSync(join(root,'crate/pr3-llamacpp/src/evidence.rs'),'utf8');
const marker='    #[test]\n    fn captured_technical_pages_keep_the_requested_rules_through_host_and_token_projection()';
if(!source.includes(marker))throw Error('Missing insertion point');
writeFileSync(join(work,'repair-regression.rs'),regression);
writeFileSync(join(work,'candidate-evidence.rs'),source.replace(marker,regression+'\n'+marker));
// The isolated probe needs the selection code, not unrelated prompt-renderer tests.
// The complete existing suite remains in candidate-evidence.rs for integration.
writeFileSync(join(probe,'crate/pr3-llamacpp/src/evidence.rs'),source.split('#[cfg(test)]')[0]+'\n#[cfg(test)]\nmod tests {\nuse super::*;\n'+regression+'\n}\n');
console.log('Prepared isolated probe; production files unchanged.');
