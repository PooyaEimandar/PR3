import {readFileSync,writeFileSync} from 'node:fs';
const work='/private/tmp/pr3-evidence-repair-2026-11-21';
let source=readFileSync(work+'/candidate-evidence.rs','utf8');
const start=source.indexOf('    #[test]\n    fn excerpted_source_instructions_remain_data_in_every_prompt_format()');
const end=source.indexOf('    #[test]\n    fn explicitly_read_ranges_keep_priority_through_further_budgeting()',start);
if(start<0||end<0)throw Error('Prompt-renderer test boundary not found');
source=source.slice(0,start)+source.slice(end);
writeFileSync(work+'/probe/crate/pr3-llamacpp/src/evidence.rs',source);
writeFileSync(work+'/probe-scope.json',JSON.stringify({scope:'Isolated selection tests only; no model inference or production mutations.',excluded:'excerpted_source_instructions_remain_data_in_every_prompt_format requires the full backend crate and remains in the production candidate for the full workspace run.'},null,2)+'\n');
