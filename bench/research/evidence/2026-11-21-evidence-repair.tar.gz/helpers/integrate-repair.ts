import {readFileSync,writeFileSync,cpSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3',work='/private/tmp/pr3-evidence-repair-2026-11-21';
const old='/private/tmp/pr3-evidence-completeness-2026-11-20';
const frozen=JSON.parse(readFileSync(`${old}/build-freeze-completeness4.json`,'utf8'));
const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const verification=JSON.parse(readFileSync(`${root}/bench/research/evidence/2026-11-20-evidence-completeness-archive-check.json`,'utf8'));
if(!verification.extractedReplaysMatch||hash(`${root}/bench/research/evidence/2026-11-20-evidence-completeness.tar.gz`)!==verification.archiveSha256)throw Error('Prior archive must verify first');
let patch='';const files=['crate/pr3-llamacpp/src/evidence.rs','crate/pr3-llamacpp/src/session.rs'];
for(const path of files){
 if(hash(`${root}/${path}`)!==frozen.productionSources[path])throw Error(`Production file changed: ${path}`);
 try{patch+=execFileSync('diff',['-u',`${root}/${path}`,`${work}/tokenizer-probe/${path}`],{encoding:'utf8'});}catch(error){const e=error as {status:number;stdout:string};if(e.status!==1)throw error;patch+=e.stdout;}
}
writeFileSync(`${work}/validated-repair.patch`,patch,{flag:'wx'});
for(const path of files)cpSync(`${work}/tokenizer-probe/${path}`,`${root}/${path}`);
writeFileSync(`${work}/integrated.json`,JSON.stringify({at:new Date().toISOString(),previousArchiveSha256:verification.archiveSha256,files:files.map(path=>({path,sha256:hash(`${root}/${path}`)}))},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({integrated:files}));
