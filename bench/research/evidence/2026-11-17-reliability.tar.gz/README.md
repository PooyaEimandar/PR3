# Research reliability evidence — final v17 development build

This archive contains exposed development regressions, not a fresh held-out set or a current OpenJarvis comparison. The original v1 comparison remains separate in the repository.

- matrix/: frozen corpus/manifest, all six model-seed outputs, logs, automatic diagnostics and full implementation-assistant source review.
- exploratory/: earlier smoke attempts and native UI observations. These include failures and are not added to final scores.
- candidates/: interrupted v14/v16 matrices, retained separately; no completed-matrix claim is made for them.
- source/: exact source overlay on the git revision in source-check.json. All 132 files are checked against the final manifest.
- verification/: Rust/TypeScript checks and the native build configuration/log. This is an ad hoc signed debug app, not a notarized release.

With Node 24 or later, run:

    node replay.ts

This recomputes the per-model/per-suite summary, checks every displayed quotation against its recorded source, checks review coverage/uniqueness and recorded execution limits, and rejects incomplete or foreign runs. It prints JSON without modifying evidence. Compare it to final-summary.json. Run `node check-replay.ts` for disposable-copy negative controls: incomplete runs, missing/duplicate review decisions, a changed quotation and a changed frozen corpus must be rejected. Borderline source-review judgments are marked explicitly; this is unblinded assistant review, not independent human validation.

To reproduce inference, overlay source/ on the recorded base revision and use the pinned Cargo.lock and model files whose hashes are in matrix/manifest.json. Build the diagnostic binary, then run each model/seed sequentially against the archived corpus:

    cargo build -p pr3-bench-documents --bin research --locked
    target/debug/research MODEL SEED /path/to/matrix/corpus.json NEW_OUTPUT.jsonl

Repeat for both models and seeds 1/2/7, always using a new output path. To prepare a separate new matrix instead, run bench/research/run-reliability.ts; that runner fetches public HTML again and creates a new corpus. Runtime IDs/timestamps and hardware nondeterminism can vary even at fixed seeds. The captured traces preserve the observed inputs/results. Model weights, native executables, credentials, private app databases and personal chats are not redistributed.

Desktop timings include all attempted turns, including failed ones, with model loading outside turn timing. They are observational; they do not measure native Tavily provider latency, Android latency, or controlled energy use. Native live timing notes are UI polling upper bounds.
