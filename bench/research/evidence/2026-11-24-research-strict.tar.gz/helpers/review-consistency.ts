/** Check that every identical displayed answer (citation identifiers removed) for the same matrix,
 * case and turn received the same judgment across all reviewed runs, including judgments copied
 * between runs. This never creates or changes a decision. TAG [TAG...] */
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { here, runs } from './runs.ts';
const extra = process.argv.slice(2);
if (!extra.length) throw Error('TAG required');
const tags = ['2026-11-22', ...extra];
type Entry = { run: string; label: string; seed: number; pass: boolean; borderline: boolean };
const groups = new Map<string, Entry[]>();
const perRun: Record<string, { turns: number; distinctDisplays: number }> = {};
for (const tag of tags) for (const [name, dir] of Object.entries(runs[tag]!)) {
  const review = JSON.parse(readFileSync(join(dir, 'source-review.json'), 'utf8'));
  if (!review.complete) throw Error('Review incomplete: ' + tag);
  const seen = new Set<string>(); let turns = 0;
  for (const label of ['4b', '27b']) for (const seed of [1, 2, 7]) {
    for (const line of readFileSync(join(dir, `${label}-seed${seed}.jsonl`), 'utf8').trim().split('\n')) {
      const row = JSON.parse(line);
      for (const [turn, t] of row.turns.entries()) {
        const d = review.decisions.find((d: any) => d.model.includes(label === '4b' ? '-4B-' : '-27B-') && d.seed === seed && d.id === row.id && d.turn === turn);
        if (!d) throw Error('Missing decision');
        turns++;
        const display = t.answer.replace(/ \[(?:research|document):[^\]\n]+\]/gu, '');
        const key = `${name}/${row.id}/${turn}/${createHash('sha256').update(JSON.stringify({ display, error: t.error })).digest('hex')}`;
        seen.add(key);
        const list = groups.get(key) ?? []; list.push({ run: tag, label, seed, pass: d.pass, borderline: d.borderline ?? false }); groups.set(key, list);
      }
    }
  }
  const r = perRun[tag] ??= { turns: 0, distinctDisplays: 0 }; r.turns += turns; r.distinctDisplays += seen.size;
}
for (const [tag, r] of Object.entries(perRun)) if (r.turns !== (runs[tag]!.development ? 240 : 78)) throw Error('Unexpected denominator: ' + tag);
for (const [key, list] of groups) if (list.some(d => d.pass !== list[0]!.pass || d.borderline !== list[0]!.borderline)) throw Error('Inconsistent judgments: ' + key + ' ' + JSON.stringify(list));
const shared = [...groups.values()].filter(list => new Set(list.map(d => d.run)).size > 1).length;
const result = { runs: tags, normalization: 'Only internal research/document citation annotations removed; all answer wording, quotations and source metadata retained. Same matrix/case/turn and error required.', perRun, distinctDisplaysAcrossRuns: groups.size, displaysSharedBetweenRuns: shared, consistent: true, groups: [...groups].map(([key, decisions]) => ({ key, decisions })) };
writeFileSync(join(here, `review-consistency-${extra.join('-')}.json`), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ runs: tags, perRun, distinctDisplaysAcrossRuns: groups.size, displaysSharedBetweenRuns: shared, consistent: true }));
