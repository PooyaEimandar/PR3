/** Render report tables from completed review, replay and comparison artifacts. No scoring. */
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { here } from './runs.ts';
const read = (path: string) => JSON.parse(readFileSync(path, 'utf8'));
const metrics = read(join(here, 'final-metrics-strict4.json')).strict4.counts;
const summary = read('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/.claude/worktrees/research-strict-quality/bench/research/evidence/2026-11-24-research-strict-summary.json');
const prior = read(join(here, 'prior-comparison.json'));
const names = ['Qwen3.5-4B-Q4_K_M.gguf', 'Qwen3.8-27B-Q4_K_M.gguf'];
const label = (m: string) => m.includes('-4B-') ? '4B' : '27B';
const matrixName = (m: string) => m === 'development' ? 'Development' : 'Exposed regression';
console.log('| Matrix | Model | Main | Strict | Lenient |');
console.log('|---|---|---:|---:|---:|');
for (const matrix of ['development', 'exposed']) for (const model of names) {
  const c = metrics[`${matrix}/${model}`];
  console.log(`| ${matrixName(matrix)} | ${label(model)} | ${c.main}/${c.turns} | ${c.strict}/${c.turns} | ${c.lenient}/${c.turns} |`);
}
for (const [group, text] of [['all', 'Total'], ['restart', 'Restart subset']]) {
  const c = metrics[group];
  console.log(`| ${text} | Both | **${c.main}/${c.turns}** | **${c.strict}/${c.turns}** | **${c.lenient}/${c.turns}** |`);
}
console.log('\n| Matrix | Model | Seed | Main | Strict |');
console.log('|---|---|---:|---:|---:|');
for (const matrix of ['development', 'exposed']) for (const model of names) for (const seed of [1, 2, 7]) {
  const c = metrics[`${matrix}/${model}/seed${seed}`];
  console.log(`| ${matrixName(matrix)} | ${label(model)} | ${seed} | ${c.main}/${c.turns} | ${c.strict}/${c.turns} |`);
}
console.log('\n| Matrix | Model | Median turn (s) | p95 (s) | Maximum (s) |');
console.log('|---|---|---:|---:|---:|');
for (const matrix of ['development', 'exposed']) for (const model of names) {
  const g = summary[matrix].groups[`${model}/all`];
  console.log(`| ${matrixName(matrix)} | ${label(model)} | ${g.medianSeconds.toFixed(2)} | ${g.p95Seconds.toFixed(2)} | ${g.maxSeconds.toFixed(2)} |`);
}
console.log('\n| Previous strict failure (2026-11-22) | Final main | Final strict |');
console.log('|---|---|---|');
for (const matrix of ['development', 'exposed']) for (const d of prior[matrix].previousStrictFailures) {
  console.log(`| ${matrixName(matrix)}, ${label(d.model)} seed ${d.seed}, \`${d.id}\`, turn ${d.turn} | ${d.currentPass ? 'Pass' : 'Fail'} | ${d.currentStrict ? 'Pass' : 'Fail'} |`);
}
console.log('\nNew strict failures:');
for (const matrix of ['development', 'exposed']) for (const d of prior[matrix].newStrictFailures) console.log(`- ${matrixName(matrix)}, ${label(d.model)} seed ${d.seed}, \`${d.id}\`, turn ${d.turn}: ${d.reason.split(' Borderline: ')[1] ?? d.reason}`);
console.log('New main failures:', prior.development.newMainFailures.length + prior.exposed.newMainFailures.length);
