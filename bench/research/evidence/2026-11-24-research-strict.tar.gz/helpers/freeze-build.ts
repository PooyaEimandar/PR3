// Freeze the research executable, a source overlay and the production patch before inference.
import { readFileSync, writeFileSync, mkdirSync, cpSync } from 'node:fs';
import { execFileSync, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { join, dirname } from 'node:path';
const root = '/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/.claude/worktrees/research-strict-quality';
const out = dirname(new URL(import.meta.url).pathname);
const tag = process.argv[2];
if (!tag) throw Error('TAG required');
const hash = (p: string) => createHash('sha256').update(readFileSync(p)).digest('hex');
const paths = execFileSync('rg', ['--files', 'crate', 'app/pr3-app/src-tauri/src', 'app/pr3-app/src', 'app/pr3-app/ui', 'bench/research', 'bench/documents/src'], { cwd: root, encoding: 'utf8' })
  .trim().split('\n').filter(p => /\.(rs|ts|html|css|toml)$/.test(p) || /\/tests\/fixtures\/.*\.json$/.test(p));
const sources: Record<string, string> = {};
mkdirSync(join(out, 'source-' + tag));
for (const path of [...paths, 'Cargo.lock', 'Cargo.toml', 'app/pr3-app/src-tauri/Cargo.toml', 'bench/documents/Cargo.toml']) {
  const target = join(out, 'source-' + tag, path); mkdirSync(dirname(target), { recursive: true });
  cpSync(join(root, path), target, { errorOnExist: true, force: false }); sources[path] = hash(target);
}
const binary = join(out, 'research-' + tag);
cpSync(join(root, 'target/debug/research'), binary, { errorOnExist: true, force: false });
// Tracked changes plus untracked production files, so the patch reproduces the frozen tree from HEAD.
const untracked = execFileSync('git', ['ls-files', '--others', '--exclude-standard', 'crate', 'app', 'bench/research', 'bench/documents'], { cwd: root, encoding: 'utf8' }).trim().split('\n').filter(Boolean);
let patch = execFileSync('git', ['diff', '--binary'], { cwd: root });
for (const path of untracked) {
  const added = spawnSync('git', ['diff', '--binary', '--no-index', '/dev/null', path], { cwd: root });
  patch = Buffer.concat([patch, added.stdout]);
}
const manifest = { frozenAt: new Date().toISOString(), head: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(), untracked, binary, binarySha256: hash(binary), productionSources: sources };
writeFileSync(join(out, 'build-freeze-' + tag + '.json'), JSON.stringify(manifest, null, 2) + '\n', { flag: 'wx' });
writeFileSync(join(out, 'production-' + tag + '.patch'), patch, { flag: 'wx' });
console.log(JSON.stringify({ binarySha256: manifest.binarySha256, sourceFiles: Object.keys(sources).length, untracked }));
