#!/bin/sh
# Stop the strict3 runner once its exposed matrix has finished, before the development matrix
# produces any row. The exposed review found an avoidable false positive, so a final strict4 run
# replaces the strict3 development matrix. Records what it stopped.
W=$(dirname "$0")
LOG=$W/matrices-strict3.log
until grep -q 'research-strict3-exposed-2026-11-24","finishedAt' "$LOG"; do sleep 2; done
pkill -f "$W/run-matrices.ts"
pkill -f 'bench/research/run-reliability.ts'
pkill -f "$W/research-strict3"
sleep 3
echo "stopped at $(date -u +%FT%TZ)"
ps -Ao pid=,command= | grep -E 'run-matrices|run-reliability|research-strict3' | grep -v grep || echo "no runner processes left"
D=/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/.claude/worktrees/research-strict-quality/bench/research/result/research-strict3-dev-2026-11-24
ls -la "$D" 2>/dev/null || echo "no development directory"
cat "$D"/*-seed*.jsonl 2>/dev/null | wc -l
