/** Data-entry helper ONLY for explicitly selected turns whose displayed answer is byte-identical
 * (citation identifiers removed) to an already reviewed display of the same case and turn, in this
 * run or in the 2026-11-22 archive. It copies that judgment and names its origin; it never scores
 * a new answer. MATRIX_DIR LABEL SEED '[indices]' */
import { existsSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { basename, dirname, join } from 'node:path';
const here = dirname(new URL(import.meta.url).pathname);
const [dir, label, seedText, indicesText] = process.argv.slice(2);
if (!dir || !label || !seedText || !indicesText) throw Error('MATRIX LABEL SEED INDICES required');
const seed = Number(seedText), indices = JSON.parse(indicesText) as number[];
if (!Array.isArray(indices) || !indices.length || new Set(indices).size !== indices.length) throw Error('Invalid explicit index selection');
const old = join(here.replace(/r23$/, 'r22'), basename(dir).includes('-exposed-') ? 'exposed' : 'development', 'matrix');
const display = (text: string) => text.replace(/ \[(?:research|document):[^\]\n]+\]/gu, '');
const hash = (t: { answer: string; error: unknown }) => createHash('sha256').update(JSON.stringify({ display: display(t.answer), error: t.error })).digest('hex');
const readRun = (d: string, l: string, s: number) => existsSync(join(d, `${l}-seed${s}.jsonl`)) ? readFileSync(join(d, `${l}-seed${s}.jsonl`), 'utf8').split('\n').slice(0, -1).flatMap(line => {
  const row = JSON.parse(line); return row.turns.map((value: any, turn: number) => ({ id: row.id, turn, value }));
}) : [];
type Decision = { model: string; seed: number; id: string; turn: number; pass: boolean; reason: string; borderline?: boolean };
const decisions = (d: string): Decision[] => existsSync(join(d, 'source-review.json')) ? JSON.parse(readFileSync(join(d, 'source-review.json'), 'utf8')).decisions : [];
const current = readRun(dir, label, seed);
const strip = (reason: string) => reason.replace(/^(?:Byte-identical display to [^.]*\. Same assessment: |Same reviewed display: )+/u, '');
const entries = indices.map(index => {
  const row = current[index]; if (!row || row.value.error) throw Error('Missing or failed row: ' + index);
  for (const [source, name] of [[dir, 'this run'], [dir.replace('strict4', 'strict3'), 'strict3'], [dir.replace('strict4', 'strict2'), 'strict2'], [dir.replace('strict4', 'strict1').replace('2026-11-24', '2026-11-23'), 'strict1'], [old, '2026-11-22']] as const) for (const d of decisions(source)) {
    if (d.id !== row.id || d.turn !== row.turn) continue;
    const other = readRun(source, d.model.includes('-4B-') ? '4b' : '27b', d.seed).find(r => r.id === row.id && r.turn === row.turn);
    if (!other || other.value.error || hash(other.value) !== hash(row.value)) continue;
    const [reason, borderline] = strip(d.reason).split(' Borderline: ');
    if (d.borderline && !borderline) throw Error('Missing prior borderline rationale');
    const origin = `${name === 'this run' ? 'this run' : name === '2026-11-22' ? 'the 2026-11-22 run' : `the superseded ${name} run`}, ${d.model.includes('-4B-') ? '4B' : '27B'}/seed${d.seed}`;
    return [index, d.pass, `Byte-identical display to the reviewed answer in ${origin}. Same assessment: ${reason}`, ...(d.borderline ? [borderline] : [])];
  }
  throw Error('No identical reviewed display: ' + index);
});
process.stdout.write(execFileSync(process.execPath, ['--no-warnings', join(here, 'record-review.ts'), dir, label, seedText, JSON.stringify(entries)], { encoding: 'utf8' }));
