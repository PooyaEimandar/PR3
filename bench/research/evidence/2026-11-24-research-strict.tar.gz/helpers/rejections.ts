/** Count real failed tool calls (validator rejections and other tool errors) in each run's
 * recorded traces, with the rejected conclusion. Descriptive only; it never grades answers.
 * TAG [TAG...]; PARTIAL=1 skips unfinished files for a progress view only. */
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { here, runs } from './runs.ts';
const tags = ['2026-11-22', ...process.argv.slice(2)];
const out: Record<string, unknown> = { scope: 'Failed tool-call steps recorded in the turn traces of complete matrices; each is a real rejected attempt followed by the same turn continuing within its budget, not a substituted retry.' };
for (const tag of tags) for (const [name, dir] of Object.entries(runs[tag]!)) {
  let turns = 0; const calls: unknown[] = [];
  for (const label of ['4b', '27b']) for (const seed of [1, 2, 7]) {
    const file = join(dir, `${label}-seed${seed}.jsonl`);
    if (!existsSync(file)) { if (process.env.PARTIAL) continue; throw Error('Missing ' + file); }
    for (const line of readFileSync(file, 'utf8').split('\n').slice(0, -1)) {
      const row = JSON.parse(line);
      row.turns.forEach((t: any, turn: number) => {
        turns++;
        for (const s of t.traces.flatMap((trace: { steps: any[] }) => trace.steps)) if (s.step_type === 'tool_call' && s.output?.success === false) {
          const args = s.input?.arguments ?? s.input;
          let conclusion: unknown = args?.conclusion;
          try { conclusion ??= JSON.parse(String(args)).conclusion; } catch { /* keep raw */ }
          calls.push({ model: label, seed, id: row.id, turn, tool: s.input?.tool, conclusion: conclusion ?? args, message: String(s.output?.result) });
        }
      });
    }
  }
  out[`${tag}/${name}`] = { turns, failedToolCalls: calls.length, calls };
}
if (!process.env.PARTIAL) writeFileSync(join(here, `rejections-${process.argv.slice(2).join('-')}.json`), JSON.stringify(out, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(out, null, 2));
