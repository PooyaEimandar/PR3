/** Summarize observational power/load sampling; does not infer model speed. */
import {readFileSync} from 'node:fs';
const path=process.argv[2];
if(!path)throw Error('PERFORMANCE_JSONL required');
type Sample={at:string;power:string;freeBytes:number;cpu:{model:number;compiler:number;other:number};loadavg:number[]};
const samples=readFileSync(path,'utf8').trim().split('\n').map(line=>JSON.parse(line) as Sample);
const transitions:{at:string;mode:string}[]=[],gaps:{from:string;to:string;seconds:number}[]=[];
let priorMode='',priorTime:number|undefined;
for(const sample of samples){
  const time=Date.parse(sample.at),mode=sample.power.match(/Now drawing from '([^']+)'/)?.[1];
  if(!Number.isFinite(time)||!mode||!Number.isFinite(sample.freeBytes)||Object.values(sample.cpu).some(n=>!Number.isFinite(n)))throw Error('Invalid power sample');
  if(priorTime!==undefined){
    if(time<priorTime)throw Error('Sampling clock reversed');
    if(time-priorTime>60000)gaps.push({from:new Date(priorTime).toISOString(),to:sample.at,seconds:(time-priorTime)/1000});
  }
  if(mode!==priorMode)transitions.push({at:sample.at,mode});
  priorMode=mode;priorTime=time;
}
console.log(JSON.stringify({scope:'Observational desktop sampling, no controlled speed claim. Sampling gaps do not by themselves identify sleep.',samples:samples.length,first:samples[0]?.at,last:samples.at(-1)?.at,transitions,gapsOver60Seconds:gaps,compilerActiveSamples:samples.filter(s=>s.cpu.compiler>0).length,maxOtherCpuPercent:Math.max(...samples.map(s=>s.cpu.other)),maxOneMinuteLoad:Math.max(...samples.map(s=>s.loadavg[0]!)),minFreeBytes:Math.min(...samples.map(s=>s.freeBytes))},null,2));
