/** Extract each final answer's conclusion, displayed quotations, request and run date for an
 * offline validator replay. Never grades. OUT_JSONL MATRIX_DIR... */
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join, basename } from 'node:path';
const [out, ...dirs] = process.argv.slice(2);
const lines: string[] = [];
for (const dir of dirs) {
  const corpus = JSON.parse(readFileSync(join(dir, 'corpus.json'), 'utf8')).cases;
  for (const label of ['4b', '27b']) for (const seed of [1, 2, 7]) {
    const path = join(dir, `${label}-seed${seed}.jsonl`); if (!existsSync(path)) continue;
    for (const row of readFileSync(path, 'utf8').trim().split('\n').map(l => JSON.parse(l))) {
      const test = corpus.find((c: { id: string }) => c.id === row.id);
      for (const [turn, t] of row.turns.entries()) {
        const conclusion = t.answer.split('\n').find((l: string) => l.startsWith('Conclusion: '))?.slice(12);
        if (!conclusion) continue;
        const quotes: string[] = []; let quote: string[] = [];
        for (const line of t.answer.split('\n')) {
          if (line.startsWith('> ')) quote.push(line.slice(2));
          else if (quote.length) { quotes.push(quote.join('\n')); quote = []; }
        }
        const today = new Date(t.wall_started_ms).toISOString().slice(0, 10);
        lines.push(JSON.stringify({ key: `${basename(dir)}/${label}/seed${seed}/${row.id}/${turn}`, request: turn === 0 ? test.topic : test.restart, today, conclusion, quotes }));
      }
    }
  }
}
writeFileSync(out, lines.join('\n') + '\n');
console.log(JSON.stringify({ conclusions: lines.length }));
