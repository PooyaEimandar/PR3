/** Shared run locations for the strict-quality evaluation helpers. strict3 ran its exposed matrix
 * only; its runner was stopped before the development matrix produced a row. */
import { dirname, join } from 'node:path';
export const here = dirname(new URL(import.meta.url).pathname);
export const r22 = here.replace(/r23$/, 'r22');
export const result = '/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/.claude/worktrees/research-strict-quality/bench/research/result';
export const runs: Record<string, { development?: string; exposed: string }> = {
  '2026-11-22': { development: join(r22, 'development/matrix'), exposed: join(r22, 'exposed/matrix') },
  strict1: { development: join(result, 'research-strict1-dev-2026-11-23'), exposed: join(result, 'research-strict1-exposed-2026-11-23') },
  strict2: { development: join(result, 'research-strict2-dev-2026-11-24'), exposed: join(result, 'research-strict2-exposed-2026-11-24') },
  strict3: { exposed: join(result, 'research-strict3-exposed-2026-11-24') },
  strict4: { development: join(result, 'research-strict4-dev-2026-11-24'), exposed: join(result, 'research-strict4-exposed-2026-11-24') },
};
