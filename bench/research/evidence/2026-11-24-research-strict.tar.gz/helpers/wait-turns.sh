#!/bin/sh
# Wait until at least $1 complete rows exist across both strict4 matrices, or the matrix runner stops.
R=/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/.claude/worktrees/research-strict-quality/bench/research/result
LOG=$(dirname "$0")/matrices-strict4.log
while :; do
  n=$(cat "$R"/research-strict4-*-2026-11-24/*-seed*.jsonl 2>/dev/null | wc -l | tr -d ' ')
  if [ "$n" -ge "$1" ]; then echo "rows $n"; exit 0; fi
  if grep -q -E 'Error|exited|research-strict4-dev-2026-11-24","finishedAt' "$LOG"; then echo "runner stopped at rows $n"; tail -3 "$LOG"; exit 0; fi
  sleep 20
done
