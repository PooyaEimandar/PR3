/** Extract every final conclusion and every rejected report conclusion, with the turn's displayed
 * quotations, request and run date, for an offline validator replay. A rejected attempt is paired
 * with the quotations its turn finally displayed (same case evidence), so it approximates the
 * attempt's own citations. Never grades. OUT_JSONL MATRIX_DIR... */
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { basename, join } from 'node:path';
const [out, ...dirs] = process.argv.slice(2);
if (!out || !dirs.length) throw Error('OUT_JSONL MATRIX_DIR... required');
const lines: string[] = []; let finals = 0, rejected = 0;
for (const dir of dirs) {
  const corpus = JSON.parse(readFileSync(join(dir, 'corpus.json'), 'utf8')).cases;
  for (const label of ['4b', '27b']) for (const seed of [1, 2, 7]) {
    const path = join(dir, `${label}-seed${seed}.jsonl`); if (!existsSync(path)) throw Error('Missing ' + path);
    for (const row of readFileSync(path, 'utf8').trim().split('\n').map(l => JSON.parse(l))) {
      const test = corpus.find((c: { id: string }) => c.id === row.id);
      for (const [turn, t] of row.turns.entries()) {
        const quotes: string[] = []; let quote: string[] = [];
        for (const line of `${t.answer}\n`.split('\n')) {
          if (line.startsWith('> ')) quote.push(line.slice(2));
          else if (quote.length) { quotes.push(quote.join('\n')); quote = []; }
        }
        const titles = new Set(t.answer.split('\n').filter((l: string) => l.startsWith('Source: ')).map((l: string) => l.slice(8).split(' · ')[0])).size;
        const base = { request: turn === 0 ? test.topic : test.restart, today: new Date(t.wall_started_ms).toISOString().slice(0, 10), quotes, titles };
        const key = `${basename(dir)}/${label}/seed${seed}/${row.id}/${turn}`;
        const conclusion = t.answer.split('\n').find((l: string) => l.startsWith('Conclusion: '))?.slice(12);
        if (conclusion) { lines.push(JSON.stringify({ key, kind: 'final', conclusion, ...base })); finals++; }
        for (const s of t.traces.flatMap((trace: { steps: any[] }) => trace.steps)) {
          if (s.step_type !== 'tool_call' || s.output?.success !== false || s.input?.tool !== 'answer_research') continue;
          let args = s.input?.arguments ?? s.input;
          if (typeof args === 'string') args = JSON.parse(args);
          if (typeof args?.conclusion === 'string' && args.conclusion.trim().startsWith('{')) args = JSON.parse(args.conclusion);
          if (typeof args?.conclusion !== 'string') throw Error('Unreadable rejected conclusion: ' + key);
          lines.push(JSON.stringify({ key: key + '/rejected', kind: 'rejected', conclusion: args.conclusion, ...base })); rejected++;
        }
      }
    }
  }
}
writeFileSync(out, lines.join('\n') + '\n', { flag: 'wx' });
console.log(JSON.stringify({ finals, rejected }));
