/** Compare final judgments with the 2026-11-22 review for the same case, turn, model and seed.
 * Same exposed cases and seeds; unblinded and non-independent; not a causal or significance estimate. */
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
const here = dirname(new URL(import.meta.url).pathname);
const root = '/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/.claude/worktrees/research-strict-quality/bench/research/result';
const r22 = here.replace(/r23$/, 'r22');
const out = process.argv[2] ?? join(here, 'prior-comparison.json');
type Decision = { model: string; seed: number; id: string; turn: number; pass: boolean; reason: string; borderline?: boolean };
const key = (d: Decision) => `${d.model}/${d.seed}/${d.id}/${d.turn}`;
const strict = (d: Decision) => d.pass && !d.borderline;
const result: Record<string, unknown> = { scope: 'Same exposed cases, models and seeds as 2026-11-22; unblinded implementation-assistant review. Answers and runtime references differ; not an isolated causal or significance estimate.' };
const tag = process.argv[3] ?? 'strict4';
for (const [name, folder] of [['development', `research-${tag}-dev-2026-11-24`], ['exposed', `research-${tag}-exposed-2026-11-24`]]) {
  const review = JSON.parse(readFileSync(join(root, folder!, 'source-review.json'), 'utf8')) as { complete: boolean; decisions: Decision[] };
  const prior = JSON.parse(readFileSync(join(r22, name!, 'matrix', 'source-review.json'), 'utf8')) as { decisions: Decision[] };
  if (!review.complete) throw Error('Final review incomplete: ' + name);
  const current = new Map(review.decisions.map(d => [key(d), d]));
  const priorByKey = new Map(prior.decisions.map(d => [key(d), d]));
  if (current.size !== priorByKey.size || [...current.keys()].some(k => !priorByKey.has(k))) throw Error('Denominator mismatch: ' + name);
  const shape = (d: Decision) => ({ model: d.model, seed: d.seed, id: d.id, turn: d.turn });
  result[name!] = {
    previousStrictFailures: prior.decisions.filter(d => !strict(d)).map(d => {
      const now = current.get(key(d))!;
      return { ...shape(d), previousReason: d.reason, currentPass: now.pass, currentStrict: strict(now), currentReason: now.reason };
    }),
    newStrictFailures: review.decisions.filter(d => !strict(d) && strict(priorByKey.get(key(d))!)).map(d => ({ ...shape(d), reason: d.reason, previousReason: priorByKey.get(key(d))!.reason })),
    newMainFailures: review.decisions.filter(d => !d.pass && priorByKey.get(key(d))!.pass).map(d => ({ ...shape(d), reason: d.reason })),
  };
}
writeFileSync(out, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result, null, 2));
