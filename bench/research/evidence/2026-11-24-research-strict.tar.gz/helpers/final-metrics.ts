/** Main/strict/lenient counts per run from completed source reviews, plus observational power
 * sampling. Descriptive only; never creates or changes a decision. TAG [TAG...] */
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';
import { here, runs } from './runs.ts';
type Decision = { model: string; seed: number; id: string; turn: number; pass: boolean; borderline?: boolean };
type Count = { turns: number; main: number; strict: number; lenient: number };
const tags = process.argv.slice(2);
if (!tags.length) throw Error('TAG required');
const out: Record<string, unknown> = { scope: 'Unblinded implementation-assistant review of exposed regressions; descriptive counts and observational desktop samples, not independent or controlled comparative evidence.' };
for (const tag of tags) {
  const counts: Record<string, Count> = {};
  const add = (name: string, d: Decision) => {
    const c = counts[name] ??= { turns: 0, main: 0, strict: 0, lenient: 0 };
    c.turns++; c.main += Number(d.pass); c.strict += Number(d.pass && !d.borderline); c.lenient += Number(d.pass || d.borderline === true);
  };
  for (const [name, dir] of Object.entries(runs[tag]!)) {
    const review = JSON.parse(readFileSync(join(dir, 'source-review.json'), 'utf8')) as { complete: boolean; decisions: Decision[] };
    if (!review.complete) throw Error(`Incomplete review: ${tag}/${name}`);
    for (const d of review.decisions) {
      for (const group of ['all', name, `${name}/${d.model}`, `${name}/${d.model}/seed${d.seed}`, `all/${d.model}`]) add(group, d);
      if (d.turn > 0) for (const group of ['restart', `restart/${d.model}`]) add(group, d);
    }
  }
  const expected = runs[tag]!.development ? [240, 84] : [78, 30];
  if (counts.all?.turns !== expected[0] || counts.restart?.turns !== expected[1]) throw Error('Unexpected denominator: ' + tag);
  const perf = join(here, `performance-${tag}.jsonl`);
  const power = existsSync(perf) ? JSON.parse(execFileSync(process.execPath, ['--no-warnings', join(here, 'power-summary.ts'), perf], { encoding: 'utf8' })) : null;
  out[tag] = { counts, power };
}
writeFileSync(join(here, `final-metrics-${tags.join('-')}.json`), JSON.stringify(out, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(out, null, 2));
