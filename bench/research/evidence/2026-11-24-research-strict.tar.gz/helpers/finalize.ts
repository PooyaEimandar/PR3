/** Stage, audit, archive and re-verify the final strict4 matrices, keeping the superseded strict1
 * and strict2 matrices and the exposed-only strict3 matrix separately. Never grades answers. TAG */
import { cpSync, createReadStream, existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { dirname, join } from 'node:path';
import { tmpdir } from 'node:os';
import { isDeepStrictEqual } from 'node:util';
const root = '/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/.claude/worktrees/research-strict-quality';
const work = dirname(new URL(import.meta.url).pathname), stage = join(work, 'archive'), r22 = work.replace(/r23$/, 'r22');
const dest = join(root, 'bench/research/evidence'), prefix = '2026-11-24-research-strict';
const tag = process.argv[2]; if (tag !== 'strict4') throw Error('Final frozen build tag strict4 required');
// strict3 ran its exposed matrix only: its runner was stopped before the development matrix produced a row.
const supersededRuns: Record<string, Partial<Record<'development' | 'exposed', string>>> = {
  strict1: { development: 'research-strict1-dev-2026-11-23', exposed: 'research-strict1-exposed-2026-11-23' },
  strict2: { development: 'research-strict2-dev-2026-11-24', exposed: 'research-strict2-exposed-2026-11-24' },
  strict3: { exposed: 'research-strict3-exposed-2026-11-24' },
};
const read = (p: string) => JSON.parse(readFileSync(p, 'utf8'));
const hash = (p: string) => createHash('sha256').update(readFileSync(p)).digest('hex');
const run = (dir: string, file: string, args: string[] = []) => JSON.parse(execFileSync(process.execPath, ['--no-warnings', join(dir, file), ...args], { cwd: dir, encoding: 'utf8' }));
const summaries: Record<string, unknown> = {}, controls: Record<string, unknown> = {}, inference: Record<string, unknown> = {}, inferenceControls: Record<string, unknown> = {}, plans: Record<string, unknown> = {}, planControls: Record<string, unknown> = {};
let finalManifest: any;
for (const [name, folder] of [['development', 'research-strict4-dev-2026-11-24'], ['exposed', 'research-strict4-exposed-2026-11-24']] as const) {
  const matrix = join(root, 'bench/research/result', folder), target = join(stage, name);
  const manifest = read(join(matrix, 'manifest.json')); finalManifest = manifest;
  if (!read(join(matrix, 'progress.json')).complete || !read(join(matrix, 'source-review.json')).complete) throw Error('Evaluation/review incomplete: ' + name);
  if (hash(manifest.binary) !== manifest.binarySha256) throw Error('Frozen executable changed');
  for (const [p, h] of Object.entries(manifest.productionSources)) if (hash(join(root, p)) !== h || hash(join(work, 'source-' + tag, p)) !== h) throw Error('Frozen source changed: ' + p);
  if (!existsSync(join(matrix, 'review-required.json'))) execFileSync(process.execPath, ['--no-warnings', join(root, 'bench/research/review-reliability.ts'), matrix], { cwd: root, stdio: ['ignore', 'ignore', 'inherit'] });
  cpSync(matrix, join(target, 'matrix'), { recursive: true, errorOnExist: true, force: false });
  cpSync(join(work, 'source-' + tag), join(target, 'source'), { recursive: true, errorOnExist: true, force: false });
  // The verifiers are the 2026-11-22 archive's own scripts, unchanged.
  for (const helper of ['replay.ts', 'check-replay.ts', 'audit-inference.ts', 'check-inference.ts', 'audit-plan.ts', 'check-plan.ts']) cpSync(join(r22, name, helper), join(target, helper));
  summaries[name] = run(target, 'replay.ts'); controls[name] = run(target, 'check-replay.ts');
  inference[name] = run(target, 'audit-inference.ts', [join(target, 'matrix')]); inferenceControls[name] = run(target, 'check-inference.ts', [join(target, 'matrix')]);
  plans[name] = run(target, 'audit-plan.ts', [join(target, 'matrix')]); planControls[name] = run(target, 'check-plan.ts', [join(target, 'matrix')]);
  for (const [file, value] of [['summary.json', summaries[name]], ['controls.json', controls[name]], ['inference.json', inference[name]], ['inference-controls.json', inferenceControls[name]], ['plans.json', plans[name]], ['plan-controls.json', planControls[name]]] as const) writeFileSync(join(target, file), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
}
for (const model of finalManifest.models) { const h = createHash('sha256'); for await (const part of createReadStream(model.path)) h.update(part); if (h.digest('hex') !== model.sha256) throw Error('Model changed: ' + model.name); }
const previous = join(dest, '2026-11-22-research-coverage.tar.gz');
const previousCheck = read(join(dest, '2026-11-22-research-coverage-archive-check.json'));
if (hash(previous) !== previousCheck.archiveSha256) throw Error('Prior archive changed');
for (const dir of ['verification', 'helpers', 'exploratory', 'builds']) mkdirSync(join(stage, dir), { recursive: true });
// The complete superseded matrices, reviewed and replayed with their own source overlays.
const superseded: Record<string, Record<string, unknown>> = {};
for (const [run_, matrices] of Object.entries(supersededRuns)) for (const [name, folder] of Object.entries(matrices) as [string, string][]) {
  const matrix = join(root, 'bench/research/result', folder), target = join(stage, 'superseded-' + run_, name);
  if (!read(join(matrix, 'progress.json')).complete || !read(join(matrix, 'source-review.json')).complete) throw Error('Superseded run incomplete: ' + folder);
  if (!existsSync(join(matrix, 'review-required.json'))) execFileSync(process.execPath, ['--no-warnings', join(root, 'bench/research/review-reliability.ts'), matrix], { cwd: root, stdio: ['ignore', 'ignore', 'inherit'] });
  cpSync(matrix, join(target, 'matrix'), { recursive: true, errorOnExist: true, force: false });
  cpSync(join(work, 'source-' + run_), join(target, 'source'), { recursive: true, errorOnExist: true, force: false });
  for (const helper of ['replay.ts', 'audit-inference.ts', 'audit-plan.ts']) cpSync(join(r22, name, helper), join(target, helper));
  const value = { replay: run(target, 'replay.ts'), inference: run(target, 'audit-inference.ts', [join(target, 'matrix')]), plans: run(target, 'audit-plan.ts', [join(target, 'matrix')]) };
  (superseded[run_] ??= {})[name] = value;
  writeFileSync(join(target, 'summary.json'), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
}
if (existsSync(join(work, 'exploratory'))) cpSync(join(work, 'exploratory'), join(stage, 'exploratory'), { recursive: true });
const archivedSources = new Set(['source-' + tag, ...Object.keys(supersededRuns).map(r => 'source-' + r)]);
for (const entry of readdirSync(work, { withFileTypes: true })) {
  if (entry.isDirectory() && entry.name.startsWith('source-') && !archivedSources.has(entry.name)) { cpSync(join(work, entry.name), join(stage, 'builds', entry.name), { recursive: true }); continue; }
  if (!entry.isFile()) continue;
  if (/\.(?:ts|sh)$/.test(entry.name)) cpSync(join(work, entry.name), join(stage, 'helpers', entry.name));
  else if (/^(?:build-freeze-|production-)/.test(entry.name)) cpSync(join(work, entry.name), join(stage, 'builds', entry.name));
  else if (/\.(?:json|jsonl|log)$/.test(entry.name)) cpSync(join(work, entry.name), join(stage, /^conclusions/.test(entry.name) ? 'exploratory' : 'verification', entry.name));
}
const summary = { scope: 'PR3-only exposed development and formerly fresh regressions, repeated unchanged after the strict-quality fixes. Unblinded implementation-assistant review, not independent held-out evidence or a matched OpenJarvis comparison. No failed-case retry substitution in the final matrices; the complete superseded strict1 and strict2 matrices and the exposed-only strict3 matrix are retained separately.', previousArchive: { name: '2026-11-22-research-coverage.tar.gz', sha256: previousCheck.archiveSha256 }, binarySha256: finalManifest.binarySha256, development: summaries.development, exposed: summaries.exposed, inference, plans, superseded };
writeFileSync(join(stage, 'summary.json'), JSON.stringify(summary, null, 2) + '\n', { flag: 'wx' });
const archive = join(dest, prefix + '.tar.gz'); if (existsSync(archive)) throw Error('Archive exists');
execFileSync('tar', ['-czf', archive, '-C', stage, '.'], { env: { ...process.env, COPYFILE_DISABLE: '1' } });
const extracted = mkdtempSync(join(tmpdir(), 'pr3-strict-verify-')); execFileSync('tar', ['-xzf', archive, '-C', extracted]);
for (const name of ['development', 'exposed']) {
  const dir = join(extracted, name), matrix = join(dir, 'matrix');
  if (!isDeepStrictEqual(summaries[name], run(dir, 'replay.ts')) || !isDeepStrictEqual(controls[name], run(dir, 'check-replay.ts')) || !isDeepStrictEqual(inference[name], run(dir, 'audit-inference.ts', [matrix])) || !isDeepStrictEqual(inferenceControls[name], run(dir, 'check-inference.ts', [matrix]))) throw Error('Extracted replay mismatch: ' + name);
  if (!isDeepStrictEqual(plans[name], run(dir, 'audit-plan.ts', [matrix])) || !isDeepStrictEqual(planControls[name], run(dir, 'check-plan.ts', [matrix]))) throw Error('Extracted plan replay mismatch: ' + name);
  for (const [run_, matrices] of Object.entries(supersededRuns)) {
    if (!(name in matrices)) continue;
    const old = join(extracted, 'superseded-' + run_, name);
    if (!isDeepStrictEqual(superseded[run_]![name], { replay: run(old, 'replay.ts'), inference: run(old, 'audit-inference.ts', [join(old, 'matrix')]), plans: run(old, 'audit-plan.ts', [join(old, 'matrix')]) })) throw Error(`Extracted superseded replay mismatch: ${run_}/${name}`);
  }
}
const verification = { verifiedAt: new Date().toISOString(), archiveSha256: hash(archive), binarySha256: finalManifest.binarySha256, currentSourcesMatchFrozenManifest: true, frozenExecutableMatchesManifest: true, modelFilesMatchManifest: true, extractedReplaysMatch: true, extractedSupersededReplaysMatch: true, previousArchiveVerified: true, controls, inferenceControls, planControls };
writeFileSync(join(dest, prefix + '-summary.json'), JSON.stringify(summary, null, 2) + '\n', { flag: 'wx' });
writeFileSync(join(dest, prefix + '-archive-check.json'), JSON.stringify(verification, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ archive, archiveSha256: verification.archiveSha256 }, null, 2));
