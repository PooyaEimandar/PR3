/** List up to N unreviewed complete turns. A turn whose displayed answer is byte-identical to an
 * already reviewed display of the same case and turn (this run or 2026-11-22) is listed by
 * reference only, with that decision. This never grades answers. */
import { existsSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join, dirname } from 'node:path';
const here = dirname(new URL(import.meta.url).pathname);
const root = '/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/.claude/worktrees/research-strict-quality/bench/research/result';
const r22 = here.replace(/r23$/, 'r22');
const limit = Number(process.argv[2] ?? 6);
const only = process.argv[3];
const matrices: [string, string][] = [['research-strict4-exposed-2026-11-24', 'exposed'], ['research-strict4-dev-2026-11-24', 'development']];
const display = (text: string) => text.replace(/ \[(?:research|document):[^\]\n]+\]/gu, '');
const key = (id: string, turn: number, t: { answer: string; error: unknown }) => `${id}/${turn}/` + createHash('sha256').update(JSON.stringify({ display: display(t.answer), error: t.error })).digest('hex');
type Decision = { model: string; seed: number; id: string; turn: number; pass: boolean; reason: string; borderline?: boolean };
const rows = (dir: string) => {
  const out: { label: string; seed: number; index: number; id: string; turn: number; t: any }[] = [];
  for (const label of ['4b', '27b']) for (const seed of [1, 2, 7]) {
    const path = join(dir, `${label}-seed${seed}.jsonl`);
    if (!existsSync(path)) continue;
    let index = 0;
    for (const line of readFileSync(path, 'utf8').split('\n').slice(0, -1)) {
      const row = JSON.parse(line);
      for (const [turn, t] of row.turns.entries()) out.push({ label, seed, index: index++, id: row.id, turn, t });
    }
  }
  return out;
};
const decisionsOf = (dir: string): Decision[] => existsSync(join(dir, 'source-review.json')) ? JSON.parse(readFileSync(join(dir, 'source-review.json'), 'utf8')).decisions : [];
const find = (ds: Decision[], label: string, seed: number, id: string, turn: number) => ds.find(d => d.model.includes(label === '4b' ? '-4B-' : '-27B-') && d.seed === seed && d.id === id && d.turn === turn);
let emitted = 0;
for (const [name, old] of matrices) {
  if (only && only !== name) continue;
  const dir = join(root, name);
  if (!existsSync(join(dir, 'corpus.json'))) continue;
  const corpus = JSON.parse(readFileSync(join(dir, 'corpus.json'), 'utf8')).cases;
  const reviewed = new Map<string, string>();
  const oldDir = join(r22, old, 'matrix'), oldDecisions = decisionsOf(oldDir);
  for (const r of rows(oldDir)) { const d = find(oldDecisions, r.label, r.seed, r.id, r.turn); if (d) reviewed.set(key(r.id, r.turn, r.t), `2026-11-22 ${r.label}/seed${r.seed}: ${d.pass ? 'PASS' : 'FAIL'}${d.borderline ? ' (borderline)' : ''} — ${d.reason}`); }
  for (const [tag, date] of [['strict1', '2026-11-23'], ['strict2', '2026-11-24'], ['strict3', '2026-11-24']]) {
    const priorDir = join(root, name.replace('strict4', tag!).replace('2026-11-24', date!)), priorDecisions = decisionsOf(priorDir);
    for (const r of rows(priorDir)) { const d = find(priorDecisions, r.label, r.seed, r.id, r.turn); if (d) reviewed.set(key(r.id, r.turn, r.t), `${tag} ${r.label}/seed${r.seed}: ${d.pass ? 'PASS' : 'FAIL'}${d.borderline ? ' (borderline)' : ''} — ${d.reason}`); }
  }
  const current = rows(dir), decisions = decisionsOf(dir);
  for (const r of current) { const d = find(decisions, r.label, r.seed, r.id, r.turn); if (d) reviewed.set(key(r.id, r.turn, r.t), `this run ${r.label}/seed${r.seed}: ${d.pass ? 'PASS' : 'FAIL'}${d.borderline ? ' (borderline)' : ''} — ${d.reason}`); }
  for (const r of current) {
    if (find(decisions, r.label, r.seed, r.id, r.turn) || emitted >= limit) continue;
    emitted++;
    const test = corpus.find((c: { id: string }) => c.id === r.id);
    const same = reviewed.get(key(r.id, r.turn, r.t));
    const head = { matrix: name, label: r.label, seed: r.seed, index: r.index, id: r.id, turn: r.turn, seconds: r.t.seconds, diagnosticPass: r.t.pass, error: r.t.error };
    if (same) { console.log(JSON.stringify({ ...head, identicalTo: same })); continue; }
    const rejections = r.t.traces.flatMap((trace: { steps: any[] }) => trace.steps).filter((s: any) => s.step_type === 'tool_call' && s.output?.success === false).map((s: any) => `${s.input?.tool}: ${String(s.output?.result).slice(0, 240)}`);
    console.log(JSON.stringify({ ...head, request: r.turn === 0 ? test.topic : test.restart, rubric: (r.turn === 0 ? test.review : test.restart_review ?? test.review)?.rubric, rejections }));
    console.log(display(r.t.answer).replace('Research findings\n\nThe analysis below is model-generated. The attached quotations are checked against saved sources.\n\n', '').replace(/\nSource: ([^\n]*?) · (https?:\/\/[^\s]+|[^\n·]+) · [^\n]*/gu, '\n— $1'));
    console.log('-----');
  }
}
if (!emitted) console.log('No unreviewed complete turn.');
