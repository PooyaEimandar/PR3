import {cpSync,mkdtempSync,readFileSync,rmSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath} from 'node:url';
const here=fileURLToPath(new URL('.',import.meta.url));
const original=process.argv[2];if(!original)throw Error('MATRIX required');
const scratch=mkdtempSync(join(tmpdir(),'pr3-plan-controls-')),matrix=join(scratch,'matrix');
const run=()=>spawnSync(process.execPath,[join(here,'audit-plan.ts'),matrix],{encoding:'utf8'});
const results:{control:string;pass:boolean}[]=[];
const report=(rows:any[])=>{
 for(const row of rows)for(const turn of row.turns){
  const generations=turn.traces.flatMap(t=>t.steps).filter(s=>s.step_type==='generate'&&s.output.prompt_tokens>0);
  for(const [index,step]of generations.entries()){
   const call=step.output.tool_calls?.find(c=>c.name==='answer_research'&&JSON.parse(c.arguments).findings?.some(f=>f.citations?.some(c=>c.quote_ref)));
   const evidence=turn.inference_evidence[index];
   if(call&&evidence?.source_views.length)return {turn,call,evidence};
  }
 }
 throw Error('Missing planned report');
};
function check(control:string,change:(rows:any[])=>void,expected:string){
 rmSync(matrix,{recursive:true,force:true});cpSync(original!,matrix,{recursive:true});
 const path=join(matrix,'4b-seed1.jsonl');const rows=readFileSync(path,'utf8').trim().split('\n').map(line=>JSON.parse(line));
 change(rows);writeFileSync(path,rows.map(row=>JSON.stringify(row)).join('\n')+'\n');
 const result=run();
 const pass=expected==='omission'?result.status===0&&JSON.parse(result.stdout).omissions.length>0:result.status!==0&&result.stderr.includes(expected);
 results.push({control,pass});if(!pass)throw Error(control+': '+result.stderr);
}
try{
 cpSync(original,matrix,{recursive:true});const valid=run();if(valid.status!==0)throw Error(valid.stderr);
 const summary=JSON.parse(valid.stdout);if(!summary.plannedReports||summary.omissions.length)throw Error('Unexpected unaltered plan audit');
 results.push({control:'unaltered plans and actual report citations match',pass:true});
 check('omitted planned citation is measured',rows=>{const {call}=report(rows),args=JSON.parse(call.arguments);args.findings=[];call.arguments=JSON.stringify(args);},'omission');
 check('foreign planned reference rejected',rows=>{const {evidence}=report(rows),view=JSON.parse(evidence.source_views[0]);view.coverage=['q:foreign'];evidence.source_views[0]=JSON.stringify(view);},'Plan cites an unfitted reference');
 check('duplicated planned reference rejected',rows=>{const {evidence}=report(rows),view=JSON.parse(evidence.source_views[0]);view.coverage.push(view.coverage[0]);evidence.source_views[0]=JSON.stringify(view);},'Invalid coverage plan');
 check('missing inference alignment rejected',rows=>{report(rows).turn.inference_evidence.pop();},'Inference alignment mismatch');
 console.log(JSON.stringify({controls:results},null,2));
}finally{rmSync(scratch,{recursive:true,force:true});}
