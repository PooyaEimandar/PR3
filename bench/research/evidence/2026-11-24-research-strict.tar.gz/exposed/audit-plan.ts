/** Observe plan use in actual generations; does not grade answer meaning. */
import {readFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
const dir=resolve(process.argv[2]??'');if(!process.argv[2])throw Error('MATRIX required');
const read=(name:string)=>JSON.parse(readFileSync(resolve(dir,name),'utf8'));
const manifest=read('manifest.json'),partial=process.argv[3]==='--partial';
const progress=existsSync(resolve(dir,'progress.json'))?read('progress.json'):{complete:false,runs:[]};
if(!progress.complete&&!partial)throw Error('Matrix incomplete');
const runs=partial?manifest.models.flatMap(model=>manifest.seeds.map(seed=>({model:model.name,seed,file:`${model.name.includes('-4B-')?'4b':'27b'}-seed${seed}.jsonl`}))).filter(run=>existsSync(resolve(dir,run.file))):progress.runs;
let turns=0,plannedReports=0,plannedCitations=0,unplannedReports=0;
const omissions:unknown[]=[];
for(const run of runs)for(const line of readFileSync(resolve(dir,run.file),'utf8').split('\n').slice(0,-1)){
 const row=JSON.parse(line);
 for(const [index,turn]of row.turns.entries()){
  turns++;
  const generations=turn.traces.flatMap(trace=>trace.steps).filter(step=>step.step_type==='generate'&&step.output.prompt_tokens>0);
  if(generations.length!==turn.inference_evidence.length)throw Error('Inference alignment mismatch');
  for(const [pass,step]of generations.entries()){
   const views=turn.inference_evidence[pass].source_views.map(raw=>JSON.parse(raw));
   for(const view of views)if(view.coverage!==undefined&&(!Array.isArray(view.coverage)||view.coverage.length>8||new Set(view.coverage).size!==view.coverage.length))throw Error('Invalid coverage plan');
   const offered=new Map(views.flatMap(v=>v.sources??[]).flatMap(s=>(s.quotes??[]).map(q=>[q.quote_ref,q])));
   const required=[...new Set(views.flatMap(v=>v.coverage??[]))];
   for(const call of step.output.tool_calls??[]){
    if(call.name!=='answer_research')continue;
    const args=JSON.parse(call.arguments);
    const citations=(args.findings??[]).flatMap(f=>f.citations??[]);
    if(citations.some(c=>typeof c.quote==='string')||!required.length){unplannedReports++;continue;}
    plannedReports++;plannedCitations+=required.length;
    for(const reference of required){
     if(!offered.has(reference))throw Error('Plan cites an unfitted reference');
     if(!citations.some(c=>c.quote_ref===reference))omissions.push({model:run.model,seed:run.seed,id:row.id,turn:index,pass,reference});
    }
   }
  }
 }
}
if(!partial&&turns!==manifest.expectedTurns)throw Error('Wrong turn count');
console.log(JSON.stringify({scope:partial?'Partial progress audit, not a completed evaluation':'Complete matrix plan audit',turns,plannedReports,plannedCitations,unplannedReports,omissions},null,2));
