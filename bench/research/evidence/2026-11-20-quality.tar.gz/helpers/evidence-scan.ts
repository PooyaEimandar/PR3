import { readFileSync } from 'node:fs';
const [file,id,term,turn='0']=process.argv.slice(2);
if(!file||!id||!term)throw Error('JSONL CASE_ID LITERAL [TURN]');
const row=readFileSync(file,'utf8').trim().split('\n').map(line=>JSON.parse(line)).find(row=>row.id===id);
if(!row)throw Error('Case unavailable');
let hits=0;
for(const source of row.turns[Number(turn)].evidence.sources) {
  const lower=source.text.toLowerCase(), windows:string[]=[];
  let from=0;
  while(windows.length<3) {
    const at=lower.indexOf(term.toLowerCase(),from);
    if(at<0)break;
    windows.push(source.text.slice(Math.max(0,at-240),at+600));from=at+term.length;hits++;
  }
  if(windows.length)console.log(JSON.stringify({source:source.source,location:source.location,windows}));
}
console.log(JSON.stringify({term,hits,savedSources:row.turns[Number(turn)].evidence.sources.length}));
