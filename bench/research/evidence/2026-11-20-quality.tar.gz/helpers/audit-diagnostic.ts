import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
const root='/private/tmp/pr3-research-quality-2026-11-20';
const file=join(root,'authority-v3-review.json'), original=readFileSync(file);
const review=JSON.parse(original.toString());
let uiFailedCalls=0, traceRejectedCalls=0;
const inputs:Record<string,string>={};
for(const seed of [1,2,7]) {
  const name=`authority-v3-4b-seed${seed}.jsonl`, bytes=readFileSync(join(root,name));
  inputs[name]=createHash('sha256').update(bytes).digest('hex');
  for(const row of bytes.toString().trim().split('\n').map(line=>JSON.parse(line)))for(const turn of row.turns) {
    uiFailedCalls+=turn.events.filter((e:{name?:string;success?:boolean})=>e.name&&e.success===false).length;
    traceRejectedCalls+=turn.traces.flatMap((t:{steps:{step_type:string;output?:{success?:boolean}}[]})=>t.steps).filter((s:{step_type:string;output?:{success?:boolean}})=>s.step_type==='tool_call'&&s.output?.success===false).length;
  }
}
writeFileSync(join(root,'authority-v3-review-original.json'),original,{flag:'wx'});
writeFileSync(file,JSON.stringify({...review,rejectedCalls:traceRejectedCalls,uiFailedCalls,traceRejectedCalls,traceAuditInputs:inputs,
  correction:'Original rejectedCalls=0 counted only UI tool events. Core traces reveal two missing-gaps schema rejections, one each in seeds 1 and 2, repaired within the existing limit. All six final-answer judgments remain unchanged. Original review is preserved alongside this correction.'},null,2)+'\n');
console.log(JSON.stringify({uiFailedCalls,traceRejectedCalls}));
