import { readFileSync } from 'node:fs';
import { join } from 'node:path';
const [dir,label,seed,start='0',count='6']=process.argv.slice(2);
if(!dir||!label||!seed)throw Error('MATRIX LABEL SEED START COUNT');
const corpus=JSON.parse(readFileSync(join(dir,'corpus.json'),'utf8')).cases;
let turnNumber=0;
for(const line of readFileSync(join(dir,`${label}-seed${seed}.jsonl`),'utf8').split('\n').slice(0,-1)) {
  const row=JSON.parse(line),test=corpus.find((c:{id:string})=>c.id===row.id);
  for(const [i,t] of row.turns.entries()) {
    const index=turnNumber++;
    if(index<Number(start)||index>=Number(start)+Number(count))continue;
    console.log(JSON.stringify({index,id:row.id,turn:i,request:i===0?test.topic:test.restart,
      rubric:(i===0?test.review:test.restart_review??test.review)?.rubric,
      expectedQuotes:i===0?test.quotes:test.restart_checks?.quotes,
      answer:t.answer.replace(/ \[(?:research|document):[^\]\n]+\]/gu,''),
      error:t.error,diagnosticPass:t.pass,seconds:t.seconds,
      failedCalls:t.events.filter((e:{success?:boolean})=>e.success===false)}));
  }
}
