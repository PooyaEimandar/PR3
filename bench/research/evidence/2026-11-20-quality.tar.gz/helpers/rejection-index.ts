import { readFileSync, readdirSync, statSync } from 'node:fs';
import { basename, dirname, join } from 'node:path';
type Step={step_type:string;input?:{tool?:string};output?:{success?:boolean;result?:string}};
const input=process.argv[2], only=process.argv[3];
if(!input)throw Error('MATRIX_OR_JSONL [CASE_ID]');
const single=statSync(input).isFile(), dir=single?dirname(input):input;
const records:unknown[]=[];
for(const file of (single?[basename(input)]:readdirSync(dir).filter(name=>/^(4b|27b)-seed[127]\.jsonl$/.test(name))).sort()) {
  for(const line of readFileSync(join(dir,file),'utf8').split('\n').slice(0,-1)) {
    const row=JSON.parse(line);
    if(only&&row.id!==only)continue;
    for(const [turn,t]of row.turns.entries()) {
      const rejected=t.traces.flatMap((trace:{steps:Step[]})=>trace.steps).filter((s:Step)=>s.step_type==='tool_call'&&s.output?.success===false).map((s:Step)=>({tool:s.input?.tool,error:s.output?.result}));
      if(only||rejected.length)records.push({file,id:row.id,turn,seconds:t.seconds,diagnosticPass:t.pass,error:t.error,rejected});
    }
  }
}
console.log(JSON.stringify(records,null,2));
