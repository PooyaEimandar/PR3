import { readFileSync } from 'node:fs';
const [file,id]=process.argv.slice(2);
if(!file||!id)throw Error('JSONL CASE_ID');
const row=readFileSync(file,'utf8').trim().split('\n').map(line=>JSON.parse(line)).find(row=>row.id===id);
const samples=readFileSync('/private/tmp/pr3-research-quality-2026-11-20/load.jsonl','utf8').trim().split('\n').map(line=>JSON.parse(line));
for(const [index,turn]of row.turns.entries()) {
  const steps=turn.traces.flatMap((t:{steps:unknown[]})=>t.steps);
  const start=Math.min(...steps.map((s:{at:number})=>s.at)),end=Math.max(...steps.map((s:{at:number})=>s.at));
  const load=samples.filter(s=>Date.parse(s.at)>=start-60000&&Date.parse(s.at)<=end+60000);
  console.log(JSON.stringify({index,seconds:turn.seconds,start:new Date(start).toISOString(),end:new Date(end).toISOString(),
    generations:steps.filter((s:{step_type:string})=>s.step_type==='generate').map((s:{duration_ms:number;output:{prompt_tokens:number;completion_tokens:number;tool_calls?:unknown[]}})=>({ms:s.duration_ms,prompt:s.output.prompt_tokens,completion:s.output.completion_tokens,calls:s.output.tool_calls?.length??0})),
    samples:load.map(s=>({at:s.at,load:s.load,power:s.power,thermal:s.thermal,freeMemory:s.freeMemory,top:s.top.map((p:{cpu:number;process:string})=>({cpu:p.cpu,category:p.process.includes('research-frozen')?'model':/(?:rustc|cargo|clang|cmake|ninja|ld)$/.test(p.process)?'compiler':'other'}))}))
  },null,2));
}
