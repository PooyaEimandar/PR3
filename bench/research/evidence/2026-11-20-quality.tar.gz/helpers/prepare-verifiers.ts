import { readFileSync, writeFileSync, cpSync } from 'node:fs';
import { join } from 'node:path';
const work='/private/tmp/pr3-research-quality-2026-11-20/archive';
for(const name of ['development','generalization']) {
  const file=join(work,name,'replay.ts');
  let text=readFileSync(file,'utf8');
  text=text.replace('seconds:number[]};','placeholderGaps:number;seconds:number[]};');
  text=text.replace('maxToolCalls:0,seconds:[]','maxToolCalls:0,placeholderGaps:0,seconds:[]');
  text=text.replace('g.verifiedQuotations+=verified;',`g.placeholderGaps+=Number(turn.answer.split('\\n').some(line=>{
        if(!line.startsWith('Unresolved questions:'))return false;
        const gap=line.slice('Unresolved questions:'.length).trim();
        return gap==='/gaps'||gap==='</gaps>'||/^[\\s\\[\\]{}"']*$/.test(gap);
      }));
      g.verifiedQuotations+=verified;`);
  if(name==='generalization')text=text.replace('Exposed development cases, not held-out or a current OpenJarvis comparison.', 'Fresh frozen assistant-authored generalization cases, not independent held-out evidence or a current OpenJarvis comparison. No tuning against these outputs.');
  writeFileSync(file,text);
}
// The fresh set has no old late-page fixture. Retain the other nine controls.
const old=join(work,'development','check-replay.ts');
let control=readFileSync(old,'utf8').split('\n').filter(line=>!line.includes("check('missing late-page fact rejected'")).join('\n');
writeFileSync(join(work,'generalization','check-replay.ts'),control,{flag:'wx'});
