import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/research/result/generalization-2026-11-20';
const checks=[
  ['4b-seed1.jsonl','fresh-python-zip','Unlike the default behavior, it raises a ValueError'],
  ['4b-seed1.jsonl','fresh-git-diff','Make the program exit with codes similar to diff(1)'],
  ['4b-seed7.jsonl','fresh-cargo-features','dep:ravif'],
  ['27b-seed1.jsonl','fresh-python-zip','Unlike the default behavior, it raises a ValueError'],
  ['27b-seed1.jsonl','fresh-git-diff','Make the program exit with codes similar to diff(1)'],
];
const findings=checks.map(([file,id,term])=>{
  const bytes=readFileSync(`${root}/${file}`,'utf8');
  const row=bytes.trim().split('\n').map(line=>JSON.parse(line)).find(r=>r.id===id);
  if(!row)throw Error(`Missing ${id}`);
  const sources=row.turns[0].evidence.sources.flatMap((s:{source:string;text:string;location:string})=>{
    const at=s.text.indexOf(term!);return at<0?[]:[{source:s.source,location:s.location,textSha256:createHash('sha256').update(s.text).digest('hex'),excerpt:s.text.slice(Math.max(0,at-200),at+600)}];
  });
  if(!sources.length)throw Error(`Required saved evidence not found: ${file}/${id}`);
  return {file,id,term,sources};
});
writeFileSync('/private/tmp/pr3-research-quality-2026-11-20/capture-audit.json',JSON.stringify({scope:'Targeted saved-snapshot availability audit. Does not prove which excerpts survived inference-context trimming or establish a single root cause.',findings},null,2)+'\n',{flag:'wx'});
