import { readFileSync } from 'node:fs';
const [file,id]=process.argv.slice(2);
if(!file||!id)throw Error('JSONL CASE_ID');
const row=readFileSync(file,'utf8').trim().split('\n').map(line=>JSON.parse(line)).find(row=>row.id===id);
if(!row)throw Error('Case unavailable');
for(const [index,turn]of row.turns.entries())console.log(JSON.stringify({index,seconds:turn.seconds,
  events:turn.events.map((e:{name?:string;success?:boolean;type?:string})=>({name:e.name,success:e.success,type:e.type})),
  steps:turn.traces.flatMap((t:{steps:unknown[]})=>t.steps).map((s:{step_type:string;duration_ms?:number;input?:unknown;output?:unknown})=>s.step_type==='generate'?{step_type:s.step_type,duration_ms:s.duration_ms}:s)
}));
