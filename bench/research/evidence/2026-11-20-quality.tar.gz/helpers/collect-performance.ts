import { execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
const root='/private/tmp/pr3-research-quality-2026-11-20';
for(const helper of ['clock-audit','load-gaps']) {
  writeFileSync(`${root}/${helper}.jsonl`,execFileSync(process.execPath,['--no-warnings',`${root}/${helper}.ts`],{encoding:'utf8'}),{flag:'wx'});
}
const log=execFileSync('pmset',['-g','log'],{encoding:'utf8',maxBuffer:64*1024*1024});
const lines=log.split('\n').filter(line=>/^2026-11-20 [0-9:]+ [+-][0-9]{4}\s+(?:Sleep|Wake|DarkWake)\s{2,}/.test(line));
writeFileSync(`${root}/power-final.log`,lines.join('\n')+'\n',{flag:'wx'});
