import { cpSync, createReadStream, existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { isDeepStrictEqual } from 'node:util';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const work='/private/tmp/pr3-research-quality-2026-11-20', stage=join(work,'archive');
const dest=join(root,'bench/research/evidence'), prefix='2026-11-20-quality';
const read=(p:string)=>JSON.parse(readFileSync(p,'utf8'));
const hash=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const run=(dir:string,file:string)=>JSON.parse(execFileSync(process.execPath,[join(dir,file)],{cwd:dir,encoding:'utf8'}));
const summaries:Record<string,unknown>={}, controls:Record<string,unknown>={};
for(const [name,folder]of [['development','quality-2026-11-20-final'],['generalization','generalization-2026-11-20']]){
  const matrix=join(root,'bench/research/result',folder!),target=join(stage,name!);
  const manifest=read(join(matrix,'manifest.json'));
  if(!read(join(matrix,'progress.json')).complete||!read(join(matrix,'source-review.json')).complete)throw Error('Evaluation/review incomplete: '+name);
  if(hash(manifest.binary)!==manifest.binarySha256)throw Error('Frozen executable changed');
  for(const[p,h]of Object.entries(manifest.productionSources))if(hash(join(root,p))!==h||hash(join(work,'source-v3',p))!==h)throw Error('Frozen source changed: '+p);
  if(!existsSync(join(matrix,'review-required.json')))execFileSync(process.execPath,[join(root,'bench/research/review-reliability.ts'),matrix],{cwd:root,stdio:['ignore','ignore','inherit']});
  cpSync(matrix,join(target,'matrix'),{recursive:true,errorOnExist:true,force:false});
  cpSync(join(work,'source-v3'),join(target,'source'),{recursive:true,errorOnExist:true,force:false});
  cpSync(join(work,name==='development'?'matrix.log':'generalization.log'),join(target,'matrix','coordinator.log'));
  summaries[name!]=run(target,'replay.ts');controls[name!]=run(target,'check-replay.ts');
  writeFileSync(join(target,'summary.json'),JSON.stringify(summaries[name!],null,2)+'\n',{flag:'wx'});
  writeFileSync(join(target,'controls.json'),JSON.stringify(controls[name!],null,2)+'\n',{flag:'wx'});
}
const manifest=read(join(root,'bench/research/result/quality-2026-11-20-final/manifest.json'));
for(const model of manifest.models){const h=createHash('sha256');for await(const part of createReadStream(model.path))h.update(part);if(h.digest('hex')!==model.sha256)throw Error('Model changed: '+model.name);}
for(const [name,overlay]of [['candidate1','source'],['candidate2','source-v2']]) {
  const target=join(stage,'candidates',name!),matrix=join(root,'bench/research/result','quality-2026-11-20-'+name);
  mkdirSync(target,{recursive:true});cpSync(matrix,join(target,'matrix'),{recursive:true});cpSync(join(work,overlay!),join(target,'source'),{recursive:true});
  cpSync(join(work,'matrix-'+name+'.log'),join(target,'matrix','coordinator.log'));
  const m=read(join(matrix,'manifest.json'));
  for(const[p,h]of Object.entries(m.productionSources))if(hash(join(target,'source',p))!==h)throw Error('Candidate source mismatch');
  if(hash(m.binary)!==m.binarySha256||hash(join(matrix,'corpus.json'))!==m.corpusSha256)throw Error('Candidate input changed');
}
execFileSync(process.execPath,['--no-warnings',join(work,'collect-performance.ts')],{stdio:['ignore','ignore','inherit']});
for(const name of ['verification','exploratory','helpers'])mkdirSync(join(stage,name),{recursive:true});
for(const entry of readdirSync(work,{withFileTypes:true})) {
  if(!entry.isFile())continue;
  if(entry.name==='load.jsonl'||entry.name==='matrix.log'||entry.name==='generalization.log')continue;
  if(/\.ts$/.test(entry.name))cpSync(join(work,entry.name),join(stage,'helpers',entry.name));
  else if(/\.(?:json|jsonl|log|patch)$/.test(entry.name)){
    const verification=/^(?:workspace-v3|clippy-v3|tokenizer-v3|e2e-build-v3|e2e-v3|e2e-v3-unlocked|typescript)\.log$/.test(entry.name);
    cpSync(join(work,entry.name),join(stage,verification?'verification':'exploratory',entry.name));
  }
}
cpSync(join(work,'fresh-input'),join(stage,'fresh-input'),{recursive:true});
cpSync(join(work,'e2e-locked'),join(stage,'verification','locked-desktop'),{recursive:true});
// Preserve measured load without publishing unrelated process names or paths.
const samples=readFileSync(join(work,'load.jsonl'),'utf8').trim().split('\n').map(line=>{
  const row=JSON.parse(line);row.top=row.top.map((p:{cpu:number;process:string})=>({cpu:p.cpu,category:p.process.includes('research-frozen')?'model':/(?:rustc|cargo|clang|cmake|ninja|ld)$/.test(p.process)?'compiler':'other'}));return row;
});
writeFileSync(join(stage,'verification','load-sanitized.jsonl'),samples.map(s=>JSON.stringify(s)).join('\n')+'\n',{flag:'wx'});
const summary={scope:'PR3-only evaluation. Separate exposed development and fresh frozen assistant-authored generalization sets; unblinded source review, not independent held-out evidence. No fresh-set tuning or retry substitution.',binarySha256:manifest.binarySha256,development:summaries.development,generalization:summaries.generalization};
writeFileSync(join(stage,'summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
const archive=join(dest,prefix+'.tar.gz');if(existsSync(archive))throw Error('Archive exists');
execFileSync('tar',['-czf',archive,'-C',stage,'.'],{env:{...process.env,COPYFILE_DISABLE:'1'}});
const extracted=mkdtempSync(join(tmpdir(),'pr3-quality-verify-'));execFileSync('tar',['-xzf',archive,'-C',extracted]);
for(const name of ['development','generalization']) {
  if(!isDeepStrictEqual(summaries[name],run(join(extracted,name),'replay.ts'))||!isDeepStrictEqual(controls[name],run(join(extracted,name),'check-replay.ts')))throw Error('Extracted replay mismatch: '+name);
}
const verification={verifiedAt:new Date().toISOString(),archiveSha256:hash(archive),binarySha256:manifest.binarySha256,currentSourcesMatchFrozenManifest:true,frozenExecutableMatchesManifest:true,modelFilesMatchManifest:true,extractedReplaysMatch:true,controls};
writeFileSync(join(dest,prefix+'-summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
writeFileSync(join(dest,prefix+'-archive-check.json'),JSON.stringify(verification,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({archive,archiveSha256:verification.archiveSha256},null,2));
