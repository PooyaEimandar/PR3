import { readFileSync } from 'node:fs';
const [file,id]=process.argv.slice(2);
if(!file||!id)throw Error('JSONL CASE_ID');
const row=readFileSync(file,'utf8').trim().split('\n').map(line=>JSON.parse(line)).find(r=>r.id===id);
if(!row)throw Error('Case missing');
for(const [turn,t]of row.turns.entries())for(const step of t.traces.flatMap((t:{steps:unknown[]})=>t.steps)) {
  if(step.step_type!=='generate')continue;
  console.log(JSON.stringify({turn,inputKeys:Object.keys(step.input??{}),inputSizes:Object.fromEntries(Object.entries(step.input??{}).map(([k,v])=>[k,JSON.stringify(v).length])),promptTokens:step.output?.prompt_tokens,completionTokens:step.output?.completion_tokens}));
}
