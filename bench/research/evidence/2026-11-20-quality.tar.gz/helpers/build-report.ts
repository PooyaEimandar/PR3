import { readFileSync, writeFileSync } from 'node:fs';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const work='/private/tmp/pr3-research-quality-2026-11-20';
const evidence=`${root}/bench/research/evidence`;
const prefix='2026-11-20-quality';
const summary=JSON.parse(readFileSync(`${evidence}/${prefix}-summary.json`,'utf8'));
const verified=JSON.parse(readFileSync(`${evidence}/${prefix}-archive-check.json`,'utf8'));
const models=['Qwen3.5-4B-Q4_K_M.gguf','Qwen3.8-27B-Q4_K_M.gguf'];
const labels=['4B','27B'];
const tables:string[]=[];
for(const name of ['development','generalization']) {
  const result=summary[name];
  tables.push(`### ${name==='development'?'Exposed development replay':'Fresh frozen generalization'}\n\n| Model | Main rubric | Stricter review | Lenient review | Automatic diagnostics | Validated reports | Rejected plans/calls (core trace) |\n|---|---:|---:|---:|---:|---:|---:|`);
  for(const [i,model]of models.entries()) {
    const g=result.groups[`${model}/all`];
    tables.push(`| ${labels[i]} | ${g.sourceReviewedPass}/${g.turns} | ${g.strictSourceReviewedPass}/${g.turns} | ${g.lenientSourceReviewedPass}/${g.turns} | ${g.diagnosticPass}/${g.turns} | ${g.validatedReports}/${g.turns} | ${g.traceRejectedCalls} |`);
  }
  tables.push(`\nAll ${result.turns} final answers were reviewed. ${result.unchangedRestartSnapshots} restart snapshots were unchanged; ${result.nonemptyRestartSnapshots} contained saved sources. Displayed quotations verified against saved bytes: ${models.reduce((n,m)=>n+result.groups[`${m}/all`].verifiedQuotations,0)}. Resumed retrieval turns: ${models.reduce((n,m)=>n+result.groups[`${m}/all`].restartRetrievalTurns,0)}. Exact empty/tag/delimiter gaps placeholders: ${models.reduce((n,m)=>n+result.groups[`${m}/all`].placeholderGaps,0)}. This last measure does not cover prose such as “None” or misleading unresolved-question text.\n`);
  tables.push('| Case / turn | 4B main rubric | 27B main rubric |\n|---|---:|---:|');
  for(const key of Object.keys(result.caseScores).filter(k=>k.startsWith(models[0]+'/'))) {
    const suffix=key.slice(models[0]!.length+1),a=result.caseScores[key],b=result.caseScores[`${models[1]}/${suffix}`];
    tables.push(`| ${suffix} | ${a.sourceReviewedPass}/${a.turns} | ${b.sourceReviewedPass}/${b.turns} |`);
  }
  tables.push('');
}
const times=['| Set / model | Median seconds | p95 seconds | Maximum seconds |','|---|---:|---:|---:|'];
for(const name of ['development','generalization'])for(const[i,model]of models.entries()) {
  const g=summary[name].groups[`${model}/all`];
  times.push(`| ${name} / ${labels[i]} | ${g.medianSeconds.toFixed(2)} | ${g.p95Seconds.toFixed(2)} | ${g.maxSeconds.toFixed(2)} |`);
}
let methods=readFileSync(`${work}/report-methods.md`,'utf8');
methods=methods.replace('# Research quality and fresh generalization evaluation — 20 November 2026\n\n','');
const report=`# Research quality and fresh generalization evaluation — 20 November 2026

The targeted report-format, authority-explanation and temporal-uncertainty changes passed regression checks, but research is not complete. The familiar development set remains much easier than the fresh set. Exact citations and restart preservation do not establish complete, correct answers. The current results do not establish an aggregate quality improvement or OpenJarvis product parity.

## Final results

Both models ran seeds 1/2/7 on the same frozen executable. All 240 final answers were reviewed; neither failed seeds nor individual answers were replaced. “Stricter” removes accepted borderline answers; “lenient” adds rejected borderline answers. These are judgment-sensitivity bounds, not confidence intervals. Full reasons and every failed answer remain in the archive and [machine-readable summary](${prefix}-summary.json).

${tables.join('\n')}

## What remains

The development replay has six failed turns: five at 4B and one at 27B. The 4B failures concern unsupported selection-bias attribution, invented license wording, two incomplete SQLite reader-mode comparisons and a contradictory unresolved-question statement after an otherwise complete long-page answer. The 27B failure incorrectly says existing readers are blocked from continuing, where the source describes a writer waiting for them to finish. Accepted borderline citation placement, timing and license wording remain visible in the stricter scores. The previous build's 76/81 and 81/81 results are historical; these runs do not establish a monotonic improvement.

All six development source-authority inspection answers passed the content review. The core traces still contain four rejected plans across two 4B turns before successful repair. The targeted diagnostic separately passed six turns with two pre-execution missing-argument rejections; those are not zero-repair successes.

The fresh cases expose weak multi-part evidence use on public technical pages, incomplete or overconfident same-name identity reasoning, and inconsistent handling of multilingual corrections and temporal uncertainty. One 27B Persian answer changes the source's device-owner approval requirement into confirmation of ownership; its corrected restart answer restores the right requirement. This is an interpretation error, not a change to runtime permissions. Some similar-name answers keep the two biographies separately attributed, so the main rubric accepts them while stricter review rejects the extra namesake/profile clutter. The automatic forbidden-word check rejects those separate mentions even without a merger. Conversely, automatic checks accept some incomplete technical answers. Neither automatic score is a substitute for source review.

A targeted captured-source audit confirms the missing Python strict=True/ValueError paragraph and Git --exit-code semantics were saved for the inspected 4B and 27B failures. The Cargo snapshot also contains the dep: suppression rule and a differently named feature activating optional dependencies. This establishes saved-evidence availability, not exactly which excerpts reached the model after context trimming. The inspected core generation traces record the model identifier and token counts, not the final trimmed prompt; the audit cannot distinguish excerpt omission from model interpretation alone. Instrument and inspect selection into the inference window and preservation of requested conditions before increasing page reads or execution limits. The audit includes source text hashes and surrounding passages.

Next implementation: preserve each requested part and its relevant context through evidence selection; make missing conclusions and uncertainty explicit; improve identity disambiguation and correction handling; retain bounded repair and truthful incomplete status. Turn these now-exposed failures into development regressions, then freeze another fresh set with independent review before new generalization claims. Repeat the live Tavily and physical Android workflow and controlled-power performance measurements. PDF extraction, source continuity, approved export and wider OpenJarvis capabilities remain later roadmap work.

The final 27B namesake continuation also illustrates a remaining claim-to-citation gap: after two rejected attempts, its validated answer still describes Dana Kent's robotics/lunar work while citing only Dana Keene's historian passage. The names are kept separate, but the displayed quotation does not support those added facts. Exact quotation integrity and a successful report call do not certify the generated finding.

## Recorded timings

${times.join('\n')}

These are the raw harness per-turn fields, including failures and repairs. They are not controlled model-speed measurements. In particular, system sleep made the harness and trace clocks diverge; the maximum above is not a complete elapsed wall-clock account. See the power and latency caveats below.

## Implementation, methods and validation

${methods}

## Evidence and reproduction

The [evidence archive](${prefix}.tar.gz) preserves both final matrices, all-turn judgments, frozen page bytes/rubrics, 138-file source overlays, two partial candidates, exploratory diagnostics, validation logs, sanitized performance samples and TypeScript replay helpers. The [archive verification](${prefix}-archive-check.json) checks current source, executable and model hashes, then extracts the archive and reproduces both summaries and all verifier controls. There are ${verified.controls.development.controls.length} development controls and ${verified.controls.generalization.controls.length} generalization controls; all passed. They test incomplete matrices/reviews, duplicate judgments, modified quotations/corpora/capture times, execution limits, and counting pre-execution rejections separately from UI events. The development controls also reject removal of a requested late fact.

Archive SHA-256: \`${verified.archiveSha256}\`.

\`\`\`sh
# Extract to a new directory; no model weights or API key are needed for replay.
tar -xzf bench/research/evidence/${prefix}.tar.gz -C /path/to/new-directory
node /path/to/new-directory/development/replay.ts
node /path/to/new-directory/development/check-replay.ts
node /path/to/new-directory/generalization/replay.ts
node /path/to/new-directory/generalization/check-replay.ts
\`\`\`
`;
writeFileSync(`${evidence}/${prefix}-report.md`,report,{flag:'wx'});
