import { readFileSync, writeFileSync } from 'node:fs';
const root='/private/tmp/pr3-research-quality-2026-11-20/archive';
for(const name of ['development','generalization']) {
  const path=`${root}/${name}/replay.ts`;
  let text=readFileSync(path,'utf8');
  if(text.includes('strictSourceReviewedPass'))throw Error('Already applied');
  text=text.replace('sourceReviewedPass:number;borderlineFailures:number;', 'sourceReviewedPass:number;acceptedBorderlines:number;borderlineFailures:number;');
  text=text.replace('sourceReviewedPass:0,borderlineFailures:0,','sourceReviewedPass:0,acceptedBorderlines:0,borderlineFailures:0,');
  text=text.replace('g.sourceReviewedPass+=Number(decision.pass);','g.sourceReviewedPass+=Number(decision.pass);g.acceptedBorderlines+=Number(decision.pass && decision.borderline===true);');
  text=text.replace('seconds:undefined,medianSeconds:', 'seconds:undefined,strictSourceReviewedPass:g.sourceReviewedPass-g.acceptedBorderlines,lenientSourceReviewedPass:g.sourceReviewedPass+g.borderlineFailures,maxSeconds:s.at(-1),medianSeconds:');
  writeFileSync(path,text);
}
