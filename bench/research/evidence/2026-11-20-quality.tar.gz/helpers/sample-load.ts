import { appendFileSync, existsSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { loadavg, freemem, totalmem } from 'node:os';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const out='/private/tmp/pr3-research-quality-2026-11-20/load.jsonl';
const finished=()=>{
  const path=root+'/bench/research/result/generalization-2026-11-20/progress.json';
  return existsSync(path)&&JSON.parse(readFileSync(path,'utf8')).complete===true;
};
const command=(name:string,args:string[])=>{
  try{return execFileSync(name,args,{encoding:'utf8',timeout:5000}).trim();}catch{return 'unavailable';}
};
function sample(){
  const top=command('ps',['-A','-o','%cpu=,comm=']).split('\n').map(line=>{
    const m=line.trim().match(/^([\d.]+)\s+(.*)$/);return m?{cpu:Number(m[1]),process:m[2]}:null;
  }).filter(x=>x!==null).sort((a,b)=>b.cpu-a.cpu).slice(0,10);
  appendFileSync(out,JSON.stringify({at:new Date().toISOString(),load:loadavg(),freeMemory:freemem(),totalMemory:totalmem(),power:command('pmset',['-g','batt']),thermal:command('pmset',['-g','therm']),top})+'\n');
}
sample();
const timer=setInterval(()=>{sample();if(finished())clearInterval(timer);},60000);
