import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
const root='/private/tmp/pr3-research-quality-2026-11-20/archive';
for(const name of ['development','generalization']) {
  const path=join(root,name,'replay.ts');
  let text=readFileSync(path,'utf8');
  const replace=(before:string,after:string)=>{if(!text.includes(before))throw Error('Missing replay anchor');text=text.replace(before,after);};
  replace('output:{tool_calls?:unknown[]}', 'output:{tool_calls?:unknown[];success?:boolean}');
  replace('failedToolCalls:number;', 'failedToolCalls:number;traceRejectedCalls:number;');
  replace('failedToolCalls:0,', 'failedToolCalls:0,traceRejectedCalls:0,');
  replace('g.failedToolCalls+=turn.events.filter(e=>e.name && e.success===false).length;', 'g.failedToolCalls+=turn.events.filter(e=>e.name && e.success===false).length;\n        // Core traces also include schema/plan rejections before a UI tool event.\n        g.traceRejectedCalls+=turn.traces.flatMap(t=>t.steps).filter(s=>s.step_type===\'tool_call\' && s.output.success===false).length;');
  writeFileSync(path,text);
  const controls=join(root,name,'check-replay.ts');
  text=readFileSync(controls,'utf8');
  const anchor="  results.push({control:'unaltered evidence accepted',pass:true});";
  if(!text.includes(anchor))throw Error('Missing controls anchor');
  text=text.replace(anchor,anchor+`
  // A pre-execution schema rejection exists in the core trace, not UI events.
  const clean=JSON.parse(valid.stdout), metric='Qwen3.5-4B-Q4_K_M.gguf/all';
  const tracePath=join(matrix,'4b-seed1.jsonl');
  const traceRows=readFileSync(tracePath,'utf8').trim().split('\\n').map(x=>JSON.parse(x));
  traceRows[0].turns[0].traces.push({steps:[{step_type:'tool_call',input:{tool:'answer_research'},output:{success:false,result:'error: missing required argument'}}]});
  writeFileSync(tracePath,traceRows.map(x=>JSON.stringify(x)).join('\\n')+'\\n');
  const counted=run();
  if(counted.status!==0)throw Error('Trace rejection metric check failed: '+counted.stderr);
  const changed=JSON.parse(counted.stdout).groups[metric], before=clean.groups[metric];
  if(changed.traceRejectedCalls!==before.traceRejectedCalls+1||changed.failedToolCalls!==before.failedToolCalls)throw Error('Pre-execution rejection was not counted separately');
  results.push({control:'pre-execution rejection counted from core trace',pass:true});`);
  writeFileSync(controls,text);
}
