import { readFileSync } from 'node:fs';
const rows=readFileSync('/private/tmp/pr3-research-quality-2026-11-20/load.jsonl','utf8').trim().split('\n').map(line=>JSON.parse(line));
for(let i=1;i<rows.length;i++) {
  const before=rows[i-1],after=rows[i],gap=(Date.parse(after.at)-Date.parse(before.at))/1000;
  if(gap>120)console.log(JSON.stringify({gapSeconds:gap,before:{at:before.at,power:before.power},after:{at:after.at,power:after.power}}));
}
const latest=rows.at(-1);console.log(JSON.stringify({latest:{at:latest.at,power:latest.power,load:latest.load,thermal:latest.thermal},samples:rows.length}));
