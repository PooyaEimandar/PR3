import { readFileSync, readdirSync } from 'node:fs';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/research/result';
for(const matrix of ['quality-2026-11-20-final','generalization-2026-11-20']) {
  for(const file of readdirSync(`${root}/${matrix}`).filter(f=>/^(4b|27b)-seed[127]\.jsonl$/.test(f))) {
    const rows=readFileSync(`${root}/${matrix}/${file}`,'utf8').trim().split('\n').filter(Boolean).map(line=>JSON.parse(line));
    for(const row of rows)for(const [turn,t]of row.turns.entries()) {
      const at=t.traces.flatMap((t:{steps:{at:number}[]})=>t.steps.map(s=>s.at));
      if(!at.length)continue;
      const start=Math.min(...at),end=Math.max(...at),traceSeconds=(end-start)/1000;
      if(traceSeconds-t.seconds>120)console.log(JSON.stringify({matrix,file,id:row.id,turn,harnessSeconds:t.seconds,traceSeconds,start:new Date(start).toISOString(),end:new Date(end).toISOString(),differenceSeconds:traceSeconds-t.seconds}));
    }
  }
}
