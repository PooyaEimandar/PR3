import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
const root='/private/tmp/pr3-research-quality-2026-11-20/archive';
for(const name of ['development','generalization']) {
  const replay=join(root,name,'replay.ts');
  let text=readFileSync(replay,'utf8');
  if(!text.includes('let unchangedRestartSnapshots=0, lateCitedPassages=0;'))throw Error('Missing snapshot counter');
  text=text.replace('let unchangedRestartSnapshots=0, lateCitedPassages=0;', 'let unchangedRestartSnapshots=0, nonemptyRestartSnapshots=0, lateCitedPassages=0;');
  text=text.replace('unchangedRestartSnapshots++;', 'unchangedRestartSnapshots++;\n      nonemptyRestartSnapshots+=Number(row.turns[0]!.evidence.sources.length>0);');
  text=text.replace('unchangedRestartSnapshots,lateCitedPassages,', 'unchangedRestartSnapshots,nonemptyRestartSnapshots,lateCitedPassages,');
  writeFileSync(replay,text);
  const controls=join(root,name,'check-replay.ts');
  text=readFileSync(controls,'utf8');
  const quote="rows[0].turns[0].answer=rows[0].turns[0].answer.replace(/^> .*$/mu,'> CORRUPTED-QUOTATION-NOT-IN-SOURCE');";
  const capture='rows[0].turns[1].evidence.sources[0].captured_at+=1;';
  if(!text.includes(quote)||!text.includes(capture))throw Error('Missing control anchor');
  text=text.replace(quote,"const turn=rows.flatMap(row=>row.turns).find(turn=>/^> /mu.test(turn.answer));if(!turn)throw Error('No quotation available for integrity control');turn.answer=turn.answer.replace(/^> .*$/mu,'> CORRUPTED-QUOTATION-NOT-IN-SOURCE');");
  text=text.replace(capture,"const row=rows.find(row=>row.turns.length===2&&row.turns[1].evidence.sources.length>0);if(!row)throw Error('No saved source available for restart control');row.turns[1].evidence.sources[0].captured_at+=1;");
  writeFileSync(controls,text);
}
