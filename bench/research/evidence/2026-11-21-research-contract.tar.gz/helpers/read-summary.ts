import {readFileSync} from 'node:fs';
const summary=JSON.parse(readFileSync(process.argv[2]!,'utf8'));
for(const name of ['development','exposed']){
 const value=summary[name];
 console.log(JSON.stringify({matrix:name,...Object.fromEntries(Object.entries(value).filter(([k])=>!['groups','caseScores','failures','borderlineJudgments'].includes(k))),failureCount:value.failures.length,borderlineCount:value.borderlineJudgments.length,groups:Object.fromEntries(Object.entries(value.groups).filter(([k])=>k.endsWith('/all')))},null,2));
}
console.log(JSON.stringify({inference:summary.inference},null,2));
