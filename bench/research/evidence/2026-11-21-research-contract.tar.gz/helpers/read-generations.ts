import {readFileSync} from 'node:fs';
const [file,id]=process.argv.slice(2);
if(!file||!id)throw Error('JSONL CASE required');
const row=readFileSync(file,'utf8').trim().split('\n').map(line=>JSON.parse(line)).find(row=>row.id===id);
if(!row)throw Error('Missing case');
for(const [turnIndex,turn]of row.turns.entries()){
 console.log(JSON.stringify({id,turn:turnIndex,events:turn.events}));
 for(const trace of turn.traces)for(const step of trace.steps)if(step.step_type==='generate')console.log(JSON.stringify({turn:turnIndex,type:step.step_type,output:step.output}));
}
