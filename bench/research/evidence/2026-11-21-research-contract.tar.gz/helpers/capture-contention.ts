import {execFileSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const rows=execFileSync('ps',['-Ao','pcpu=,comm='],{encoding:'utf8'}).split('\n').flatMap(line=>{
 const m=line.trim().match(/^([\d.]+)\s+(.+)$/);
 return m&&Number(m[1])>=50?[{cpuPercent:Number(m[1]),executable:m[2]}]:[];
});
const value={at:new Date().toISOString(),scope:'One observational process snapshot during the final matrix. No process arguments collected and no process interrupted. CPU accounting does not isolate GPU contention or establish a causal speed effect.',processes:rows};
writeFileSync('/private/tmp/pr3-research-contract-2026-11-21/contention-observation.json',JSON.stringify(value,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(value));
