import {readFileSync} from 'node:fs';
const [path,corpusPath,start='0',count='4']=process.argv.slice(2);
const cases=JSON.parse(readFileSync(corpusPath!,'utf8')).cases;
let index=0;
for(const line of readFileSync(path!,'utf8').split('\n').slice(0,-1)){
 const row=JSON.parse(line),test=cases.find(c=>c.id===row.id);
 for(const [turn,t]of row.turns.entries()){
  const current=index++;if(current<Number(start)||current>=Number(start)+Number(count))continue;
  console.log(JSON.stringify({index:current,id:row.id,turn,request:turn?test.restart:test.topic,rubric:(turn?test.restart_review??test.review:test.review)?.rubric,answer:t.answer.replace(/ \[(?:research|document):[^\]\n]+\]/gu,'').replace('Research findings\n\nThe analysis below is model-generated. The attached quotations are checked against saved sources.\n\n',''),diagnosticPass:t.pass,error:t.error,seconds:t.seconds,rejections:t.traces.flatMap(trace=>trace.steps).filter(s=>s.step_type==='tool_call'&&s.output?.success===false).map(s=>s.output.result)}));
 }
}
