import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
const [dir,label,seed,items]=process.argv.slice(2);
if(!dir||!label||!seed||!items)throw Error('MATRIX LABEL SEED JSON_DECISIONS');
const model=label==='4b'?'Qwen3.5-4B-Q4_K_M.gguf':'Qwen3.8-27B-Q4_K_M.gguf';
const turns=readFileSync(join(dir,`${label}-seed${seed}.jsonl`),'utf8').split('\n').slice(0,-1).flatMap(line=>{
  const row=JSON.parse(line);return row.turns.map((_:unknown,turn:number)=>({id:row.id,turn}));
});
const path=join(dir,'source-review.json');
const review=existsSync(path)?JSON.parse(readFileSync(path,'utf8')):{complete:false,method:'Unblinded implementation-assistant review of every actual answer against the latest request and its cited source evidence. All material unsupported claims, missing requested conclusions, irrelevant instructions and incomplete reports fail. Not independent human validation.',decisions:[]};
for(const [index,pass,reason,borderline]of JSON.parse(items)) {
  const t=turns[index];if(!t||typeof pass!=='boolean'||!reason.trim())throw Error('Invalid reviewed turn');
  if(review.decisions.some((d:{model:string;seed:number;id:string;turn:number})=>d.model===model&&d.seed===Number(seed)&&d.id===t.id&&d.turn===t.turn))throw Error('Already reviewed');
  review.decisions.push({model,seed:Number(seed),...t,pass,reason:typeof borderline==='string'?reason+' Borderline: '+borderline:reason,...(borderline?{borderline:true}:{})});
}
const manifest=JSON.parse(readFileSync(join(dir,'manifest.json'),'utf8'));
review.complete=review.decisions.length===manifest.expectedTurns;
writeFileSync(path,JSON.stringify(review,null,2)+'\n');
console.log(JSON.stringify({reviewed:review.decisions.length,expected:manifest.expectedTurns,complete:review.complete}));
