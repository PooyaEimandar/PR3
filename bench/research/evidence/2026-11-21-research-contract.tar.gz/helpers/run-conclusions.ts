import {spawn} from 'node:child_process';
import {readFileSync,writeFileSync,openSync} from 'node:fs';
const work='/private/tmp/pr3-research-contract-2026-11-21';
const tag=process.argv[2];if(!tag)throw Error('TAG required');
const original=JSON.parse(readFileSync(`${work}/targeted.json`,'utf8'));
const corpus=`${work}/conclusions-${tag}.json`;
writeFileSync(corpus,JSON.stringify({status:'Exposed conclusion diagnostics, unchanged cases',cases:original.cases.filter((c:{id:string})=>['fresh-identical-name','fresh-spanish-dates'].includes(c.id))},null,2)+'\n',{flag:'wx'});
for(const [label,model,seeds] of [['4b','Qwen3.5-4B-Q4_K_M.gguf',[2,7]],['27b','Qwen3.8-27B-Q4_K_M.gguf',[7,1]]] as const)for(const seed of seeds){
 const prefix=`${work}/conclusions-${tag}-${label}-seed${seed}`;
 const log=openSync(prefix+'.log','wx');
 console.log(JSON.stringify({label,seed,start:new Date().toISOString()}));
 await new Promise<void>((resolve,reject)=>{
  const child=spawn(`${work}/research-${tag}`,[`model/${model}`,String(seed),corpus,prefix+'.jsonl'],{stdio:['ignore',log,log]});
  child.once('error',reject);child.once('exit',code=>code===0?resolve():reject(Error('Diagnostic exited '+code)));
 });
 console.log(JSON.stringify({label,seed,end:new Date().toISOString()}));
}
