import {readFileSync,writeFileSync} from 'node:fs';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const work='/private/tmp/pr3-research-contract-2026-11-21';
type Decision={model:string;seed:number;id:string;turn:number;pass:boolean;reason:string; borderline?:boolean};
const previous=JSON.parse(readFileSync(`${root}/bench/research/evidence/2026-11-21-evidence-repair-summary.json`,'utf8'));
const key=(d:Decision)=>`${d.model}/${d.seed}/${d.id}/${d.turn}`;
const result:Record<string,unknown>={scope:'Same exposed cases and seeds, unblinded non-independent review. Runtime-generated references differ; this is not an isolated causal or significance estimate.'};
for(const [name,folder]of [['development','research-contract-dev-2026-11-21'],['exposed','research-contract-exposed-2026-11-21']]){
 const review=JSON.parse(readFileSync(`${root}/bench/research/result/${folder}/source-review.json`,'utf8')) as {complete:boolean;decisions:Decision[]};
 if(!review.complete)throw Error('Final review incomplete: '+name);
 const current=new Map(review.decisions.map(d=>[key(d),d]));
 const failures=previous[name!].failures as Decision[];
 const oldFailed=new Set(failures.map(key));
 result[name!]={previousFailures:failures.map(d=>{
   const now=current.get(key(d));if(!now)throw Error('Missing previous case');
   return {model:d.model,seed:d.seed,id:d.id,turn:d.turn,previousReason:d.reason,currentPass:now.pass,currentBorderline:now.borderline??false,currentReason:now.reason};
 }),newMainFailures:review.decisions.filter(d=>!d.pass&&!oldFailed.has(key(d)))};
}
writeFileSync(`${work}/prior-comparison.json`,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result,null,2));
