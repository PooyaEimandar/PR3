import {readFileSync} from 'node:fs';
const [path,id]=process.argv.slice(2);
for(const line of readFileSync(path!,'utf8').split('\n').slice(0,-1)){
 const row=JSON.parse(line);if(row.id!==id)continue;
 for(const [turn,t]of row.turns.entries())for(const trace of t.traces)for(const step of trace.steps)if(step.step_type==='tool_call'&&step.output?.success===false)console.log(JSON.stringify({turn,input:step.input,output:step.output},null,2));
}
