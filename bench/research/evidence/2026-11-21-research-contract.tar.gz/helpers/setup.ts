import {readFileSync,writeFileSync,mkdirSync,cpSync} from 'node:fs';
import {join} from 'node:path';
const root='/Users/pooyaeimandar/Codes/PooyaEimandar/pr3';
const previous='/private/tmp/pr3-evidence-repair-2026-11-21';
const work='/private/tmp/pr3-research-contract-2026-11-21';
for(const name of ['audit-inference.ts','check-inference.ts','check-freeze.ts','freeze-build.ts','status.ts','next-review.ts','record-review.ts','read-answers.ts','read-evidence.ts','read-summary.ts','inspect-rejections.ts','run-matrices.ts','power-summary.ts','log-power-event.ts','finalize.ts']) {
 const text=readFileSync(join(previous,name),'utf8').replaceAll(previous,work)
 .replaceAll('evidence-repair-dev-2026-11-21','research-contract-dev-2026-11-21')
 .replaceAll('evidence-repair-exposed-2026-11-21','research-contract-exposed-2026-11-21')
 .replaceAll("prefix='2026-11-21-evidence-repair'","prefix='2026-11-21-research-contract'")
 .replaceAll('2026-11-20-evidence-completeness','2026-11-21-evidence-repair')
 .replaceAll('pr3-repair-verify-','pr3-contract-verify-');
 writeFileSync(join(work,name),text,{flag:'wx'});
}
for(const matrix of ['development','exposed']){
 const dir=join(work,'archive',matrix);mkdirSync(dir,{recursive:true});
 for(const helper of ['replay.ts','check-replay.ts'])cpSync(join(previous,'archive',matrix,helper),join(dir,helper),{errorOnExist:true,force:false});
}
const wanted=new Set(['public-sqlite-comparison-restart','fresh-python-zip','fresh-cargo-features','fresh-identical-name','fresh-spanish-dates','fresh-persian-recovery']);
const cases=['evidence-repair-dev-2026-11-21','evidence-repair-exposed-2026-11-21'].flatMap(name=>JSON.parse(readFileSync(join(root,'bench/research/result',name,'corpus.json'),'utf8')).cases).filter(c=>wanted.has(c.id));
writeFileSync(join(work,'targeted.json'),JSON.stringify({status:'Exposed targeted diagnostics, unchanged cases from the prior frozen matrix.',cases},null,2)+'\n',{flag:'wx'});
writeFileSync(join(work,'scope.json'),JSON.stringify({scope:'Fix eight remaining research failures. Final unchanged development and exposed regression matrices, 4B/27B seeds 1/2/7. All actual answers reviewed; no retry substitution, new holdout or matched OpenJarvis claim.',previousArchive:'2026-11-21-evidence-repair.tar.gz'},null,2)+'\n',{flag:'wx'});
console.log({targetedCases:cases.length,targetedTurns:cases.reduce((n,c)=>n+(c.restart?2:1),0)});
