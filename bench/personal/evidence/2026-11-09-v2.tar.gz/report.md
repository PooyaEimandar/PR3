# personal-200-v2 current-build evaluation

Complete: **True**. Recorded 1200/1200.

Development and heldout are separate. Pending cases stay in the planned denominator; failed/error cases are never dropped.

| Split | Model | Recorded / planned | Passed | Failed | Runtime errors | Task leaks |
|---|---|---:|---:|---:|---:|---:|
| development | Qwen3.5-4B-Q4_K_M | 360/360 | 247 | 113 | 4 | 0 |
| development | Qwen3.8-27B-Q4_K_M | 360/360 | 351 | 9 | 2 | 0 |
| heldout | Qwen3.5-4B-Q4_K_M | 240/240 | 160 | 80 | 12 | 11 |
| heldout | Qwen3.8-27B-Q4_K_M | 240/240 | 199 | 41 | 2 | 12 |

The 200 synthetic cases belong to 50 families; variants and seeds are related observations. These rates are descriptive, not a population accuracy estimate.
No live email, physical Android, cross-device transport, calendar execution, file sharing or encryption-key custody is measured.
Raw answers and exact effects remain in rows/. progress.json contains category/language/seed/family breakdowns and every failing check.
Timings exclude model loading and background summary work. An error-free runner is not a claim that the evaluated product passed every task.
