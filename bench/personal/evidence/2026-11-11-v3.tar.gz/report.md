# personal-200-v3 current-build evaluation

Complete: **True**. Recorded 1494/1494.

Partitions are separate. Only fresh-heldout in v3 is new held-out evidence; both prior v2 partitions and email cases are reused regressions. Pending cases stay in the planned denominator; failures/errors are retained.

| Split | Model | Recorded / planned | Passed | Failed | Runtime errors | Task leaks |
|---|---|---:|---:|---:|---:|---:|
| regression-development | Qwen3.5-4B-Q4_K_M | 360/360 | 270 | 90 | 1 | 0 |
| regression-development | Qwen3.8-27B-Q4_K_M | 360/360 | 353 | 7 | 1 | 0 |
| regression-prior-heldout | Qwen3.5-4B-Q4_K_M | 240/240 | 194 | 46 | 0 | 0 |
| regression-prior-heldout | Qwen3.8-27B-Q4_K_M | 240/240 | 238 | 2 | 0 | 0 |
| email-regression | Qwen3.5-4B-Q4_K_M | 27/27 | 26 | 1 | 0 | 0 |
| email-regression | Qwen3.8-27B-Q4_K_M | 27/27 | 27 | 0 | 0 | 0 |
| fresh-heldout | Qwen3.5-4B-Q4_K_M | 120/120 | 88 | 32 | 3 | 0 |
| fresh-heldout | Qwen3.8-27B-Q4_K_M | 120/120 | 107 | 13 | 1 | 0 |

The 249 synthetic cases belong to 79 families; variants and seeds are related observations. Rates are descriptive, not a population accuracy estimate.
No live email, physical Android, cross-device transport, calendar execution, file sharing or encryption-key custody is measured.
Raw answers and exact effects remain in rows/. progress.json contains category/language/seed/family breakdowns and every failing check.
Timings exclude model loading and background summary work. An error-free runner is not a claim that the evaluated product passed every task.

## Privacy and desktop model-turn latency

Mail disclosures count actual forbidden card/outbox content, not absent cards. Model-turn latency includes only turns with recorded prompt tokens; it excludes model load/background summaries and is not Android latency.

| Partition | Model | Mail disclosures | Unapproved/duplicate effects | Model turns | Turn median / p95 (s) | First visible median / p95 (ms) |
|---|---|---:|---:|---:|---|---|
| regression-development | Qwen3.5-4B-Q4_K_M | 0 | 0 | 1427 | 2.48 / 7.53 | 2484 / 7504 |
| regression-development | Qwen3.8-27B-Q4_K_M | 0 | 0 | 1428 | 12.38 / 49.76 | 12376.5 / 48189 |
| regression-prior-heldout | Qwen3.5-4B-Q4_K_M | 0 | 0 | 948 | 2.7 / 7.42 | 2696.0 / 7395 |
| regression-prior-heldout | Qwen3.8-27B-Q4_K_M | 0 | 0 | 948 | 11.43 / 40.71 | 11431.0 / 37661 |
| email-regression | Qwen3.5-4B-Q4_K_M | 0 | 0 | 60 | 5.86 / 7.37 | 3535.5 / 7194 |
| email-regression | Qwen3.8-27B-Q4_K_M | 0 | 0 | 60 | 27.07 / 47.21 | 18511.0 / 40185 |
| fresh-heldout | Qwen3.5-4B-Q4_K_M | 0 | 0 | 551 | 3.97 / 12.3 | 3965 / 10193 |
| fresh-heldout | Qwen3.8-27B-Q4_K_M | 0 | 0 | 551 | 14.89 / 51.48 | 14729 / 44092 |
