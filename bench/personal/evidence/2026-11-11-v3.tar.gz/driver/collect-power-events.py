from pathlib import Path
import datetime,json,re,subprocess

root=Path('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3/bench/personal/result/2026-11-11-v3')
target=root/'validation/power-events.json'
start=datetime.datetime.fromisoformat(json.loads((root/'manifest.json').read_text())['created_at_utc'])
previous=json.loads(target.read_text()) if target.exists() else {'events':[]}
events={(e['at_utc'],e['event']):e for e in previous['events'] if not e['description'].startswith('Requests')}
raw=subprocess.check_output(['/usr/bin/pmset','-g','log'],text=True)
for line in raw.splitlines():
    match=re.match(r'^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d [+-]\d{4})\s+(Sleep|Wake|DarkWake)\s+(.+)$',line)
    if not match or match[3].strip().startswith('Requests'):
        continue
    stamp=datetime.datetime.strptime(match[1],'%Y-%m-%d %H:%M:%S %z')
    if stamp<start:
        continue
    event={'at_utc':stamp.astimezone(datetime.timezone.utc).isoformat(),'event':match[2],'description':match[3].strip()}
    events[(event['at_utc'],event['event'])]=event
result={'captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source':'pmset -g log; only observed Sleep/Wake/DarkWake events since run preparation, merged with earlier snapshots',
        'events':[events[key] for key in sorted(events)],
        'interpretation':'System sleep occurred during this descriptive desktop run, with the Mac reporting battery power. Raw scores and timings are retained without adjustment; this is not a controlled latency experiment.'}
target.write_text(json.dumps(result,indent=2)+'\n')
print('Retained',len(events),'observed power events.')
