from pathlib import Path
from collections import Counter
import hashlib,json,re,shutil,subprocess,sys,tarfile,tempfile,tomllib
ROOT=Path('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3')
OUT=ROOT/'bench/personal/result/2026-11-11-v3'
STEM='2026-11-11-v3'
sys.path.insert(0,str(OUT/'driver'))
import run,dataset
from score import assess

def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
m=json.loads((OUT/'manifest.json').read_text());finished=json.loads((OUT/'finished.json').read_text())
assert finished['complete']
run.verify(OUT,m)
summary=run.summarize(OUT,m)
assert summary['complete'] and summary['recorded']==summary['planned']==1494
assert all(digest(ROOT/name)==h for name,h in m['source_sha256'].items()), 'Working sources changed; report the evaluated snapshot accurately before export'
pre=json.loads((OUT/'validation/preflight.json').read_text())
assert pre['run_manifest_sha256']==digest(OUT/'manifest.json')
audit_path=ROOT/'bench/rebaseline/result/2026-11-07/.personal-v3-20261112-resume1-interruption.json'
audit=json.loads(audit_path.read_text())
assert audit['exit_code']==(1 if summary['errors'] else 0) and audit['resumed_pid']
shutil.copy2(audit_path,OUT/'validation/historical-resume.json')
shutil.copy2(ROOT/'bench/rebaseline/result/2026-11-07/.personal-v3-20261111-interruption.json',OUT/'validation/original-interruption.json')
shutil.copy2('/tmp/pr3-personal-v3-resume1.log',OUT/'resume1-runner.log')
shutil.copy2('/tmp/pr3-personal-v3-isolated.py',OUT/'driver/isolate.py')
shutil.copy2('/tmp/pr3-personal-v3-evaluation.log',OUT/'runner.log')
shutil.copy2(__file__,OUT/'driver/package.py')
subprocess.run([sys.executable,'/tmp/pr3-personal-v3-power.py'],check=True)
shutil.copy2('/tmp/pr3-personal-v3-power.py',OUT/'driver/collect-power-events.py')
# Compare only literally unchanged cases and identical model weights/seeds.
prior=ROOT/'bench/personal/evidence/2026-11-09-v2.tar.gz'
prior_evidence=json.loads((ROOT/'bench/personal/evidence/2026-11-09-v2.json').read_text())
assert digest(prior)==prior_evidence['archive_sha256']
old_rows={}
with tarfile.open(prior) as archive:
 old_manifest=json.load(archive.extractfile('manifest.json'))
 old_dataset=json.load(archive.extractfile('data/manifest.json'))
 for member in archive.getmembers():
  if member.name.startswith('rows/') and member.name.endswith('.jsonl'):
   model=next(model for model in m['models'] if model in member.name)
   assert m['models'][model]['sha256']==old_manifest['models'][model]['sha256']
   for line in archive.extractfile(member):
    row=json.loads(line);old_rows[(model,row['seed'],row['id'])]=row
current_dataset=json.loads((OUT/'data/manifest.json').read_text())
old_cases={c['id']:c for c in old_dataset['cases']}
unchanged={c['id'] for c in current_dataset['cases'] if c['id'] in old_cases and c['sha256']==old_cases[c['id']]['sha256']}
comparison=[]
for model in m['models']:
 matched=[]
 for job in m['jobs']:
  if job['model']!=model:continue
  for line in (OUT/'rows'/(job['name']+'.jsonl')).read_text().splitlines():
   row=json.loads(line)
   if row['id'] in unchanged:
    old=old_rows[(model,row['seed'],row['id'])]
    matched.append((old['passed'],row['passed']))
 assert len(matched)==len(unchanged)*3
 comparison.append({'model':model,'unchanged_cases':len(unchanged),'runs':len(matched),
                    'previous_passed':sum(a for a,b in matched),'current_passed':sum(b for a,b in matched),
                    'changed_to_pass':sum(not a and b for a,b in matched),'changed_to_fail':sum(a and not b for a,b in matched)})
# Retain inspectable failed-step examples without converting strict failures into passes.
examples=[]
for failure in summary['failures']:
 job=next(j for j in m['jobs'] if j['name']==failure['job'])
 rows=[json.loads(s) for s in (OUT/'rows'/(job['name']+'.jsonl')).read_text().splitlines()]
 row=next(r for r in rows if r['id']==failure['id'])
 for check in failure['failures']:
  at=next((s for s in row['steps'] if (s['launch'],s['step'])==(check['launch'],check['step'])),None)
  examples.append({'model':job['model'],'seed':job['seed'],'split':job['split'],'case':row['id'],'check':check,
                   'answer':at.get('answer') if at else None,'card':at.get('card') if at else None,
                   'sent':at.get('sent') if at else None,'error':at.get('error') if at else None})
write(OUT/'failure-observations.json',examples)
write(OUT/'unchanged-case-comparison.json',comparison)
# Portable replay uses a scratch copy so validation never modifies archived evidence.
replay='''from pathlib import Path
import hashlib,json,shutil,sys,tempfile
import run
from dataset import validate
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name,h in json.loads((root/'inventory.json').read_text()).items():assert digest(root/name)==h,name
m=json.loads((root/'manifest.json').read_text());validate(root/'data')
for name,h in m['files'].items():
 if name!='bin/pr3-bench-task':assert digest(root/name)==h,name
with tempfile.TemporaryDirectory(prefix='pr3-personal-replay-') as directory:
 scratch=Path(directory)
 for folder in ('data','rows'):shutil.copytree(root/folder,scratch/folder)
 shutil.copy2(root/'manifest.json',scratch/'manifest.json')
 actual=run.summarize(scratch,m)
 expected=json.loads((root/'progress.json').read_text())
 for key in ('complete','planned','recorded','passed','errors','groups','jobs','failures','result_sha256'):
  assert actual[key]==expected[key],key
 assert actual['complete'] and actual['recorded']==actual['planned']==1494
print('Verified all 1494 rows, identities, failures, privacy checks, split metrics and latency from raw observations.')
'''
(OUT/'driver/replay.py').write_text(replay)
files=[p for p in OUT.rglob('*') if p.is_file() and p.relative_to(OUT).parts[0]!='bin' and '__pycache__' not in p.parts and p.name not in ('inventory.json','running.json','.lock')]
write(OUT/'inventory.json',{str(p.relative_to(OUT)):digest(p) for p in sorted(files)})
files.append(OUT/'inventory.json')
subprocess.run([sys.executable,str(OUT/'driver/replay.py'),str(OUT)],check=True)
archive=ROOT/'bench/personal/evidence'/(STEM+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(OUT)))
evidence={'status':'Completed current-build workflow evaluation; failures retained, not a release certification.',
 'complete':True,'finished_at_utc':finished['finished_at_utc'],'recorded':1494,'planned':1494,'dataset_version':'personal-200-v3',
 'base_commit':m['base_commit'],'run_manifest_sha256':digest(OUT/'manifest.json'),'dataset_manifest_sha256':m['dataset_manifest_sha256'],
 'binary_sha256':m['files']['bin/pr3-bench-task'],'models':m['models'],'seeds':m['seeds'],'groups':summary['groups'],
 'task_runs_with_runtime_errors':summary['errors'],'failure_count':len(summary['failures']),
 'unchanged_case_comparison':comparison,'archive':str(archive.relative_to(ROOT)),'archive_sha256':digest(archive),
 'preflight':pre['validation'],'historical_matrix_resumed':audit,
 'limits':['200 prior tasks and nine email cases are reused regressions. Only the 40 newly authored tasks in 20 families form a fresh public runtime holdout.',
           'Variants and seeds are related; do not pool partitions or claim population accuracy. No runtime/prompt tuning occurred during this matrix.',
           'V3 explicitly versions numeric alternatives and eight email requests; full v2/v3 scores are not a clean causal before/after comparison. The matched table uses only identical case hashes and model weights.',
           'Strict bare-answer checks retain correct-value replies with unwanted prose as instruction-following failures. Lexical checks do not establish general semantic truth, negation or privacy.',
           'System sleep occurred during this run, with the Mac reporting battery power; raw desktop timings are unadjusted descriptive measurements, not controlled performance results.',
           'Model-turn desktop latency excludes runtime-only steps, model loading and background summary work. No Android, power, physical continuity, real sending or current full security certification.']}
write(ROOT/'bench/personal/evidence'/(STEM+'.json'),evidence)
with tempfile.TemporaryDirectory(prefix='pr3-v3-export-check-') as directory:
 with tarfile.open(archive) as tar:tar.extractall(directory,filter='data')
 subprocess.run([sys.executable,str(Path(directory)/'driver/replay.py'),directory],check=True)
print('Exported',archive)
print('Groups:',[(g['split'],g['model'],g['passed'],g['planned']) for g in summary['groups']])
