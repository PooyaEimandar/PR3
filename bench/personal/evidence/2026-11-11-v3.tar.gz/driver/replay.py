from pathlib import Path
import hashlib,json,shutil,sys,tempfile
import run
from dataset import validate
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for name,h in json.loads((root/'inventory.json').read_text()).items():assert digest(root/name)==h,name
m=json.loads((root/'manifest.json').read_text());validate(root/'data')
for name,h in m['files'].items():
 if name!='bin/pr3-bench-task':assert digest(root/name)==h,name
with tempfile.TemporaryDirectory(prefix='pr3-personal-replay-') as directory:
 scratch=Path(directory)
 for folder in ('data','rows'):shutil.copytree(root/folder,scratch/folder)
 shutil.copy2(root/'manifest.json',scratch/'manifest.json')
 actual=run.summarize(scratch,m)
 expected=json.loads((root/'progress.json').read_text())
 for key in ('complete','planned','recorded','passed','errors','groups','jobs','failures','result_sha256'):
  assert actual[key]==expected[key],key
 assert actual['complete'] and actual['recorded']==actual['planned']==1494
print('Verified all 1494 rows, identities, failures, privacy checks, split metrics and latency from raw observations.')
