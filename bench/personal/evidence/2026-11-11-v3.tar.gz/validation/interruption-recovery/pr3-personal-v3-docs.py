from pathlib import Path
from collections import Counter
import json
ROOT=Path('/Users/pooyaeimandar/Codes/PooyaEimandar/pr3')
E=ROOT/'bench/personal/evidence/2026-11-11-v3.json'
e=json.loads(E.read_text());assert e['complete'] and e['recorded']==1494
out=ROOT/'bench/personal/result/2026-11-11-v3'
p=json.loads((out/'progress.json').read_text())
examples=json.loads((out/'failure-observations.json').read_text())
hardware=json.loads((out/'validation/hardware-snapshot.json').read_text())['fields']
num=lambda n:'—' if n is None else f'{n:.2f}'
lines=['# Personal-200 v3: current-build evaluation and fresh challenges','',
 'All **1,494 declared runs completed** on the frozen build: both installed 4B/27B models, seeds **1/2/7**. Every failure and runtime error remains in its planned denominator. This completes the evaluation, not a product release gate.','',
 '[Results and hashes](2026-11-11-v3.json) · [Portable raw evidence](2026-11-11-v3.tar.gz) · [Preflight](2026-11-11-v3-preflight.json) · [Dataset and methodology](../README.md)','',
 '## Separate evaluation groups','',
 '| Partition | Model | Passed / planned | Task runs with errors | Forbidden recall | Mail disclosure | Unapproved/duplicate effect |',
 '|---|---|---:|---:|---:|---:|---:|']
for g in e['groups']:
 lines.append(f"| {g['split']} | {g['model']} | {g['passed']}/{g['planned']} | {g['errors']} | {g['leaked']} | {g['mail_disclosure_runs']} | {g['unapproved_or_duplicate_effect_runs']} |")
lines+=['','The 200 prior Personal tasks and nine email cases are reused regressions. Only the 40 new tasks in 20 families are fresh public runtime-held-out evidence for this frozen build. Variants and repeated seeds are related observations; these are descriptive task results, not population accuracy estimates. The models differ in family as well as size.','',
 'No product prompt, runtime code, approval rule or execution allowance changed during the evaluation. Held-out results did not select cases or trigger tuning. A public synthetic holdout is not a secret exam or proof against training contamination.','',
 '## Version boundary and matched comparison','',
 'V3 preserves v1/v2 files and original scores. Positive and negative checks explicitly accept equivalent comma/space grouping of ASCII integers. Eight resumed-email requests clarify the message purpose without repeating the original recipient or reference. Bare-answer checks still reject extra prose and guesses. The Rust harness and independent Python scorer remain unchanged.','',
 'Because inputs/oracles changed, overall v2 and v3 scores are not a clean before/after comparison. The following subset includes only identical case hashes, identical model weights and seeds 1/2/7. It is reused regression evidence.','',
 '| Model | Unchanged cases × 3 seeds | Previous passes | Current passes | Changed to pass | Changed to fail |',
 '|---|---:|---:|---:|---:|---:|']
for c in e['unchanged_case_comparison']:
 lines.append(f"| {c['model']} | {c['unchanged_cases']} × 3 = {c['runs']} | {c['previous_passed']} | {c['current_passed']} | {c['changed_to_pass']} | {c['changed_to_fail']} |")
lines+=['','## Remaining failures','',f"There are **{e['task_runs_with_runtime_errors']} task runs with runtime errors**. Runtime errors, missing drafts and wrong content are distinct failure types. `failure-observations.json` in the archive retains the exact failed check, reply, card, outbox and error; raw full traces remain in `rows/`.",'',
 'Forbidden recalled values count `forbid` failures. Mail disclosure requires actual forbidden content in an approval card or sandbox record; an absent card is not a disclosure. Unapproved/duplicate effects and exact-approval failures remain separate. Lexical checks cannot prove general semantic correctness, negation or privacy.','',
 '| Partition / model | Failing checks (step counts, not independent tasks) |','|---|---|']
for g in e['groups']:
 checks=', '.join(f'{k}: {v}' for k,v in sorted(g['failures_by_check'].items(),key=lambda kv:(-kv[1],kv[0]))) or 'None'
 lines.append(f"| {g['split']} / {g['model']} | {checks} |")
lines+=['','### Fresh-family breakdown','', '| Family | 4B passed / 6 | 27B passed / 6 |','|---|---:|---:|']
fresh=[g for g in e['groups'] if g['split']=='fresh-heldout']
for family in sorted(set().union(*(set(g['by']['family']) for g in fresh))):
 vals=[g['by']['family'][family]['passed'] for g in fresh]
 lines.append(f'| {family} | {vals[0]}/6 | {vals[1]}/6 |')
lines+=['','### Inspectable examples','']
seen=set()
for item in examples:
 key=(item['split'],item['check']['what'])
 if key in seen:continue
 seen.add(key)
 lines.append(f"- `{item['case']}` / {item['model']} / seed {item['seed']}: failed **{item['check']['what']}**. Expected check: `{item['check']['words']}`. Observed reply: {json.dumps((item['answer'] or '')[:300],ensure_ascii=False)}. See the full card/error in the archive.")
 if len(seen)>=10:break
lines+=['','These examples do not adjust the score. In particular, a reply containing the requested code with unwanted prose still fails an explicit bare-answer request. No failed run was repeated to improve its score.','',
 '## Desktop latency','', f"Runtime hardware snapshot: {hardware['machdep.cpu.brand_string']}, {int(hardware['hw.memsize'])/1073741824:g} GiB memory, {hardware['hw.ncpu']} CPU cores ({hardware['hw.model']}). Hardware fields were recorded during inference, not frozen before it.",'', '| Partition | Model | Model turns | Whole-turn median / p95 (s) | First visible median / p95 (ms) |',
 '|---|---|---:|---|---|']
for g in e['groups']:
 l=g['latency'];lines.append(f"| {g['split']} | {g['model']} | {l['model_turn_count']} | {num(l['model_turn_median_seconds'])} / {num(l['model_turn_p95_seconds'])} | {num(l['model_first_visible_median_ms'])} / {num(l['model_first_visible_p95_ms'])} |")
lines+=['','Measured on the recorded desktop environment, one benchmark model process at a time. System sleep occurred during the run, with the Mac reporting battery power; `validation/power-events.json` retains the observed events. Raw timings are unadjusted descriptive measurements, not a controlled performance experiment. Model turns require recorded prompt tokens; deterministic runtime commands and errors without a token record are excluded from this timing table. All runtime errors remain in the task-score denominator. Model loading, background summaries, phone latency and energy are not measured. These definitions are narrower than the old v2 first-visible aggregate, so do not interpret those timing columns as a matched performance comparison.','',
 '## Reproducibility and next gates','',
 f"The evaluated product is commit `{e['base_commit']}` with benchmark-only additions archived alongside it. All 443 workspace tests, 33 Python tests, strict Clippy and formatting passed. Preflight verified 157 runtime/build files against that product commit. Source, binary, model, dataset and driver hashes were frozen before inference and verified before export.",'',
 'The archive retains all raw rows, frozen sources/inputs/scorer, validation logs, failures, identities and interruption/resume audit. Binaries and model weights are omitted; their hashes remain. Independent replay from a fresh extraction reproduces every result and metric:','',
 '```sh','python3 driver/replay.py .','```','',
 'Prior evidence remains immutable. The historical security matrix resumed with its own original command and older frozen inputs; completion of this workflow evaluation does not complete that matrix. Android email/contacts, phone/computer continuity, key recovery, mobile latency and the 30-day real-use diary remain separate gates. Use the failures above to select the next product fix, then treat these newly observed families as regression evidence for that next build.']
(ROOT/'bench/personal/evidence/2026-11-11-v3-report.md').write_text('\n'.join(lines)+'\n')
# Replace only the explicit in-progress status paragraph written for this run.
fresh_scores='; '.join(f"{g['model']}: {g['passed']}/{g['planned']}" for g in fresh)
paragraph=f'''**11 November current-build workflow rebaseline (completed).** All **1,494 declared runs** completed on the frozen current product build: 200 revised Personal regression tasks, nine unchanged email cases and 40 newly frozen tasks, both models at seeds 1/2/7. Fresh-held-out passes: **{fresh_scores}**. There were **{e['task_runs_with_runtime_errors']} task runs with runtime errors**; all failures, exact effects, privacy findings and desktop latency remain in the separate partition results. No runtime/prompt tuning, approval changes or budget increases occurred. [Report and replay](../bench/personal/evidence/2026-11-11-v3-report.md). V1/v2 results remain immutable; only identical cases are used for the matched comparison. This completes the evaluation, not Android, the separate older security matrix, general semantic accuracy or a release gate. Use the recorded failures to prioritize the next implementation.

'''
for name in ('doc/roadmap.md','doc/benchmarks.md'):
 path=ROOT/name;text=path.read_text();start=text.index('**11 November current-build workflow rebaseline (in progress).**');end=text.index('**10 November multilingual email exclusion follow-up.**',start)
 path.write_text(text[:start]+paragraph+text[end:])
path=ROOT/'doc/changelog.md';text=path.read_text();text=text.replace('- Evaluation is in progress. Preparation is not a completed model score or Android/security release gate. [Preflight](../bench/personal/evidence/2026-11-11-v3-preflight.json).',f'- All 1,494 runs completed; fresh-held-out passes: {fresh_scores}. Every failure and all {e["task_runs_with_runtime_errors"]} runtime-error task runs remain recorded. [Report and replay](../bench/personal/evidence/2026-11-11-v3-report.md). Android and the older security matrix remain separate gates.')
path.write_text(text)
path=ROOT/'bench/personal/README.md';text=path.read_text();text=text.replace('The full evaluation is in progress; preparation and\npassing unit tests do not constitute a completed model result.',f'The [completed evaluation](evidence/2026-11-11-v3-report.md) retains all **1,494 runs**,\nincluding every failure and {e["task_runs_with_runtime_errors"]} runtime-error task runs.\nFresh-held-out passes: {fresh_scores}. This is not a release certification.')
text=text.replace('The other partitions remain pending; this is not the final evaluation.', 'This remains an earlier partial snapshot; do not pool it with the final evaluation.')
path.write_text(text)
print('Completed report and documentation updated.')
